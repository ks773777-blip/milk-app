/* main.js — bootstrap: hydrate from IndexedDB, expose UI handlers, start the app */
import * as UI from './views/ui.js';
import { loadStateAsync } from './lib/store.js';
import qrcode from '../vendor/qrcode.js';

/* inline onclick="fn()" in the markup needs these on the global object */
Object.assign(window, UI);
window.qrcode = qrcode;          // used by the UPI QR helper
window.MilkUI = UI;

(async function boot() {
  let changed = false;
  try { changed = await loadStateAsync(); } catch (e) {}   // IndexedDB (no 5 MB limit)
  try { UI.init(); } catch (e) { console.error('init failed', e); }
  if (changed) { try { UI.refreshAll(); } catch (e) {} }
})();
