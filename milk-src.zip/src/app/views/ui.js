/* views/ui.js — all screens & interactions (ES module) */
import { state, setState, saveState, defaultState, migrate, loadState, STORE_KEY } from '../lib/store.js';
import { t, LANG, T, setLangVar } from '../lib/i18n.js';
import { uid, $, esc, cur, money, money2, num, ymd, todayStr, monthStr, fmtDate, MONTHS, fmtMonth, DOW, shiftLbl, partyName, partyById, isSup, toast, shopName, avatarHtml, itemById, calcAmount, IDX, rebuildIndex, partyBalance, lastDay, rangeFor, inRange, isHoliday } from '../lib/helpers.js';
import { GROUPS, GMAP, REL } from '../registry.js';
import { vlist, resetVlist } from '../lib/virtual.js';

/* =====================================================================
   दूध हिसाब — Milk Manager  v11  (single-file, offline, Hindi + English)
   Modular "function folders" hub · multi-item customers (cow/buffalo) ·
   bulk monthly entry + holidays · milk card · bills (day/10/15/month) ·
   all-bills PDF · ledger · statements · payments · dues · reports ·
   stock · expenses · reminders · cloud backup · PIN · themes.
   All data stays on the device (localStorage).
   ===================================================================== */

function save(){ rebuildIndex(); saveState(); try{ scheduleAutoDriveBackup(); }catch(e){} }

/* ---------------- theme / lang ---------------- */
function applyTheme(){
  const h=document.documentElement;
  h.setAttribute('data-theme',state.settings.theme||'green');
  h.setAttribute('data-dark',state.settings.dark?'1':'0');
  const m=document.querySelector('meta[name=theme-color]');
  const colors={green:'#0f7b53',blue:'#1d6fb8',purple:'#7b3fb0',teal:'#0c7b7b'};
  if(m) m.setAttribute('content',colors[state.settings.theme]||'#0f7b53');
}
function setLang(l){ setLangVar(l); state.settings.lang=l; save(); applyStatic(); refreshAll(); }
function setTheme(th){ state.settings.theme=th; save(); applyTheme(); renderSettingsBits(); }
function toggleDark(){ state.settings.dark=!state.settings.dark; save(); applyTheme(); renderSettingsBits(); }
function toggleRound(){ state.settings.roundOff=!state.settings.roundOff; save(); renderSettingsBits(); }
function toggleAutoShift(){ state.settings.autoShift=!(state.settings.autoShift!==false); save(); renderSettingsBits(); toast(t('saved')); }
function togglePin(){
  if(state.settings.pin){ if(confirm(t('pin')+' — '+t('pin_off')+'?')){ state.settings.pin=''; save(); renderSettingsBits(); toast(t('pin_off')); } }
  else askNewPin();
}
function askNewPin(){ openModal(`
  <div class="sheet-head"><h2>${t('pin_set')}</h2><button class="x" onclick="closeModal()">✕</button></div>
  <div class="field"><label>${t('pin_set')}</label><input type="tel" inputmode="numeric" maxlength="4" id="np1" placeholder="••••" /></div>
  <div class="field"><label>${t('pin_again')}</label><input type="tel" inputmode="numeric" maxlength="4" id="np2" placeholder="••••" /></div>
  <button class="btn" onclick="saveNewPin()">${t('save')}</button>`); }
function saveNewPin(){
  const a=$('np1').value.trim(), b=$('np2').value.trim();
  if(!/^\d{4}$/.test(a)){ toast(t('pin_need4')); return; }
  if(a!==b){ toast(t('pin_mismatch')); return; }
  state.settings.pin=btoa(a); save(); closeModal(); renderSettingsBits(); toast(t('pin_on'));
}
let lockBuf='';
function showLock(){ lockBuf=''; $('lockTitle').textContent=t('lock_title'); renderLockDots(); $('lock').classList.add('on'); }
function renderLockDots(){ $('lockDots').innerHTML=[0,1,2,3].map(i=>`<i class="${i<lockBuf.length?'f':''}"></i>`).join(''); }
function lockPress(d){
  if(d==='del'){ lockBuf=lockBuf.slice(0,-1); renderLockDots(); return; }
  if(d==='ok'){ lockSubmit(); return; }
  if(lockBuf.length>=4) return; lockBuf+=d; renderLockDots();
  if(lockBuf.length===4) setTimeout(lockSubmit,120);
}
function lockSubmit(){
  if(btoa(lockBuf)===state.settings.pin){ $('lock').classList.remove('on'); }
  else { toast(t('lock_wrong')); lockBuf=''; renderLockDots(); }
}
function buildLockPad(){
  const keys=['1','2','3','4','5','6','7','8','9','del','0','ok'];
  $('lockPad').innerHTML=keys.map(k=>{ const lbl=k==='del'?'⌫':k==='ok'?t('unlock'):k;
    return `<button class="${k==='ok'?'ok':''}" onclick="lockPress('${k}')">${lbl}</button>`; }).join('');
}

/* ---------------- nav + modules ---------------- */
let uiPartyType='customer', uiRoute='', billPeriod='month', repType='month', curModule='';
let uiTab='home', navStack=[], navPos=-1, navSilent=false;
const MODULES=[
  {id:'bulk',       ic:'🧺', hi:'बल्क एंट्री',        en:'Bulk entry',        render:modBulk},
  {id:'bulkMonthly',ic:'🗓️', hi:'बल्क मासिक एंट्री',  en:'Bulk monthly entry',render:modBulkMonthly},
  {id:'holiday',    ic:'🎉', hi:'छुट्टी जोड़ें',      en:'Add holiday',       render:modHoliday},
  {id:'milkcard',   ic:'🥛', hi:'मिल्क कार्ड',        en:'Milk card',         render:modMilkCard, after:renderMilkCard},
  {id:'ledger',     ic:'📒', hi:'खाता (Ledger)',      en:'Ledger',            render:modLedger,   after:renderLedger},
  {id:'statement',  ic:'📄', hi:'मासिक स्टेटमेंट',    en:'Monthly statement', render:modStatement,after:renderStatement},
  {id:'payments',   ic:'💵', hi:'भुगतान',             en:'Payments',          render:modPayments, after:function(){renderPayments('d');}},
  {id:'dues',       ic:'⏳', hi:'बकाया व पेंडिंग',    en:'Dues & pending',    render:modDues,     after:renderDues},
  {id:'reports',    ic:'📊', hi:'रिपोर्ट',            en:'Reports',           render:modReports,  after:renderReports},
  {id:'pnl',        ic:'📈', hi:'लाभ-हानि',           en:'Profit & Loss',     render:modPnl,      after:function(){renderPnL('month');}},
  {id:'rate',       ic:'🏷️', hi:'रेट चार्ट',          en:'Rate chart',        render:modRate,     after:renderRateChart},
  {id:'stock',      ic:'📦', hi:'स्टॉक',              en:'Stock',             render:modStock,    after:renderStock},
  {id:'expenses',   ic:'💸', hi:'खर्च',               en:'Expenses',          render:modExpenses, after:renderExpenses},
  {id:'explog',     ic:'📋', hi:'खर्च बहीखाता',       en:'Expense ledger',    render:modExpLog},
  {id:'reminders',  ic:'🔔', hi:'रिमाइंडर',           en:'Reminders',         render:modReminders},
  {id:'backup',     ic:'☁️', hi:'बैकअप व डेटा',       en:'Backup & data',     render:modBackup,   after:function(){renderDataUsage();cloudStatus();}},
  {id:'account',    ic:'🔐', hi:'Google लॉगिन',       en:'Google login',      render:modAccount,  after:renderAccountBits},
  {id:'settings',   ic:'⚙️', hi:'सेटिंग',             en:'Settings',          render:modSettings, after:renderSettingsBits},
  {id:'register',   ic:'🗓️', hi:'डेली रजिस्टर',       en:'Daily register',    render:modRegister, after:renderRegister},
  {id:'drive',      ic:'☁️', hi:'Drive बैकअप',        en:'Drive backup',      render:modDrive,    after:renderDriveBits},
  {id:'datacheck',  ic:'✅', hi:'डेटा जाँच',           en:'Data check',        render:modDataCheck, after:renderDataCheck},
  {id:'calendar',   ic:'📅', hi:'कैलेंडर',            en:'Calendar',          render:modCalendar, after:renderCalendar},
  {id:'topcust',    ic:'🏆', hi:'टॉप ग्राहक',          en:'Top customers',     render:modTopCust,  after:function(){renderTopCust('month');}},
  {id:'routes',     ic:'🚚', hi:'रूट सारांश',          en:'Route summary',     render:modRoutes,   after:renderRoutes},
  {id:'wastage',    ic:'📉', hi:'वेस्टेज / नुकसान',    en:'Wastage / loss',    render:modWastage},
  {id:'animals',    ic:'🐄', hi:'पशु रजिस्टर',         en:'Cattle register',   render:modAnimals},
  {id:'calc',       ic:'🧮', hi:'कैलकुलेटर',           en:'Calculator',        render:modCalc},
  {id:'notes',      ic:'📝', hi:'नोट्स',               en:'Notes',             render:modNotes},
  {id:'bills',      ic:'🧾', hi:'बिल बनाएँ',          en:'Create bills',      jump:'bills'},
  {id:'bulkbill',   ic:'📤', hi:'बल्क बिल भेजें',     en:'Bulk send bills',   render:modBulkBill, after:renderBulkBill},
  {id:'compare',    ic:'📊', hi:'महीना तुलना',        en:'Month comparison',  render:modCompare,  after:renderCompare},
  {id:'delivery',   ic:'🚚', hi:'डिलीवरी शीट',        en:'Delivery sheet',    render:modDelivery, after:renderDelivery},
  {id:'quality',    ic:'🥛', hi:'गुणवत्ता (FAT)',     en:'Quality (FAT)',     render:modQuality,  after:function(){renderQuality('month');}},
  {id:'inactive',   ic:'😴', hi:'निष्क्रिय ग्राहक',    en:'Inactive customers',render:modInactive, after:renderInactive},
  {id:'loans',      ic:'💳', hi:'उधार / कर्ज़',        en:'Loans / credit',    render:modLoans},
  {id:'recurring',  ic:'🔁', hi:'आवर्ती खर्च',         en:'Recurring expenses',render:modRecurring},
  {id:'invoices',   ic:'🧾', hi:'इनवॉइस नंबर',        en:'Invoices',          render:modInvoices},
  {id:'staff',      ic:'👷', hi:'स्टाफ व मजदूरी',     en:'Staff & wages',     render:modStaff},
  {id:'trend',      ic:'📈', hi:'वार्षिक ट्रेंड',      en:'Yearly trend',      render:modTrend,    after:renderTrend},
  {id:'dayend',     ic:'🌙', hi:'दिन-अंत सारांश',     en:'Day-end summary',   render:modDayEnd,   after:renderDayEnd},
  {id:'budget',     ic:'💰', hi:'मासिक बजट',          en:'Monthly budget',    render:modBudget,   after:renderBudget},
  {id:'support',    ic:'🆘', hi:'सहायता',             en:'Help & support',    render:modSupport},
  {id:'legal',      ic:'📜', hi:'नियम व प्राइवेसी',    en:'Legal & privacy',   render:modLegal},
  {id:'help',       ic:'❓', hi:'मदद',                en:'Help',              render:modHelp},
  {id:'cashbook',   ic:'💵', hi:'दैनिक कैश बुक',     en:'Daily cash book',   render:modCashBook, after:renderCashBook},
  {id:'ahealth',    ic:'🩺', hi:'पशु स्वास्थ्य',      en:'Animal health',     render:modAHealth},
  {id:'aprod',      ic:'🥛', hi:'दूध उत्पादन (पशु)',  en:'Milk production',   render:modAProd,    after:renderAProd},
  {id:'avacc',      ic:'💊', hi:'टीका रिमाइंडर',      en:'Vaccine reminder',  render:modAVacc},
  {id:'feed',       ic:'🌾', hi:'चारा इन्वेंटरी',     en:'Feed inventory',    render:modFeed,     after:renderFeed},
  {id:'fat30',      ic:'📊', hi:'गुणवत्ता ट्रेंड',    en:'Quality trend',     render:modFat30,    after:renderFat30},
  {id:'wastpie',    ic:'📉', hi:'वेस्टेज विश्लेषण',   en:'Wastage analysis',  render:modWastPie,  after:renderWastPie},
  {id:'routemap',   ic:'📍', hi:'रूट मैप',            en:'Route map',         render:modRouteMap},
  {id:'perms',      ic:'🔐', hi:'परमिशन (अनुमतियाँ)',  en:'Permissions',       render:modPerms,    after:renderPerms},
  {id:'ai',         ic:'🤖', hi:'AI सहायक',           en:'AI assistant',      render:modAI},
  {id:'insights',   ic:'🔎', hi:'स्मार्ट इनसाइट्स',    en:'Smart insights',    render:modInsights, after:renderInsights},
  {id:'monthclose', ic:'📅', hi:'महीना बंद (हिसाब)',  en:'Month close',       render:modMonthClose,after:renderMonthClose},
];
function switchTab(tab){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  $('view-'+tab).classList.add('active');
  document.querySelectorAll('nav.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===(tab==='bills'?'more':tab)));
  $('fab').style.display=(tab==='home'||tab==='entries')?'grid':'none';
  window.scrollTo({top:0,behavior:'instant'});
  if(tab==='home') renderHome();
  if(tab==='search') renderSearch();
  if(tab==='entries') renderEntries();
  if(tab==='parties') renderParties();
  if(tab==='bills') renderBilling();
  if(tab==='more') renderHub();
  if(tab==='module'){ document.querySelectorAll('nav.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab==='more')); $('fab').style.display='none'; }
  uiTab=tab; try{ navPush(); }catch(e){} try{ updateBackState(); }catch(e){}
}
let _lpFired=false;
function hubTile(m){
  const fav=(state.settings.favs||[]).indexOf(m.id)>=0;
  return `<div class="tile" data-mid="${m.id}"><span class="ti">${m.ic}</span><span class="tt">${esc(LANG==='hi'?m.hi:m.en)}</span>${fav?'<span class="fav">★</span>':''}</div>`;
}
function hubHead(g, n, folded){
  return '<div class="hub-head" onclick="toggleGroup(\''+g.id+'\')"><span>'+g.ic+' '+esc(LANG==='hi'?g.hi:g.en)+'</span>'
    +'<span class="hcnt">'+n+'</span><span class="hcaret">'+(folded?'▶':'▼')+'</span></div>';
}
function renderHub(){
  if($('hubSearch')) $('hubSearch').placeholder=t('hub_search');
  if($('l-modHint')) $('l-modHint').textContent=t('hub_hint');
  const q=(($('hubSearch')&&$('hubSearch').value)||'').trim().toLowerCase();
  const hit=function(m){ if(!q) return true; return ((LANG==='hi'?m.hi:m.en)+' '+(LANG==='hi'?m.en:m.hi)).toLowerCase().indexOf(q)>=0; };
  const favs=(state.settings.favs||[]).map(function(id){ return MODULES.find(function(x){return x.id===id;}); }).filter(Boolean);
  const rec=(state.settings.recent||[]).map(function(id){ return MODULES.find(function(x){return x.id===id;}); }).filter(Boolean);
  let out='';
  if(!q && favs.length){
    out+='<div class="hub-group"><div class="hub-head"><span>'+t('favs')+'</span><span class="hcnt">'+favs.length+'</span><span class="hcaret"></span></div><div class="tiles">'+favs.map(hubTile).join('')+'</div></div>';
  }
  if(!q && rec.length){
    out+='<div class="hub-group"><div class="hub-head"><span>'+t('recent')+'</span><span class="hcnt">'+rec.length+'</span><span class="hcaret"></span></div><div class="tiles">'+rec.map(hubTile).join('')+'</div></div>';
  }
  if($('hubChips')) $('hubChips').innerHTML=GROUPS.map(function(g){
    const n=MODULES.filter(function(m){ return (GMAP[m.id]||'app')===g.id; }).length;
    return '<button class="hchip" onclick="hubJump(\''+g.id+'\')">'+g.ic+' '+esc(LANG==='hi'?g.hi:g.en)+' · '+n+'</button>';
  }).join('');
  GROUPS.forEach(function(g){
    const all=MODULES.filter(function(m){ return (GMAP[m.id]||'app')===g.id; });
    const items=all.filter(hit);
    if(!items.length) return;
    const folded=(state.settings.collapsed||[]).indexOf(g.id)>=0 && !q;
    out+='<div class="hub-group'+(folded?' folded':'')+'" id="g-'+g.id+'">'+hubHead(g,all.length,folded)+'<div class="tiles">'+items.map(hubTile).join('')+'</div></div>';
  });
  $('moduleTiles').innerHTML=out||('<div class="empty">'+t('no_data')+'</div>');
  bindHubTiles();
}
function bindHubTiles(){
  document.querySelectorAll('#moduleTiles .tile[data-mid]').forEach(function(el){
    const mid=el.getAttribute('data-mid');
    let timer=null;
    const fire=function(){ timer=null; _lpFired=true; toggleFav(mid); setTimeout(function(){ _lpFired=false; },700); };
    const down=function(){ if(timer) return; timer=setTimeout(fire,500); };
    const up=function(){ if(timer){ clearTimeout(timer); timer=null; } };
    el.addEventListener('touchstart',down,{passive:true});
    el.addEventListener('touchend',up);
    el.addEventListener('touchcancel',up);
    el.addEventListener('touchmove',up,{passive:true});
    el.addEventListener('mousedown',down);
    el.addEventListener('mouseup',up);
    el.addEventListener('mouseleave',up);
    el.addEventListener('click',function(e){
      if(_lpFired){ e.preventDefault(); e.stopPropagation(); return; }
      const m=MODULES.find(function(x){ return x.id===mid; });
      if(!m) return;
      if(m.jump) switchTab(m.jump); else openModule(m.id);
    });
  });
}
function toggleFav(id){
  const f=state.settings.favs||(state.settings.favs=[]);
  const i=f.indexOf(id);
  if(i>=0){ f.splice(i,1); toast(t('fav_off')); } else { f.push(id); toast(t('fav_on')); }
  save(); renderHub();
}
function toggleGroup(gid){
  const c=state.settings.collapsed||(state.settings.collapsed=[]);
  const i=c.indexOf(gid);
  if(i>=0) c.splice(i,1); else c.push(gid);
  save(); renderHub();
}
function hubJump(gid){
  const c=state.settings.collapsed||(state.settings.collapsed=[]);
  const i=c.indexOf(gid);
  if(i>=0){ c.splice(i,1); save(); renderHub(); }
  setTimeout(function(){ const el=document.getElementById('g-'+gid); if(el) el.scrollIntoView({behavior:'smooth',block:'start'}); }, 70);
}
function openModule(id){
  curModule=id; const m=MODULES.find(x=>x.id===id); if(!m) return;
  $('moduleTitle').textContent=m.ic+' '+(LANG==='hi'?m.hi:m.en);
  $('moduleBody').innerHTML=m.render()+relatedRow(id);
  try{ const r=state.settings.recent||(state.settings.recent=[]); const i=r.indexOf(id); if(i>=0) r.splice(i,1); r.unshift(id); if(r.length>6) r.length=6; save(); }catch(e){}
  if(m.after){ try{ m.after(); }catch(e){} }
  switchTab('module');
}
function closeModule(){ curModule=''; switchTab('more'); }
/* ---- clock + auto shift + back/forward navigation ---- */
function autoShift(){ return (new Date().getHours()<12)?'morning':'evening'; }
function tickClock(){
  const el=$('topClock'); if(!el) return;
  const d=new Date(); const p=n=>String(n).padStart(2,'0');
  el.textContent=p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());
  const w=$('entryWhen');
  if(w){ const sh=autoShift(); w.textContent='🕐 '+t('now_lbl')+' '+p(d.getHours())+':'+p(d.getMinutes())+' · '+(sh==='evening'?t('evening'):t('morning'))+' — '+t('entry_auto'); }
}
function navLoc(){ return curModule?('m:'+curModule):('t:'+uiTab); }
function navLabel(k){
  if(!k) return '';
  if(k.indexOf('m:')===0){ const m=MODULES.find(x=>x.id===k.slice(2)); return m?(m.ic+' '+(LANG==='hi'?m.hi:m.en)):''; }
  const tab=k.slice(2); const map={home:'tab_home',entries:'tab_entries',parties:'tab_parties',bills:'tab_bills',more:'tab_more',module:'tab_more'};
  return t(map[tab]||'tab_home');
}
function navPush(){ if(navSilent) return; const k=navLoc(); if(navStack[navPos]===k) return; navStack=navStack.slice(0,navPos+1); navStack.push(k); navPos=navStack.length-1; renderNavBtns(); }
function renderNavBtns(){ const b=$('navBack'), f=$('navFwd'); if(!b||!f) return; b.disabled=navPos<=0; f.disabled=navPos>=navStack.length-1; const l=$('navLbl'); if(l) l.textContent=navLabel(navStack[navPos]); }
function navApply(k){ navSilent=true; if(k.indexOf('m:')===0){ openModule(k.slice(2)); } else { curModule=''; switchTab(k.slice(2)); } navSilent=false; renderNavBtns(); }
function navBack(){ if(navPos>0){ navPos--; navApply(navStack[navPos]); } }
function navForward(){ if(navPos<navStack.length-1){ navPos++; navApply(navStack[navPos]); } }
function entryNav(dir){ const sel=$('f_party'); if(!sel) return; const list=state.parties.filter(p=>p.active!==false); if(!list.length) return; let i=list.findIndex(p=>p.id===sel.value); if(i<0) i=0; i=(i+dir+list.length)%list.length; sel.value=list[i].id; window._qtyAuto=false; onEntryParty(''); }
function shiftDay(dir){ const el=$('entryDate'); if(!el) return; const d=new Date((el.value||todayStr())+'T00:00:00'); d.setDate(d.getDate()+dir); el.value=ymd(d); renderEntries(); }
function jumpToday(){ const el=$('entryDate'); if(el){ el.value=todayStr(); renderEntries(); } }
function rerenderModule(){ if(curModule) { const m=MODULES.find(x=>x.id===curModule); if(m) $('moduleBody').innerHTML=m.render(); } }
function openModal(html){ $('sheet').innerHTML='<div class="handle"></div>'+html; $('modalBg').classList.add('on'); updateBackState(); }
function closeModal(){ $('modalBg').classList.remove('on'); updateBackState(); }

/* ================= HOME ================= */
function renderHome(){
  const today=todayStr(), m=monthStr();
  const tE=state.entries.filter(e=>e.date===today);
  const sale=tE.filter(e=>e.kind==='sale'), pur=tE.filter(e=>e.kind==='purchase');
  $('s-todaySale').innerHTML=num(sale.reduce((s,e)=>s+e.qty,0))+'<small>L</small> · '+money(sale.reduce((s,e)=>s+e.amount,0));
  $('s-todayPurchase').innerHTML=num(pur.reduce((s,e)=>s+e.qty,0))+'<small>L</small> · '+money(pur.reduce((s,e)=>s+e.amount,0));
  const mE=state.entries.filter(e=>e.date.startsWith(m));
  const mS=mE.filter(e=>e.kind==='sale').reduce((s,e)=>s+e.amount,0);
  const mP=mE.filter(e=>e.kind==='purchase').reduce((s,e)=>s+e.amount,0);
  const mX=state.expenses.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+x.amount,0);
  const mW=state.wastage.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+(x.value||0),0);
  $('s-monthProfit').textContent=money(mS-mP-mX-mW);
  $('s-receivable').textContent=money(state.parties.filter(p=>!isSup(p)).reduce((s,p)=>s+Math.max(0,partyBalance(p.id)),0));
  $('homeDateLbl').textContent=fmtDate(today);
  try{
    if($('heroDate')) $('heroDate').textContent=fmtDate(today);
    if($('heroBig')) $('heroBig').textContent=money(sale.reduce((s,e)=>s+e.amount,0));
    if($('heroLbl')) $('heroLbl').textContent=t('hero_today');
    const hM=state.entries.filter(e=>e.date===today&&e.kind==='sale'&&e.shift==='morning');
    const hE=state.entries.filter(e=>e.date===today&&e.kind==='sale'&&e.shift==='evening');
    if($('heroMorL')) $('heroMorL').textContent='🌅 '+t('morning');
    if($('heroEveL')) $('heroEveL').textContent='🌙 '+t('evening');
    if($('heroDueL')) $('heroDueL').textContent=t('hero_due');
    if($('heroMor')) $('heroMor').textContent=num(hM.reduce((s,e)=>s+e.qty,0))+' L · '+money(hM.reduce((s,e)=>s+e.amount,0));
    if($('heroEve')) $('heroEve').textContent=num(hE.reduce((s,e)=>s+e.qty,0))+' L · '+money(hE.reduce((s,e)=>s+e.amount,0));
    if($('heroDue')) $('heroDue').textContent=money(state.parties.filter(p=>!isSup(p)).reduce((s,p)=>s+Math.max(0,partyBalance(p.id)),0));
  }catch(e){}
  try{ renderSyncCard(); }catch(e){}
  renderChart(); renderLowStock(); renderTarget();
  const recent=tE.slice().sort((a,b)=>b.id.localeCompare(a.id));
  $('homeRecent').innerHTML=recent.length?recent.map(entryRow).join(''):'<div class="empty"><span class="big">🥛</span>'+t('no_entries_today')+'</div>';
  // today by customer
  const byC={}; sale.forEach(e=>{ const o=byC[e.partyId]||(byC[e.partyId]={q:0,a:0}); o.q+=e.qty; o.a+=e.amount; });
  const rows=Object.keys(byC).map(id=>({p:partyById(id),q:byC[id].q,a:byC[id].a})).filter(x=>x.p).sort((a,b)=>b.a-a.a);
  $('todayCustList').innerHTML=rows.length?rows.map(({p,q,a})=>`
    <div class="list-item" onclick="openBillDetail('${p.id}',rangeFor('day',todayStr()))">${avatarHtml(p)}
      <div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${num(q)} L</div></div>
      <div class="li-amt"><div class="a">${money(a)}</div></div></div>`).join(''):'<div class="empty">'+t('no_entries_today')+'</div>';
  const dues=state.parties.map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal>0.5).sort((a,b)=>b.bal-a.bal);
  $('homeDues').innerHTML=dues.length?dues.slice(0,10).map(({p,bal})=>`
      <div class="list-item" onclick="openBillDetail('${p.id}',rangeFor('month',todayStr()))">${avatarHtml(p)}
        <div class="li-main"><div class="t">${esc(p.name)}<span class="tag ${isSup(p)?'sup':''}">${isSup(p)?t('purchase'):t('sale')}</span></div><div class="s">${esc(p.phone||'')}</div></div>
        <div class="li-amt"><div class="b due">${money(bal)} ${isSup(p)?t('to_pay'):t('owes')}</div></div>
        ${p.phone?`<button class="btn wa xs" onclick="event.stopPropagation();waRemind('${p.id}')">🔔</button>`:''}</div>`).join('')
    :'<div class="empty"><span class="big">✅</span>'+t('no_dues')+'</div>';
  renderHighlights(); updateBell(); renderShiftCard();
}
function renderChart(){
  const days=[], now=new Date();
  for(let i=6;i>=0;i--){ const d=new Date(now); d.setDate(now.getDate()-i); days.push(d); }
  const vals=days.map(d=>{ const ds=ymd(d); return (IDX.date[ds]||{}).sale||0; });
  const max=Math.max(1,...vals);
  $('chart7').innerHTML=days.map((d,i)=>`<div class="bar ${i===6?'today':''}"><div class="b" style="height:${Math.max(4,Math.round(vals[i]/max*88))}%"></div><div class="d">${DOW[LANG][d.getDay()]}</div></div>`).join('');
}
function renderLowStock(){
  const low=state.items.filter(it=>it.min>0 && stockOf(it.id)<it.min);
  if(!low.length){ $('lowStockCard').style.display='none'; return; }
  $('lowStockCard').style.display='block';
  $('lowStockList').innerHTML=low.map(it=>`<div class="list-item"><div class="avatar" style="background:var(--red-l);color:var(--red)">📦</div>
    <div class="li-main"><div class="t">${esc(it.name)}</div><div class="s">${t('stock_qty')}: ${num(stockOf(it.id))} ${esc(it.unit||'')}</div></div>
    <div class="li-amt"><div class="b due">${t('low_stock')}</div></div></div>`).join('');
}
function renderTarget(){
  const tgt=state.settings.target||0, card=$('targetCard');
  if(!tgt){ card.style.display='none'; return; }
  card.style.display='block';
  const month=monthStr(); const sale=(state.entries.filter(e=>e.date.startsWith(month)&&e.kind==='sale').reduce((s,e)=>s+e.amount,0));
  const pct=Math.min(100,Math.round(sale/tgt*100));
  $('targetBar').style.width=pct+'%';
  $('targetTxt').textContent=sale>=tgt?('🎉 '+money(sale)):(money(sale)+' / '+money(tgt)+' ('+pct+'%)');
}
function entryRow(e){
  const p=partyById(e.partyId), sup=isSup(p), it=itemById(p,e.itemId);
  const itTag=it?`<span class="tag">${esc(it.name)}</span>`:'';
  const pend=(state.settings.driveAuto && !e.syncAt)?`<span class="tag pend" title="${t('sync_pending')}">⏳</span>`:'';
  const ph=(p&&p.phone)?p.phone:'';
  return `<div class="list-item">
    <div class="avatar ${sup?'sup':''}">${sup?'🚚':'🥛'}</div>
    <div class="li-main" onclick="openEntry('${e.id}')">
      <div class="t">${esc(partyName(e.partyId))}<span class="tag ${e.shift==='evening'?'eve':''}">${shiftLbl(e.shift)}</span>${itTag}<span class="tag ${sup?'sup':''}">${sup?t('purchase'):t('sale')}</span>${pend}</div>
      <div class="s">${num(e.qty)} L${e.fat?' • '+t('fat_short')+' '+num(e.fat):''} • ${cur()}${num(e.rate)}/L</div>
    </div>
    <div class="li-amt" onclick="openEntry('${e.id}')"><div class="a">${money(e.amount)}</div></div>
    ${ph?`<button class="btn grey xs" onclick="event.stopPropagation();callParty('${p.id}')">📞</button><button class="btn wa xs" onclick="event.stopPropagation();waParty('${p.id}')">💬</button>`:''}
    <button class="btn grey xs" onclick="event.stopPropagation();openEntry('${e.id}')">✏️</button>
    <button class="btn danger xs" onclick="delEntry('${e.id}')">🗑</button>
  </div>`;
}

/* ================= ENTRIES ================= */
let uiShift='';
function setShift(s){ uiShift=s; renderShiftSeg(); renderEntries(); }
function renderShiftSeg(){ if(!$('shf-all')) return;
  $('shf-all').textContent=t('shift_all'); $('shf-m').textContent=t('morning'); $('shf-e').textContent=t('evening');
  $('shf-all').classList.toggle('on',uiShift===''); $('shf-m').classList.toggle('on',uiShift==='morning'); $('shf-e').classList.toggle('on',uiShift==='evening'); }
function openEntryShift(shift){ openEntry(); if($('f_shift')) $('f_shift').value=shift; }
function renderEntries(){
  const d=$('entryDate').value||todayStr();
  const q=($('entrySearch')?$('entrySearch').value:'').trim().toLowerCase();
  let list;
  if(q){ const m=d.slice(0,7); list=state.entries.filter(e=>e.date.startsWith(m)&&partyName(e.partyId).toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date)); }
  else list=state.entries.filter(e=>e.date===d).sort((a,b)=>a.shift.localeCompare(b.shift));
  if(uiShift) list=list.filter(e=>e.shift===uiShift);
  const box=$('entriesList');
  if(!list.length){ box.innerHTML='<div class="empty"><span class="big">📭</span>'+t('no_entries_date')+'</div>'; return; }
  const qty=list.reduce((s,e)=>s+e.qty,0), amt=list.reduce((s,e)=>s+e.amount,0);
  resetVlist(box);
  vlist(box, list, entryRow, { moreLabel: t('vmore') });   /* windowed: huge lists stay fast */
  box.insertAdjacentHTML('beforeend', `<div class="bill-line tot" style="margin-top:10px"><span class="k">${t('total')}</span><span class="v">${num(qty)} L • ${money(amt)}</span></div>`);
}
function delEntry(id){
  const rec=state.entries.find(e=>e.id===id); if(!rec) return;
  state.entries=state.entries.filter(e=>e.id!==id);
  save(); renderEntries(); renderHome(); rerenderModule();
  toast(t('deleted_undo'),t('undo'),()=>{ state.entries.push(rec); save(); renderEntries(); renderHome(); rerenderModule(); });
}
function entryItemOptions(p,sel){
  if(!p||!p.items||!p.items.length) return '';
  return p.items.map((i,idx)=>`<option value="${i.id}" ${(sel?sel===i.id:idx===0)?'selected':''}>${esc(i.name)}</option>`).join('');
}
function openEntry(id){
  const edit=id?state.entries.find(e=>e.id===id):null;
  if(!state.parties.length){ toast(t('add_party_first')); switchTab('parties'); openParty(); return; }
  const d=edit?edit.date:($('entryDate').value||todayStr());
  const defShift=edit?edit.shift:((state.settings.autoShift!==false)?autoShift():state.settings.defaultShift);
  window._qtyAuto=false;
  const first=edit?edit.partyId:state.parties[0].id;
  const opts=state.parties.filter(p=>p.active!==false).map(p=>`<option value="${p.id}" ${first===p.id?'selected':''}>${esc(p.name)} — ${isSup(p)?t('purchase'):t('sale')}</option>`).join('');
  openModal(`
    <div class="sheet-head"><h2>${edit?t('edit_entry'):t('new_entry')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('party_lbl')}</label><select id="f_party" onchange="onEntryParty()">${opts}</select></div>
    <div class="btn-row" style="margin:-4px 0 8px">
      <button class="btn grey sm" onclick="entryNav(-1)">◀ ${t('prev')}</button>
      <button class="btn grey sm" onclick="entryNav(1)">${t('next')} ▶</button>
    </div>
    <div class="field" id="f_itemWrap" style="display:none"><label>${t('item_lbl')}</label><select id="f_item" onchange="previewAmt()"></select></div>
    <div class="row2">
      <div class="field"><label>${t('date')}</label><input type="date" id="f_date" value="${d}" /></div>
      <div class="field"><label>${t('shift')}</label><select id="f_shift">
        <option value="morning" ${defShift!=='evening'?'selected':''}>${t('morning')}</option>
        <option value="evening" ${defShift==='evening'?'selected':''}>${t('evening')}</option></select></div>
    </div>
    ${edit?'':`<div class="hint" id="entryWhen" style="margin:-2px 0 8px"></div>`}
    <div class="field" style="margin-bottom:8px"><label>${t('quick_qty')}</label><div class="chips">${[0.5,1,1.5,2,2.5,3,4,5].map(v=>`<span class="chip" onclick="setQty(${v})">${v}</span>`).join('')}</div></div>
    <div class="row2">
      <div class="field"><label>${t('qty')}</label><input type="number" step="0.01" inputmode="decimal" id="f_qty" value="${edit?edit.qty:''}" placeholder="${t('qty_ph')}" oninput="previewAmt()" /></div>
      <div class="field"><label>${t('fat')}</label><input type="number" step="0.1" inputmode="decimal" id="f_fat" value="${edit&&edit.fat?edit.fat:''}" placeholder="${t('fat_ph')}" oninput="previewAmt()" /></div>
    </div>
    <div class="field"><label>${t('rate_optional')}</label><input type="number" step="0.01" inputmode="decimal" id="f_rate" value="${edit?edit.rate:''}" placeholder="auto" oninput="previewAmt()" /></div>
    <div class="amt-preview"><span class="k">${t('total_amount')}</span><span class="v" id="f_amt">${cur()}0</span></div>
    <div class="btn-row">
      ${edit?`<button class="btn danger" onclick="delEntry('${edit.id}');closeModal()">${t('del')}</button>`:''}
      <button class="btn" onclick="saveEntry(${edit?"'"+edit.id+"'":'null'})">${t('save')}</button>
    </div>`);
  onEntryParty(edit?edit.itemId:'');
  try{ tickClock(); }catch(e){}
}
function onEntryParty(itemSel){
  const p=partyById($('f_party').value), q=$('f_qty');
  const iw=$('f_itemWrap'), is=$('f_item');
  if(p&&p.items&&p.items.length){ iw.style.display='block'; is.innerHTML=entryItemOptions(p,itemSel); }
  else { iw.style.display='none'; }
  if(q&&(window._qtyAuto||!q.value)){ if(p&&p.defaultQty){ q.value=p.defaultQty; window._qtyAuto=true; } else if(window._qtyAuto){ q.value=''; window._qtyAuto=false; } }
  previewAmt();
}
function setQty(v){ const el=$('f_qty'); if(el){ el.value=v; window._qtyAuto=false; previewAmt(); } }
function previewAmt(){
  const p=partyById($('f_party').value);
  const itemId=($('f_item')&&$('f_itemWrap').style.display!=='none')?$('f_item').value:'';
  const r=calcAmount(p,$('f_qty').value,$('f_fat').value,itemId,$('f_rate').value);
  $('f_amt').textContent=money2(r.amount);
}
function saveEntry(id){
  const partyId=$('f_party').value, p=partyById(partyId);
  const date=$('f_date').value||todayStr(), shift=$('f_shift').value;
  const itemId=($('f_item')&&$('f_itemWrap').style.display!=='none')?$('f_item').value:'';
  const qty=parseFloat($('f_qty').value), fat=parseFloat($('f_fat').value)||0;
  if(!qty||qty<=0){ toast(t('enter_qty')); return; }
  const r=calcAmount(p,qty,fat,itemId,$('f_rate').value);
  const rec={id:id||uid(),date,partyId,itemId,kind:isSup(p)?'purchase':'sale',shift,qty,fat,rate:r.rate,amount:r.amount};
  const dup=state.entries.find(e=>e.partyId===partyId&&e.date===date&&e.shift===shift&&(e.itemId||'')===(itemId||'')&&e.id!==(id||''));
  if(dup){ if(!confirm(t('dup_warn'))) return; state.entries=state.entries.filter(e=>e.id!==dup.id); }
  if(id) state.entries[state.entries.findIndex(e=>e.id===id)]=rec; else state.entries.push(rec);
  save(); closeModal(); toast(id?t('entry_updated'):t('entry_saved'));
  renderEntries(); renderHome(); rerenderModule();
}
function openBulk(){
  let custs=state.parties.filter(p=>p.type==='customer'&&p.active!==false);
  if(!custs.length){ toast(t('no_customers')); return; }
  const routes=[...new Set(custs.map(c=>c.route).filter(Boolean))];
  const rf=window._bulkRoute||'';
  if(rf) custs=custs.filter(c=>c.route===rf);
  const rows=custs.map(c=>`<div class="list-item" style="padding:8px 0">
      <div class="li-main"><div class="t">${esc(c.name)}</div><div class="s">${c.rateType==='fat'?cur()+num(c.rate)+t('rate_per_f'):cur()+num(c.rate)+t('rate_per_l')}</div></div>
      <input type="number" step="0.01" inputmode="decimal" id="bk_${c.id}" value="${c.defaultQty?c.defaultQty:''}" placeholder="0" style="width:92px;padding:9px;border:1.5px solid var(--line);border-radius:10px;background:var(--card);text-align:right" /></div>`).join('');
  openModal(`
    <div class="sheet-head"><h2>${t('bulk_entry')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="margin-bottom:10px">${t('bulk_hint')}</div>
    ${routes.length?`<div class="field"><label>${t('route_filter')}</label><select id="bk_route" onchange="window._bulkRoute=this.value;openBulk()"><option value="">${t('all_routes')}</option>${routes.map(r=>`<option ${rf===r?'selected':''}>${esc(r)}</option>`).join('')}</select></div>`:''}
    <div class="row2">
      <div class="field"><label>${t('date')}</label><input type="date" id="bk_date" value="${($('entryDate')?$('entryDate').value:'')||todayStr()}" /></div>
      <div class="field"><label>${t('shift')}</label><select id="bk_shift">
        <option value="morning" ${state.settings.defaultShift!=='evening'?'selected':''}>${t('morning')}</option>
        <option value="evening" ${state.settings.defaultShift==='evening'?'selected':''}>${t('evening')}</option></select></div>
    </div>
    <div class="field"><label>${t('bulk_rate')}</label><input type="number" step="0.01" inputmode="decimal" id="bk_rate" placeholder="auto" /></div>
    <div class="divider"></div>${rows}
    <button class="btn" style="margin-top:14px" onclick="saveBulk()">${t('bulk_save')}</button>`);
}
function saveBulk(){
  const date=$('bk_date').value||todayStr(), shift=$('bk_shift').value, rate=$('bk_rate').value; let n=0;
  state.parties.filter(p=>p.type==='customer'&&p.active!==false).forEach(c=>{
    const el=$('bk_'+c.id); if(!el) return; const qty=parseFloat(el.value); if(!qty||qty<=0) return;
    const r=calcAmount(c,qty,0,'',rate);
    state.entries.push({id:uid(),date,partyId:c.id,itemId:'',kind:'sale',shift,qty,fat:0,rate:r.rate,amount:r.amount}); n++;
  });
  if(!n){ toast(t('bulk_none')); return; }
  save(); closeModal(); toast(n+' × '+t('bulk_saved')); renderEntries(); renderHome(); rerenderModule();
}
function autoDefaultEntries(){
  const today=$('entryDate').value||todayStr();
  const shift=state.settings.defaultShift||'morning';
  const cand=state.parties.filter(p=>p.type==='customer'&&p.active!==false&&p.defaultQty>0);
  if(!cand.length){ toast(t('auto_default_none')); return; }
  const todo=cand.filter(c=>!state.entries.some(e=>e.partyId===c.id&&e.date===today));
  if(!todo.length){ toast(t('bulk_none')); return; }
  if(!confirm(t('auto_default_confirm').replace('{n}',todo.length))) return;
  todo.forEach(c=>{ const r=calcAmount(c,c.defaultQty,0,'',''); state.entries.push({id:uid(),date:today,partyId:c.id,itemId:'',kind:'sale',shift,qty:c.defaultQty,fat:0,rate:r.rate,amount:r.amount}); });
  save(); renderEntries(); renderHome(); rerenderModule(); toast(todo.length+' × '+t('auto_default_done'));
}
function copyPrevDay(){
  const sel=$('entryDate').value||todayStr();
  const dates=[...new Set(state.entries.map(e=>e.date))].filter(d=>d<sel).sort();
  if(!dates.length){ toast(t('no_entries_today')); return; }
  const src=dates[dates.length-1]; const srcEntries=state.entries.filter(e=>e.date===src);
  if(!srcEntries.length){ toast(t('no_entries_today')); return; }
  if(state.entries.some(e=>e.date===sel) && !confirm(t('c_load_backup'))) return;
  srcEntries.forEach(e=>{ state.entries.push({...e, id:uid(), date:sel}); });
  save(); renderEntries(); renderHome(); toast(srcEntries.length+' × '+t('entry_saved'));
}
function shareTodaySummary(){
  const today=$('entryDate').value||todayStr();
  const e=state.entries.filter(x=>x.date===today);
  const sale=e.filter(x=>x.kind==='sale'), pur=e.filter(x=>x.kind==='purchase');
  const txt='🥛 '+shopName()+'\n'+t('summary_today')+' — '+fmtDate(today)+'\n────────────\n'
    +t('sale')+': '+num(sale.reduce((s,x)=>s+x.qty,0))+' L • '+money(sale.reduce((s,x)=>s+x.amount,0))+'\n'
    +t('purchase')+': '+num(pur.reduce((s,x)=>s+x.qty,0))+' L • '+money(pur.reduce((s,x)=>s+x.amount,0))+'\n'
    +t('entry_count')+': '+e.length+'\n────────────\n'+t('thank');
  if(navigator.share) navigator.share({title:t('summary_today'),text:txt}).catch(()=>{});
  else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(()=>{}); toast(t('copied')); }
}

/* ================= PARTIES ================= */
function setPartyType(tp){ uiPartyType=tp; uiRoute=''; renderParties(); }
function setRoute(r){ uiRoute=r; renderParties(); }
function renderRouteChips(){
  const el=$('routeChips'); if(!el) return;
  const routes=[...new Set(state.parties.filter(p=>p.type===uiPartyType).map(p=>p.route).filter(Boolean))];
  el.innerHTML=routes.length?`<span class="chip ${uiRoute===''?'on':''}" onclick="setRoute('')">${t('all_routes')}</span>`
    +routes.map(r=>`<span class="chip ${uiRoute===r?'on':''}" onclick='setRoute(${JSON.stringify(r)})'>${esc(r)}</span>`).join(''):'';
}
function renderParties(){
  $('seg-cust').classList.toggle('on',uiPartyType==='customer');
  $('seg-sup').classList.toggle('on',uiPartyType==='supplier');
  $('b-addParty').textContent=uiPartyType==='supplier'?t('add_farmer'):t('add_customer');
  renderRouteChips();
  const q=($('partySearch').value||'').trim().toLowerCase();
  let list=state.parties.filter(p=>p.type===uiPartyType);
  if(uiRoute) list=list.filter(p=>p.route===uiRoute);
  if(q) list=list.filter(p=>(p.name||'').toLowerCase().includes(q)||(p.phone||'').includes(q));
  list.sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  const box=$('partiesList');
  if(!list.length){ box.innerHTML='<div class="empty"><span class="big">👥</span>'+(state.parties.filter(p=>p.type===uiPartyType).length?t('no_match'):t('no_parties'))+'</div>'; return; }
  box.innerHTML=list.map(p=>{
    const bal=partyBalance(p.id);
    const rateTxt=p.rateType==='fat'?`${cur()}${num(p.rate)}${t('rate_per_f')}`:`${cur()}${num(p.rate)}${t('rate_per_l')}`;
    return `<div class="list-item">
      <div onclick="openParty('${p.id}')">${avatarHtml(p)}</div>
      <div class="li-main" onclick="openParty('${p.id}')"><div class="t">${esc(p.name)}${p.defaultQty?'<span class="tag">'+num(p.defaultQty)+' L</span>':''}</div><div class="s">${rateTxt}${p.route?' • '+esc(p.route):''}${p.phone?' • 📞 '+esc(p.phone):''}</div></div>
      <div class="li-amt" onclick="openBillDetail('${p.id}',rangeFor('month',todayStr()))"><div class="b ${bal>0.5?'due':'ok'}">${bal>0.5?money(bal)+' '+t('owes'):t('clean')}</div></div>
      <button class="btn grey xs" onclick="event.stopPropagation();openBillDetail('${p.id}',rangeFor('month',todayStr()))">🧾</button>
      <button class="btn grey xs" onclick="event.stopPropagation();openParty('${p.id}')">✏️</button>
      ${p.phone?`<button class="btn wa xs" onclick="event.stopPropagation();waRemind('${p.id}')">🔔</button>`:''}
      <button class="btn danger xs" onclick="event.stopPropagation();delParty('${p.id}')">🗑</button>
    </div>`;
  }).join('');
}
function openParty(id){
  const edit=id?partyById(id):null, type=edit?edit.type:uiPartyType;
  const title=type==='supplier'?(edit?t('edit_farmer'):t('new_farmer')):(edit?t('edit_customer'):t('new_customer'));
  window._photo=edit?(edit.photo||''):'';
  window._items=edit?JSON.parse(JSON.stringify(edit.items||[])):[];
  openModal(`
    <div class="sheet-head"><h2>${title}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="photo-edit">
      <div id="photoBox">${edit?avatarHtml(edit,'lg'):'<div class="avatar lg">?</div>'}</div>
      <div class="btn-row" style="width:100%">
        <button class="btn grey sm" style="flex:1" onclick="pickPhoto()" id="b-photo">${edit&&edit.photo?t('photo_change'):t('photo_add')}</button>
        <button class="btn grey sm" style="flex:1" onclick="pickContactJs()" id="b-contact">${t('pick_contact')}</button>
      </div>
    </div>
    <div class="field"><label>${t('name')}</label><input type="text" id="c_name" value="${edit?esc(edit.name):''}" placeholder="${t('name_ph')}" /></div>
    <div class="field"><label>${t('phone')}</label><input type="tel" inputmode="tel" id="c_phone" value="${edit?esc(edit.phone||''):''}" placeholder="${t('phone_ph')}" /></div>
    <div class="row2">
      <div class="field"><label>${t('default_qty')}</label><input type="number" step="0.01" inputmode="decimal" id="c_defqty" value="${edit?(edit.defaultQty||0):0}" /></div>
      <div class="field"><label>${t('route')}</label><input type="text" id="c_route" value="${edit?esc(edit.route||''):''}" placeholder="${t('route_ph')}" /></div>
    </div>
    <div class="field"><label>${t('rate_type')}</label><select id="c_rateType" onchange="toggleRateLabel()">
        <option value="liter" ${!edit||edit.rateType==='liter'?'selected':''}>${t('per_liter')}</option>
        <option value="fat" ${edit&&edit.rateType==='fat'?'selected':''}>${t('per_fat')}</option></select></div>
    <div class="field"><label id="c_rateLbl">${t('rate_l')}</label><input type="number" step="0.01" inputmode="decimal" id="c_rate" value="${edit?edit.rate:state.settings.defaultRate}" /></div>
    <div class="field"><label>${t('opening')}</label><input type="number" step="0.01" inputmode="decimal" id="c_opening" value="${edit?(edit.opening||0):0}" /></div>
    <div class="field"><label>${t('items_lbl')}</label><div id="itemsList"></div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <input type="text" id="newItemName" placeholder="${t('item_ph')}" style="flex:2" />
        <input type="number" step="0.01" inputmode="decimal" id="newItemRate" placeholder="${t('rate_l')}" style="flex:1" />
        <button class="btn ghost sm" onclick="addPartyItem()">➕</button>
      </div>
      <div class="hint">${t('no_items')}</div>
    </div>
    <div class="btn-row">
      ${edit?`<button class="btn danger" onclick="delParty('${edit.id}')">${t('del')}</button>`:''}
      <button class="btn" onclick="saveParty(${edit?"'"+edit.id+"'":'null'},'${type}')">${t('save')}</button>
    </div>`);
  toggleRateLabel(); renderPartyItems();
}
function renderPartyItems(){
  const el=$('itemsList'); if(!el) return;
  el.innerHTML=(window._items||[]).map(i=>`<div class="list-item" style="padding:8px 0">
    <div class="li-main"><div class="t">${esc(i.name)}</div><div class="s">${cur()}${num(i.rate)}${i.rateType==='fat'?t('rate_per_f'):t('rate_per_l')}</div></div>
    <button class="btn danger xs" onclick="delPartyItem('${i.id}')">🗑</button></div>`).join('')||'';
}
function addPartyItem(){
  const n=$('newItemName').value.trim(), r=parseFloat($('newItemRate').value)||0;
  if(!n){ toast(t('enter_name')); return; }
  window._items=window._items||[]; window._items.push({id:uid(),name:n,rateType:'liter',rate:r});
  $('newItemName').value=''; $('newItemRate').value=''; renderPartyItems();
}
function delPartyItem(id){ window._items=(window._items||[]).filter(i=>i.id!==id); renderPartyItems(); }
function toggleRateLabel(){ $('c_rateLbl').textContent=$('c_rateType').value==='fat'?t('rate_f'):t('rate_l'); }
function pickPhoto(){
  const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*';
  inp.onchange=()=>{ const f=inp.files[0]; if(!f) return; shrink(f,200,d=>{ window._photo=d; $('photoBox').innerHTML=`<div class="avatar lg" style="background-image:url('${d}')"></div>`; }); };
  inp.click();
}
function shrink(file,max,cb){
  const r=new FileReader();
  r.onload=()=>{ const img=new Image(); img.onload=()=>{ const s=Math.min(1,max/Math.max(img.width,img.height));
      const c=document.createElement('canvas'); c.width=Math.round(img.width*s); c.height=Math.round(img.height*s);
      c.getContext('2d').drawImage(img,0,0,c.width,c.height); cb(c.toDataURL('image/jpeg',0.75)); }; img.src=r.result; };
  r.readAsDataURL(file);
}
function saveParty(id,type){
  const name=$('c_name').value.trim(); if(!name){ toast(t('enter_name')); return; }
  const rec={id:id||uid(),name,phone:$('c_phone').value.trim(),address:'',type,
    rateType:$('c_rateType').value,rate:parseFloat($('c_rate').value)||0,opening:parseFloat($('c_opening').value)||0,active:true,photo:window._photo||'',
    defaultQty:parseFloat($('c_defqty')?$('c_defqty').value:0)||0, route:($('c_route')?$('c_route').value.trim():''),
    items:window._items||[]};
  if(id){ const i=state.parties.findIndex(p=>p.id===id); rec.active=state.parties[i].active!==false; rec.address=state.parties[i].address||''; state.parties[i]=rec; }
  else state.parties.push(rec);
  save(); closeModal(); toast(id?t('party_updated'):t('party_added'));
  renderParties(); renderHome(); rerenderModule();
}
function delParty(id){
  const has=state.entries.some(e=>e.partyId===id)||state.payments.some(p=>p.partyId===id);
  if(has&&!confirm(t('c_del_party_entries'))) return;
  if(!has&&!confirm(t('c_del'))) return;
  state.parties=state.parties.filter(p=>p.id!==id);
  state.entries=state.entries.filter(e=>e.partyId!==id);
  state.payments=state.payments.filter(p=>p.partyId!==id);
  save(); closeModal(); toast(t('party_deleted'));
  renderParties(); renderHome(); rerenderModule();
}

/* ================= BILLING ================= */
function setBillPeriod(p){ billPeriod=p; renderBilling(); }
function renderBilling(){
  if(!$('billAnchor').value) $('billAnchor').value=todayStr();
  ['day','d10','d15','month'].forEach(p=>{ const el=$('per-'+p); if(el) el.classList.toggle('on',p===billPeriod); });
  const r=rangeFor(billPeriod,$('billAnchor').value);
  $('billPeriodLbl').textContent=r.label;
  const e=state.entries.filter(x=>inRange(x.date,r.start,r.end));
  const pays=state.payments.filter(x=>inRange(x.date,r.start,r.end));
  const sale=e.filter(x=>x.kind==='sale'), pur=e.filter(x=>x.kind==='purchase');
  const qty=sale.reduce((s,x)=>s+x.qty,0), saleAmt=sale.reduce((s,x)=>s+x.amount,0);
  const purAmt=pur.reduce((s,x)=>s+x.amount,0), paid=pays.reduce((s,x)=>s+x.amount,0);
  $('bs-qty').textContent=num(qty)+' L'; $('bs-sale').textContent=money(saleAmt);
  $('bs-purch').textContent=money(purAmt); $('bs-paid').textContent=money(paid); $('bs-due').textContent=money(saleAmt-paid);
  const parties=state.parties.filter(p=>p.type==='customer');
  const bills=parties.map(p=>{
    const pe=e.filter(x=>x.partyId===p.id);
    const q=pe.reduce((s,x)=>s+x.qty,0), amt=pe.reduce((s,x)=>s+x.amount,0);
    const pd=pays.filter(x=>x.partyId===p.id).reduce((s,x)=>s+x.amount,0);
    return {p,q,amt,pd,due:amt-pd};
  }).filter(b=>b.q||b.amt||b.pd).sort((a,b)=>b.due-a.due);
  $('billingList').innerHTML=bills.length?bills.map(b=>`
    <div class="list-item" onclick="openBillDetail('${b.p.id}',rangeFor(billPeriod,document.getElementById('billAnchor').value))">
      ${avatarHtml(b.p)}<div class="li-main"><div class="t">${esc(b.p.name)}</div><div class="s">${num(b.q)} L • ${money(b.amt)}</div></div>
      <div class="li-amt"><div class="a">${money(b.due)}</div><div class="b ${b.due>0.5?'due':'ok'}">${b.due>0.5?t('remaining'):t('clean')}</div></div></div>`).join('')
    :'<div class="empty">'+t('no_data')+'</div>';
}
function openBillDetail(id,r){
  const p=partyById(id), sup=isSup(p); r=r||rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const e=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).sort((a,b)=>a.date.localeCompare(b.date));
  const pays=state.payments.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).sort((a,b)=>b.date.localeCompare(a.date));
  const qty=e.reduce((s,x)=>s+x.qty,0), billed=e.reduce((s,x)=>s+x.amount,0);
  const paid=pays.reduce((s,x)=>s+x.amount,0), due=billed-paid;
  openModal(`
    <div class="sheet-head"><h2>🧾 ${esc(p.name)}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="margin-bottom:10px">${r.label} · ${sup?t('purchase'):t('sale')}</div>
    <div class="bill-box">
      <div class="bill-line"><span class="k">${t('entry_count')}</span><span class="v">${e.length}</span></div>
      <div class="bill-line"><span class="k">${t('total_milk')}</span><span class="v">${num(qty)} ${t('litres')}</span></div>
      <div class="bill-line"><span class="k">${sup?t('total_purchase'):t('total_bill')}</span><span class="v">${money2(billed)}</span></div>
      <div class="bill-line"><span class="k">${t('paid_month')}</span><span class="v">${money2(paid)}</span></div>
      <div class="bill-line tot"><span class="k">${due>=0?t('remaining'):t('advance')}</span><span class="v">${money2(Math.abs(due))}</span></div>
    </div>
    <div class="divider"></div>
    <div class="bill-line"><span class="k">${t('total_outstanding')}</span><span class="v"><b>${money2(partyBalance(id))}</b></span></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn" onclick="openPayment('${id}')">${t('add_payment')}</button></div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn ghost" onclick="shareBill('${id}')">${t('send')}</button>
      <button class="btn ghost" onclick="printBill('${id}')">${t('print')}</button>
    </div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn ghost" onclick="billView('${id}')">👁️ ${t('bill_view')}</button>
      <button class="btn ghost" onclick="billDownload('${id}')">⬇️ ${t('bill_dl')}</button>
    </div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn wa" onclick="billWhatsApp('${id}')">💬 ${t('bill_wa')}</button>
      <button class="btn grey" onclick="shareBillPdf('${id}')">📤 ${t('share_pdf')}</button>
    </div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn grey" onclick="shareBillLink('${id}')">${t('share_link')}</button>
    </div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn grey" onclick="showUpiQr('${id}')">${t('upi_qr')}</button>
      <button class="btn grey" onclick="openLedgerFor('${id}')">${t('ledger')}</button>
    </div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn wa" onclick="waRemind('${id}')">${t('wa_remind')}</button>
      <button class="btn sms" onclick="smsRemind('${id}')">${t('sms_remind')}</button>
    </div>
    <div class="divider"></div>
    <h3 style="font-size:14px;font-weight:700;margin-bottom:6px">${t('month_entries')}</h3>
    ${e.length?e.map(x=>`<div class="list-item"><div class="li-main"><div class="t">${fmtDate(x.date)} <span class="tag ${x.shift==='evening'?'eve':''}">${shiftLbl(x.shift)}</span>${itemById(p,x.itemId)?'<span class="tag">'+esc(itemById(p,x.itemId).name)+'</span>':''}</div>
      <div class="s">${num(x.qty)} L${x.fat?' • '+t('fat_short')+' '+num(x.fat):''} • ${cur()}${num(x.rate)}/L</div></div>
      <div class="li-amt"><div class="a">${money(x.amount)}</div></div></div>`).join(''):'<div class="empty">'+t('no_month_entries')+'</div>'}
    <h3 style="font-size:14px;font-weight:700;margin:12px 0 6px">${t('payment_history')}</h3>
    ${pays.length?pays.map(x=>`<div class="list-item"><div class="avatar">💵</div>
      <div class="li-main"><div class="t">${fmtDate(x.date)}</div><div class="s">${esc(x.mode||'')}${x.note?' • '+esc(x.note):''}</div></div>
      <div class="li-amt"><div class="a">${money(x.amount)}</div></div>
      <button class="btn grey xs" onclick="editPayment('${x.id}')">✏️</button>
      <button class="btn danger xs" onclick="delPayment('${x.id}')">🗑</button></div>`).join(''):'<div class="empty">'+t('no_payments')+'</div>'}`);
}
function payStats(id){
  const billed=state.entries.filter(e=>e.partyId===id&&e.kind==='sale').reduce((s,e)=>s+e.amount,0);
  const pur=state.entries.filter(e=>e.partyId===id&&e.kind==='purchase').reduce((s,e)=>s+e.amount,0);
  const paid=state.payments.filter(p=>p.partyId===id).reduce((s,p)=>s+p.amount,0);
  return {billed:billed, pur:pur, paid:paid, bal:partyBalance(id)};
}
function openPayment(id){
  const st=payStats(id), due=Math.max(0,st.bal);
  openModal(`
    <div class="sheet-head"><h2>${t('payment_add')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('party_lbl')}</label><input type="text" value="${esc(partyName(id))}" disabled /></div>
    <div class="bill-box" style="margin-bottom:10px">
      <div class="bill-line"><span class="k">${t('pay_total_milk')}</span><span class="v">${money2(st.billed)}</span></div>
      <div class="bill-line"><span class="k">${t('pay_total_paid')}</span><span class="v">${money2(st.paid)}</span></div>
      <div class="bill-line tot"><span class="k">${t('pay_due_now')}</span><span class="v" style="color:${due>0.5?'var(--red)':'var(--green)'}">${money2(due)}</span></div>
    </div>
    <div class="field"><label>${t('date')}</label><input type="date" id="p_date" value="${todayStr()}" /></div>
    <div class="field"><label>${t('amount')}</label><input type="number" step="0.01" inputmode="decimal" id="p_amt" placeholder="${t('amount_ph')}" oninput="payPreview('${id}')" /></div>
    <div class="chips" style="margin:-4px 0 10px">
      ${due>0.5?`<button class="chip" onclick="payFill('${id}',${Math.round(due*100)/100})">${t('pay_full')} · ${money2(due)}</button>`:''}
      <button class="chip" onclick="payFill('${id}',0)">${t('clear_all_sel')}</button>
    </div>
    <div class="amt-preview" id="payAfter"><span>${t('pay_after')}</span><b id="payAfterVal">${money2(due)}</b></div>
    <div class="field"><label>${t('method')}</label><select id="p_mode"><option>${t('cash')}</option><option>${t('upi')}</option><option>${t('bank')}</option><option>${t('other')}</option></select></div>
    <div class="field"><label>${t('note')}</label><input type="text" id="p_note" placeholder="${t('note_ph')}" /></div>
    <button class="btn" onclick="savePayment('${id}')">${t('save_payment')}</button>`);
}
function payFill(id,amt){ const e=$('p_amt'); if(e){ e.value=amt>0?amt:''; payPreview(id); } }
function payPreview(id){
  const st=payStats(id); const amt=parseFloat(($('p_amt')||{}).value)||0; const after=st.bal-amt;
  const el=$('payAfterVal'); if(!el) return;
  el.textContent=money2(after);
  el.style.color=after>0.5?'var(--red)':(after<-0.5?'var(--blue)':'var(--green)');
}
function editPayment(id){
  const x=state.payments.find(p=>p.id===id); if(!x) return;
  openModal(`<div class="sheet-head"><h2>${t('pay_edit')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('party_lbl')}</label><input type="text" value="${esc(partyName(x.partyId))}" disabled /></div>
    <div class="field"><label>${t('date')}</label><input type="date" id="ep_date" value="${x.date}" /></div>
    <div class="field"><label>${t('amount')}</label><input type="number" step="0.01" inputmode="decimal" id="ep_amt" value="${x.amount}" /></div>
    <div class="field"><label>${t('method')}</label><input type="text" id="ep_mode" value="${esc(x.mode||'')}" /></div>
    <div class="field"><label>${t('note')}</label><input type="text" id="ep_note" value="${esc(x.note||'')}" /></div>
    <button class="btn" onclick="saveEditPayment('${id}')">${t('save')}</button>`);
}
function saveEditPayment(id){
  const x=state.payments.find(p=>p.id===id); if(!x) return;
  const amt=parseFloat($('ep_amt').value); if(!amt||amt<=0){ toast(t('enter_amount')); return; }
  x.date=$('ep_date').value||x.date; x.amount=amt; x.mode=$('ep_mode').value.trim(); x.note=$('ep_note').value.trim();
  save(); closeModal(); toast(t('saved')); renderBilling(); renderHome(); rerenderModule();
}
function savePayment(id){
  const amt=parseFloat($('p_amt').value); if(!amt||amt<=0){ toast(t('enter_amount')); return; }
  state.payments.push({id:uid(),partyId:id,date:$('p_date').value||todayStr(),amount:amt,mode:$('p_mode').value,note:$('p_note').value.trim()});
  save(); closeModal(); toast(t('payment_saved')); renderBilling(); renderHome(); rerenderModule();
}
function delPayment(id){
  const rec=state.payments.find(p=>p.id===id); if(!rec) return;
  state.payments=state.payments.filter(p=>p.id!==id);
  save(); renderBilling(); renderHome(); rerenderModule();
  toast(t('deleted_undo'),t('undo'),()=>{ state.payments.push(rec); save(); renderBilling(); renderHome(); rerenderModule(); });
}
function billText(id,r){
  const p=partyById(id), sup=isSup(p); r=r||rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const e=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end));
  const qty=e.reduce((s,x)=>s+x.qty,0), billed=e.reduce((s,x)=>s+x.amount,0);
  const paid=state.payments.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
  return `🥛 ${shopName()}\n${t('bill_title')} — ${p.name}\n${r.label}\n────────────\n${t('milk_word')}: ${num(qty)} ${t('litres')}\n${sup?t('total_purchase'):t('total_bill')}: ${money(billed)}\n${t('paid_month')}: ${money(paid)}\n${t('remaining')}: ${money(billed-paid)}\n${t('total_outstanding')}: ${money(partyBalance(id))}\n────────────\n${t('thank')}`;
}
function shareBill(id){
  const text=billText(id);
  if(navigator.share){ navigator.share({title:t('bill_title'),text}).catch(()=>{}); }
  else { if(navigator.clipboard) navigator.clipboard.writeText(text).catch(()=>{}); toast(t('copied')); }
}
function billRowsHtml(id,r){
  const p=partyById(id);
  const e=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).sort((a,b)=>a.date.localeCompare(b.date));
  return e.map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${shiftLbl(x.shift)}</td><td>${itemById(p,x.itemId)?esc(itemById(p,x.itemId).name):'-'}</td><td>${num(x.qty)}</td><td>${x.fat?num(x.fat):'-'}</td><td>${num(x.rate)}</td><td>${num(x.amount)}</td></tr>`).join('')
    ||`<tr><td colspan="7" style="text-align:center">${t('no_month_entries')}</td></tr>`;
}
function themeHex(){ return state.settings.theme==='blue'?'#1d6fb8':state.settings.theme==='purple'?'#7b3fb0':state.settings.theme==='teal'?'#0c7b7b':'#0f7b53'; }
function billPageCss(){ return `<style>body{font-family:Arial,'Noto Sans Devanagari',sans-serif;padding:22px;color:#111;max-width:680px;margin:auto}
  h1{font-size:20px;margin:0 0 2px}h2{font-size:14px;margin:0 0 12px;color:#555;font-weight:500}
  .hd{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid ${themeHex()};padding-bottom:10px;margin-bottom:14px}
  .co{font-size:12px;color:#555}table{width:100%;border-collapse:collapse;font-size:13px;margin-top:8px}
  th,td{border-bottom:1px solid #ddd;padding:6px;text-align:right}th:first-child,td:first-child,th:first-child+td,td:first-child+td{text-align:left}
  th{background:#f2f6f4;font-size:11px;text-transform:uppercase}
  .sum{margin-top:14px;font-size:14px;width:100%}.sum td{border:none;padding:4px 6px}.sum .b{font-weight:700;border-top:2px solid #111}
  .ft{margin-top:26px;font-size:12px;color:#666;text-align:center}</style>`; }
function billPageHtml(id,r){
  const p=partyById(id), sup=isSup(p), b=state.settings.business;
  const e=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end));
  const qty=e.reduce((s,x)=>s+x.qty,0), billed=e.reduce((s,x)=>s+x.amount,0);
  const paid=state.payments.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
  return `<div class="hd"><div><h1>${esc(shopName())}</h1><div class="co">${esc(b.owner||'')}${b.phone?' • '+esc(b.phone):''}${b.address?'<br>'+esc(b.address):''}</div>
      <h2>${t('bill_title')} — ${r.label}</h2></div>
      <div style="text-align:right;font-size:13px"><b>${esc(p.name)}</b><br>${esc(p.phone||'')}</div></div>
    <table><thead><tr><th>${t('date')}</th><th>${t('shift')}</th><th>${t('item_lbl')}</th><th>L</th><th>${t('fat_short')}</th><th>${cur()}/L</th><th>${cur()}</th></tr></thead><tbody>${billRowsHtml(id,r)}</tbody></table>
    <table class="sum">
      <tr><td>${t('total_milk')}</td><td style="text-align:right">${num(qty)} ${t('litres')}</td></tr>
      <tr><td>${sup?t('total_purchase'):t('total_bill')}</td><td style="text-align:right">${money(billed)}</td></tr>
      <tr><td>${t('paid_month')}</td><td style="text-align:right">${money(paid)}</td></tr>
      <tr class="b"><td>${t('remaining')}</td><td style="text-align:right">${money(billed-paid)}</td></tr>
      <tr><td>${t('total_outstanding')}</td><td style="text-align:right"><b>${money(partyBalance(id))}</b></td></tr>
    </table><div class="ft">${t('thank')}</div>`;
}
function printBill(id){
  const r=rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('bill_title')}</title>${billPageCss()}</head><body>${billPageHtml(id,r)}<script>setTimeout(function(){window.print();},350);<\/script></body></html>`);
  w.document.close();
}
function shareBillLink(id){
  const r=rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const html='<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+t('bill_title')+'</title>'+billPageCss()+'</head><body>'+billPageHtml(id,r)+'</body></html>';
  const p=partyById(id);
  const file=new File([html],'bill-'+((p&&p.name)||'party').replace(/\s+/g,'-')+'.html',{type:'text/html'});
  if(navigator.canShare&&navigator.canShare({files:[file]})){ navigator.share({files:[file],title:t('bill_title')}).catch(()=>{}); return; }
  download('bill-'+((p&&p.name)||'party').replace(/\s+/g,'-')+'.html', html, 'text/html'); toast(t('saved'));
}
function printAllStatements(){
  const month=$('billAnchor').value?$('billAnchor').value.slice(0,7):monthStr();
  const r=rangeFor('month',month+'-01');
  const list=state.parties.filter(p=>p.type==='customer');
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('bill_title')}</title>${billPageCss()}</head><body>${list.map(p=>`<div style="page-break-after:always">${billPageHtml(p.id,r)}</div>`).join('')}<script>setTimeout(function(){window.print();},500);<\/script></body></html>`);
  w.document.close();
}

/* ---------- ALL BILLS PDF ---------- */
function dataUrlToBytes(u){ const b=atob(u.split(',')[1]); const a=new Uint8Array(b.length); for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i); return a; }
function buildPdfMulti(pages){
  const enc=s=>{ const a=new Uint8Array(s.length); for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i)&0xff; return a; };
  const parts=[],offsets=[]; let pos=0;
  const push=u8=>{ parts.push(u8); pos+=u8.length; }; const ps=s=>push(enc(s));
  ps('%PDF-1.4\n');
  const obj=(n,body,stream)=>{ offsets[n]=pos; ps(n+' 0 obj\n'+body+'\n'); if(stream){ ps('stream\n'); push(stream); ps('\nendstream\n'); } ps('endobj\n'); };
  const N=pages.length;
  obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
  const kids=[]; for(let i=0;i<N;i++) kids.push((3+i*3)+' 0 R');
  obj(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+N+' >>');
  for(let i=0;i<N;i++){
    const pg=pages[i], pageObj=3+i*3, imgObj=pageObj+1, contObj=pageObj+2;
    obj(pageObj,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+pg.w+' '+pg.h+'] /Resources << /XObject << /Im0 '+imgObj+' 0 R >> >> /Contents '+contObj+' 0 R >>');
    obj(imgObj,'<< /Type /XObject /Subtype /Image /Width '+pg.iw+' /Height '+pg.ih+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+pg.bytes.length+' >>',pg.bytes);
    const content=enc('q '+pg.w+' 0 0 '+pg.h+' 0 0 cm /Im0 Do Q');
    obj(contObj,'<< /Length '+content.length+' >>',content);
  }
  const total=N*3+3;
  const xref=pos; let x='xref\n0 '+total+'\n0000000000 65535 f \n';
  for(let i=1;i<total;i++) x+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';
  x+='trailer\n<< /Size '+total+' /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF'; ps(x);
  const totalLen=parts.reduce((s,p)=>s+p.length,0); const out=new Uint8Array(totalLen); let o=0; parts.forEach(p=>{ out.set(p,o); o+=p.length; }); return out;
}
const BILL_LBL={
  hi:{title:'बिल',date:'तारीख',shift:'समय',litres:'लीटर',rate:'रेट',amount:'रकम',totalMilk:'कुल दूध',totalBill:'कुल बिल',paid:'जमा',remaining:'बाकी',outstanding:'कुल बकाया'},
  en:{title:'Bill',date:'Date',shift:'Shift',litres:'Litres',rate:'Rate',amount:'Amount',totalMilk:'Total milk',totalBill:'Total bill',paid:'Paid',remaining:'Remaining',outstanding:'Total due'}
};
function bl(k){ const lang=state.settings.billLang||(LANG==='en'?'en':'hi'); return (BILL_LBL[lang]||BILL_LBL.hi)[k]||k; }
function billAccent(){ const c=state.settings.billColor; if(c==='green') return '#0f7b53'; if(c==='blue') return '#1d6fb8'; if(c==='purple') return '#7b3fb0'; if(c==='teal') return '#0c7b7b'; if(c==='maroon') return '#8e2b2b'; return themeHex(); }
function billCanvas(id,r){
  const p=partyById(id), sup=isSup(p), b=state.settings.business;
  const e=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).sort((a,c)=>a.date.localeCompare(c.date));
  const qty=e.reduce((s,x)=>s+x.qty,0), billed=e.reduce((s,x)=>s+x.amount,0);
  const paid=state.payments.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
  const hasUpi=!!state.settings.upi;
  const W=820, rh=26, H=260+e.length*rh+170+(hasUpi?210:0);
  const c=document.createElement('canvas'); c.width=W; c.height=H; const g=c.getContext('2d');
  g.fillStyle='#fff'; g.fillRect(0,0,W,H);
  const hex=billAccent();
  g.fillStyle=hex; g.font='bold 28px Arial'; g.fillText(shopName(),50,58);
  g.fillStyle='#555'; g.font='15px Arial'; g.fillText((b.owner||'')+(b.phone?' • '+b.phone:'')+(b.address?' • '+b.address:''),50,82);
  g.fillStyle='#111'; g.font='bold 19px Arial'; g.textAlign='right'; g.fillText(t('bill_title')+' — '+r.label,W-50,58);
  g.font='15px Arial'; g.fillStyle='#333'; g.fillText(p.name,W-50,84); g.textAlign='left';
  g.strokeStyle=hex; g.lineWidth=2; g.beginPath(); g.moveTo(50,104); g.lineTo(W-50,104); g.stroke();
  let y=136; g.fillStyle='#666'; g.font='bold 12px Arial';
  [bl('date'),bl('shift'),bl('litres'),bl('rate'),bl('amount')].forEach((h,i)=>{ g.textAlign=i===0?'left':'right'; g.fillText(h,i===0?50:200+i*110,y); }); g.textAlign='left';
  y+=10; g.strokeStyle='#ddd'; g.lineWidth=1; g.beginPath(); g.moveTo(50,y); g.lineTo(W-50,y); g.stroke(); y+=22;
  g.font='13px Arial'; g.fillStyle='#111';
  e.forEach(x=>{ g.textAlign='left'; g.fillText(fmtDate(x.date),50,y); g.textAlign='right'; g.fillText(shiftLbl(x.shift),310,y); g.fillText(num(x.qty),420,y); g.fillText(num(x.rate),530,y); g.fillText(num(x.amount),W-60,y); y+=rh; });
  g.textAlign='left'; y+=8; g.strokeStyle='#111'; g.lineWidth=2; g.beginPath(); g.moveTo(50,y); g.lineTo(W-50,y); g.stroke(); y+=30;
  g.font='15px Arial'; const line=(k,v,bold)=>{ g.fillStyle='#555'; g.textAlign='left'; g.fillText(k,50,y); g.fillStyle='#111'; g.font=bold?'bold 16px Arial':'15px Arial'; g.textAlign='right'; g.fillText(v,W-60,y); g.font='15px Arial'; y+=25; };
  line(bl('totalMilk'),num(qty)+' '+bl('litres'));
  line(bl('totalBill'),money(billed));
  line(bl('paid'),money(paid));
  line(bl('remaining'),money(billed-paid),true);
  line(bl('outstanding'),money(partyBalance(id)),true);
  if(hasUpi){ try{ drawQrTo(g,upiUri(partyBalance(id)),50,y+8,140,2);
    g.fillStyle='#333'; g.font='bold 14px Arial'; g.textAlign='left'; g.fillText(t('scan_pay')+' — '+t('upi'),210,y+44);
    g.fillStyle='#666'; g.font='13px Arial'; g.fillText(state.settings.upi,210,y+70); }catch(e2){} }
  g.textAlign='center'; g.fillStyle='#888'; g.font='12px Arial'; g.fillText(t('thank'),W/2,H-20);
  return c;
}
function downloadAllBillsPdf(){
  const r=rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const list=state.parties.filter(p=>p.type==='customer'&&(state.entries.some(e=>e.partyId===p.id&&inRange(e.date,r.start,r.end))||Math.abs(partyBalance(p.id))>0.5));
  if(!list.length){ toast(t('no_data')); return; }
  try{
    const pages=list.map(p=>{ const c=billCanvas(p.id,r); return {bytes:dataUrlToBytes(c.toDataURL('image/jpeg',0.9)),iw:c.width,ih:c.height,w:c.width,h:c.height}; });
    const pdf=buildPdfMulti(pages);
    const blob=new Blob([pdf],{type:'application/pdf'});
    const fname='all-bills-'+r.start+'.pdf';
    const file=new File([blob],fname,{type:'application/pdf'});
    if(navigator.canShare&&navigator.canShare({files:[file]})){ navigator.share({files:[file],title:t('bill_title')}).catch(()=>{}); return; }
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fname; a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1500); toast(t('pdf_saved'));
  }catch(err){ toast(t('no_pdf')); }
}
function shareBillPdf(id){
  try{
    const r=rangeFor(billPeriod,$('billAnchor').value||todayStr());
    const c=billCanvas(id,r); const pdf=buildPdfMulti([{bytes:dataUrlToBytes(c.toDataURL('image/jpeg',0.92)),iw:c.width,ih:c.height,w:c.width,h:c.height}]);
    const blob=new Blob([pdf],{type:'application/pdf'});
    const p=partyById(id); const fname='bill-'+((p&&p.name)||'party').replace(/\s+/g,'-')+'.pdf';
    const file=new File([blob],fname,{type:'application/pdf'});
    if(navigator.canShare&&navigator.canShare({files:[file]})){ navigator.share({files:[file],title:t('bill_title')}).catch(()=>{}); return; }
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fname; a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1500); toast(t('pdf_saved'));
  }catch(err){ toast(t('no_pdf')); }
}

/* ---------- sync / backup card (home) ---------- */
function syncPendingCount(){ try{ return state.settings.driveAuto ? state.entries.filter(e=>!e.syncAt).length : 0; }catch(e){ return 0; } }
function renderSyncCard(){
  const el=$('syncCard'); if(!el) return;
  const conn=driveReady()||state.settings.driveConnected;
  const last=state.settings.lastDriveBackup||0;
  const pend=syncPendingCount();
  el.className='card sync-card'+(conn?'':' sync-off');
  el.innerHTML='<div class="sync-row">'
    +'<div class="sync-ic">'+(conn?'☁️':'📴')+'</div>'
    +'<div class="sync-main"><div class="sync-t">'+(conn?t('sync_on'):t('sync_off'))+'</div>'
    +'<div class="sync-s">'+(last?(t('sync_last')+' '+fmtDateTime(last)):t('sync_never'))+'</div>'
    +(pend>0?('<div class="sync-pend">⏳ '+pend+' '+t('sync_pending')+'</div>'):'')+'</div>'
    +'<button class="btn sm'+(conn?'':' ghost')+'" onclick="syncNow()">'+(conn?('🔄 '+t('sync_now')):t('sync_connect'))+'</button></div>'
    +'<div class="sync-row" style="margin-top:10px"><span style="flex:1;font-size:13px;font-weight:700">🔁 '+t('sync_auto')+'</span>'
    +'<div class="tr '+(state.settings.driveAuto?'on':'')+'" onclick="toggleAutoBackup()"></div></div>'
    +'<div class="btn-row" style="margin-top:8px">'
    +'<button class="btn grey sm" style="flex:1" onclick="quickBackupFile()">💾 '+t('sync_file')+'</button>'
    +'<button class="btn grey sm" style="flex:1" onclick="openModule(\'drive\')">⚙️ '+t('sync_more')+'</button></div>';
}
async function syncNow(){
  if(!driveReady()){ connectDrive(); toast(t('sync_connect_first')); return; }
  toast('⏳ '+t('sync_doing'));
  let ok=false;
  try{ ok=await driveBackupNow(false); }catch(e){}
  if(ok){ try{ markSynced(); state.settings.lastDriveBackup=Date.now(); save(); }catch(e){} }
  try{ renderSyncCard(); }catch(e){}
  toast(ok?('✅ '+t('sync_done')):t('dr_fail'));
}
function toggleAutoBackup(){
  state.settings.driveAuto=!state.settings.driveAuto; save();
  try{ renderSyncCard(); }catch(e){}
  toast(state.settings.driveAuto?('🔁 '+t('sync_auto_on')):('⏸ '+t('sync_auto_off')));
  if(state.settings.driveAuto){ try{ scheduleAutoDriveBackup(); }catch(e){} }
}
function quickBackupFile(){
  try{
    const blob=new Blob([JSON.stringify(state,null,1)],{type:'application/json'});
    const fname='milk-backup-'+todayStr()+'.json';
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fname;
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(url); a.remove(); }catch(e){} },1500);
    state.settings.lastBackup=Date.now(); save();
    toast('💾 '+t('sync_file_done'));
  }catch(e){ toast(t('dr_fail')); }
}
/* ---------- bill: view / download / WhatsApp ---------- */
function billRange(){ try{ return rangeFor(billPeriod,$('billAnchor').value||todayStr()); }catch(e){ return rangeFor('month',todayStr()); } }
function billPdfBytes(id,r){ try{ const c=billCanvas(id,r); return buildPdfMulti([{bytes:dataUrlToBytes(c.toDataURL('image/jpeg',0.92)),iw:c.width,ih:c.height,w:c.width,h:c.height}]); }catch(e){ return null; } }
function billFileName(id){ const p=partyById(id); return 'bill-'+((p&&p.name)||'party').replace(/\s+/g,'-')+'-'+todayStr()+'.pdf'; }
function billView(id){
  const pdf=billPdfBytes(id,billRange()); if(!pdf){ toast(t('no_pdf')); return; }
  try{
    const url=URL.createObjectURL(new Blob([pdf],{type:'application/pdf'}));
    const w=window.open(url,'_blank');
    if(!w) toast(t('no_pdf'));
    setTimeout(function(){ try{ URL.revokeObjectURL(url); }catch(e){} },90000);
  }catch(e){ toast(t('no_pdf')); }
}
function billDownload(id){
  const pdf=billPdfBytes(id,billRange()); if(!pdf){ toast(t('no_pdf')); return; }
  try{
    const url=URL.createObjectURL(new Blob([pdf],{type:'application/pdf'}));
    const a=document.createElement('a'); a.href=url; a.download=billFileName(id); document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(url); a.remove(); }catch(e){} },1500);
    toast(t('pdf_saved'));
  }catch(e){ toast(t('no_pdf')); }
}
function billWhatsApp(id){
  const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; }
  const txt=billText(id,billRange());
  const code=(state.settings.waCode||'91').replace(/\D/g,''), ph=(p.phone||'').replace(/\D/g,'');
  const full=ph.startsWith(code)?ph:code+ph;
  try{ window.open('https://wa.me/'+full+'?text='+encodeURIComponent(txt),'_blank'); }catch(e){}
}
/* ---------- generic record edit/delete (har jagah) ---------- */
const REC_DEF={
  note:{arr:'notes', icon:'📝', title:'नोट', f:[['text','नोट','text']]},
  loan:{arr:'loans', icon:'💳', title:'उधार', f:[['name','नाम','text'],['amount','रकम','number'],['note','नोट','text']]},
  feed:{arr:'feed', icon:'🌾', title:'चारा', f:[['name','नाम','text'],['stock','स्टॉक','number'],['lowAt','कम होने पर','number']]},
  holiday:{arr:'holidays', icon:'🎉', title:'छुट्टी', f:[['date','तारीख','date']]},
  animal:{arr:'animals', icon:'🐄', title:'पशु', f:[['tag','टैग','text'],['dailyYield','रोज़ का दूध','number']]},
  invoice:{arr:'invoices', icon:'🧾', title:'इनवॉइस', f:[['amount','रकम','number'],['note','नोट','text']]}
};
function editRec(type,id){
  const d=REC_DEF[type]; if(!d) return;
  const rec=(state[d.arr]||[]).find(x=>x.id===id); if(!rec) return;
  const fields=d.f.map(function(f){
    const v=(rec[f[0]]==null?'':rec[f[0]]);
    return '<div class="field"><label>'+f[1]+'</label><input type="'+f[2]+'" id="er_'+f[0]+'" value="'+esc(String(v))+'" /></div>';
  }).join('');
  openModal('<div class="sheet-head"><h2>'+d.icon+' '+d.title+'</h2><button class="x" onclick="closeModal()">✕</button></div>'+fields
    +'<button class="btn" onclick="saveRec(\''+type+'\',\''+id+'\')">'+t('save')+'</button>');
}
function saveRec(type,id){
  const d=REC_DEF[type]; if(!d) return;
  const rec=(state[d.arr]||[]).find(x=>x.id===id); if(!rec) return;
  d.f.forEach(function(f){ const el=$('er_'+f[0]); if(!el) return; rec[f[0]]=(f[2]==='number')?(parseFloat(el.value)||0):el.value; });
  save(); closeModal(); toast(t('saved')); rerenderModule(); renderHome();
}
function delRec(type,id){
  const d=REC_DEF[type]; if(!d) return;
  state[d.arr]=(state[d.arr]||[]).filter(x=>x.id!==id); save(); toast(t('deleted')); rerenderModule();
}
/* ---------- UPI QR ---------- */
function upiUri(amount){
  const vpa=state.settings.upi; if(!vpa) return '';
  const pn=state.settings.upiName||shopName();
  return 'upi://pay?pa='+encodeURIComponent(vpa)+'&pn='+encodeURIComponent(pn)+'&am='+encodeURIComponent((Math.round((amount||0)*100)/100).toFixed(2))+'&cu=INR&tn='+encodeURIComponent(t('bill_title'));
}
function qrMatrix(text){ const qr=qrcode(0,'M'); qr.addData(text); qr.make(); return qr; }
function drawQrTo(g,text,x,y,size,quiet){
  const qr=qrMatrix(text); const n=qr.getModuleCount(); const q=quiet||2; const total=n+q*2; const cell=size/total;
  g.fillStyle='#fff'; g.fillRect(x,y,size,size); g.fillStyle='#000';
  for(let r=0;r<n;r++) for(let c=0;c<n;c++) if(qr.isDark(r,c)) g.fillRect(Math.floor(x+(c+q)*cell),Math.floor(y+(r+q)*cell),Math.ceil(cell),Math.ceil(cell));
}
function showUpiQr(id){
  const upi=state.settings.upi; if(!upi){ toast(t('no_upi')); return; }
  const p=partyById(id), r=rangeFor(billPeriod,$('billAnchor').value||todayStr());
  const billed=state.entries.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
  const paid=state.payments.filter(x=>x.partyId===id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
  let amt=billed-paid; if(amt<=0) amt=partyBalance(id); if(amt<0) amt=0;
  openModal(`
    <div class="sheet-head"><h2>${t('upi_qr')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div style="text-align:center">
      <div style="font-weight:800;font-size:17px">${esc(p.name)}</div>
      <div style="font-size:22px;font-weight:800;color:var(--green-d);margin:6px 0 10px">${money(amt)}</div>
      <div id="qrBox" style="display:inline-block;padding:10px;background:#fff;border-radius:14px"></div>
      <div class="hint" style="margin-top:10px">${t('scan_pay')} · ${t('pay_to')}: ${esc(state.settings.upiName||shopName())}<br>${esc(upi)}</div>
    </div>`);
  try{ const c=document.createElement('canvas'); c.width=260; c.height=260; c.style.borderRadius='8px';
    drawQrTo(c.getContext('2d'),upiUri(amt),0,0,260,2); $('qrBox').appendChild(c); }
  catch(e){ $('qrBox').innerHTML='<div class="hint">QR error</div>'; }
}

/* ---------- REMINDERS ---------- */
function remMsg(p){ return t('reminder_msg').replace('{name}',p.name).replace('{amt}',money(partyBalance(p.id))).replace('{shop}',shopName()); }
function dial(p){ const code=(state.settings.waCode||'').replace(/\D/g,''); let ph=(p.phone||'').replace(/\D/g,''); if(code&&!ph.startsWith(code)) ph=code+ph; return ph; }
function waLink(p){ const ph=dial(p); if(!p.phone) return null; return 'https://wa.me/'+ph+'?text='+encodeURIComponent(remMsg(p)); }
function smsLink(p){ if(!p.phone) return null; return 'sms:'+dial(p)+'?body='+encodeURIComponent(remMsg(p)); }
function waRemind(id){ const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; } window.open(waLink(p),'_blank'); }
function smsRemind(id){ const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; } window.location.href=smsLink(p); }
function openReminders(){
  const dues=state.parties.map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal>0.5).sort((a,b)=>b.bal-a.bal);
  openModal(`
    <div class="sheet-head"><h2>${t('reminders')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="margin-bottom:10px">${t('remind_hint')}</div>
    ${dues.length?dues.map(({p,bal})=>`<div class="list-item">${avatarHtml(p)}
        <div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||t('no_phone'))}</div></div>
        <div class="li-amt"><div class="b due">${money(bal)}</div></div>
        ${p.phone?`<button class="btn wa xs" onclick="waRemind('${p.id}')">🔔</button><button class="btn sms xs" onclick="smsRemind('${p.id}')">✉️</button>`:''}</div>`).join(''):'<div class="empty">✅ '+t('rem_none')+'</div>'}`);
}
function openBulkRemind(){
  const dues=state.parties.map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal>0.5).sort((a,b)=>b.bal-a.bal);
  if(!dues.length){ toast(t('rem_none')); return; }
  window._dues=dues; window._sel={}; dues.forEach(d=>{ if(d.p.phone) window._sel[d.p.id]=true; });
  renderBulkRemind();
}
function renderBulkRemind(){
  const dues=window._dues||[];
  openModal(`
    <div class="sheet-head"><h2>${t('bulk_remind')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="btn-row" style="margin-bottom:8px">
      <button class="btn grey sm" style="flex:1" onclick="bulkSelect(true)">${t('select_all')}</button>
      <button class="btn grey sm" style="flex:1" onclick="bulkSelect(false)">${t('clear_all_sel')}</button>
    </div>
    ${dues.map(({p,bal})=>`<div class="list-item">
        <input type="checkbox" ${window._sel[p.id]?'checked':''} ${p.phone?'':'disabled'} onchange="window._sel['${p.id}']=this.checked" style="width:22px;height:22px;flex:none;accent-color:var(--green)" />
        ${avatarHtml(p)}<div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||t('no_phone'))}</div></div>
        <div class="li-amt"><div class="b due">${money(bal)}</div></div></div>`).join('')}
    <div class="divider"></div>
    <button class="btn sms" style="margin-bottom:8px" onclick="sendBulkSms()">${t('bulk_sms')}</button>
    <div class="btn-row" style="margin-bottom:8px">
      <button class="btn wa" onclick="startQueue('wa')">${t('wa_queue')}</button>
      <button class="btn sms" onclick="startQueue('sms')">${t('sms_queue')}</button>
    </div>
    <button class="btn grey sm" style="width:100%" onclick="copyDueList()">${t('copy_list')}</button>`);
}
function bulkSelect(v){ (window._dues||[]).forEach(d=>{ if(d.p.phone) window._sel[d.p.id]=v; }); renderBulkRemind(); }
function selParties(){ return (window._dues||[]).filter(d=>window._sel[d.p.id]&&d.p.phone).map(d=>d.p); }
function sendBulkSms(){
  const ps=selParties(); if(!ps.length){ toast(t('no_sel')); return; }
  window.location.href='sms:'+ps.map(dial).join(',')+'?body='+encodeURIComponent(t('bulk_sms_msg').replace('{shop}',shopName()));
}
function startQueue(mode){ const ps=selParties(); if(!ps.length){ toast(t('no_sel')); return; } window._q={mode,ps,i:0}; renderQueue(); }
function renderQueue(){
  const q=window._q, p=q.ps[q.i];
  const act=(q.mode==='wa')?("waRemind('"+p.id+"')"):("smsRemind('"+p.id+"')");
  openModal(`
    <div class="sheet-head"><h2>${q.mode==='wa'?t('wa_queue'):t('sms_queue')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="text-align:center;margin-bottom:10px">${t('party_x_of_y').replace('{a}',q.i+1).replace('{b}',q.ps.length)}</div>
    <div style="display:flex;justify-content:center">${avatarHtml(p,'lg')}</div>
    <div style="text-align:center;font-weight:800;font-size:17px;margin-top:8px">${esc(p.name)}</div>
    <div style="text-align:center;color:var(--red);font-weight:700;margin-bottom:12px">${money(partyBalance(p.id))}</div>
    <button class="btn ${q.mode==='wa'?'wa':'sms'}" style="margin-bottom:8px" onclick="${act}">${t('btn_send')}</button>
    <div class="btn-row"><button class="btn grey" ${q.i===0?'disabled':''} onclick="queuePrev()">${t('prev')}</button>
      <button class="btn" onclick="queueNext()">${q.i>=q.ps.length-1?t('done_all'):t('next')}</button></div>`);
}
function queueNext(){ const q=window._q; if(q.i>=q.ps.length-1){ closeModal(); return; } q.i++; renderQueue(); }
function queuePrev(){ const q=window._q; if(q.i>0){ q.i--; renderQueue(); } }
function copyDueList(){ const ps=selParties(); if(!ps.length){ toast(t('no_sel')); return; }
  const txt=ps.map(p=>p.name+': '+money(partyBalance(p.id))).join('\n'); if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(()=>{}); toast(t('copied')); }

/* ================= MODULES ================= */
function modBulk(){ openBulk(); return '<div class="card"><div class="empty">'+t('bulk_entry')+'</div></div>'; }
function modBulkMonthly(){
  return `<div class="card">
    <div class="hint" style="margin-bottom:12px">${t('bulk_monthly_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('month_lbl')}</label><input type="month" id="bm_month" value="${monthStr()}" /></div>
      <div class="field" style="margin:0"><label>${t('shift')}</label><select id="bm_shift"><option value="morning">${t('morning')}</option><option value="evening">${t('evening')}</option><option value="both">${t('both')}</option></select></div>
    </div>
    <div class="field"><label>${t('qty_override')}</label><input type="number" step="0.01" inputmode="decimal" id="bm_qty" placeholder="auto" /></div>
    <button class="btn" onclick="runBulkMonthly()">${t('run_bulk')}</button>
  </div>`;
}
function runBulkMonthly(){
  const month=$('bm_month').value||monthStr(); const shift=$('bm_shift').value; const ov=parseFloat($('bm_qty').value)||0;
  const [yy,mm]=month.split('-').map(Number); const days=lastDay(yy,mm);
  const shifts=shift==='both'?['morning','evening']:[shift];
  let n=0;
  state.parties.filter(p=>p.type==='customer'&&p.active!==false).forEach(c=>{
    const qty=ov||c.defaultQty; if(!qty||qty<=0) return;
    for(let day=1;day<=days;day++){ const ds=month+'-'+String(day).padStart(2,'0');
      if(isHoliday(ds,c.id)) continue;
      shifts.forEach(sh=>{
        if(state.entries.some(e=>e.partyId===c.id&&e.date===ds&&e.shift===sh)) return;
        const r=calcAmount(c,qty,0,'','');
        state.entries.push({id:uid(),date:ds,partyId:c.id,itemId:'',kind:'sale',shift:sh,qty,fat:0,rate:r.rate,amount:r.amount}); n++;
      });
    }
  });
  if(!n){ toast(t('no_default_warn')); return; }
  save(); renderHome(); renderEntries(); rerenderModule(); toast(n+' × '+t('bulk_monthly_done'));
}
function modHoliday(){
  const hs=state.holidays.slice().sort((a,b)=>b.date.localeCompare(a.date));
  return `<div class="card">
    <div class="hint" style="margin-bottom:12px">${t('holiday_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('date')}</label><input type="date" id="hd_date" value="${todayStr()}" /></div>
      <div class="field" style="margin:0"><label>${t('party_lbl')}</label><select id="hd_party"><option value="">${t('holiday_all')}</option>${state.parties.filter(p=>p.type==='customer').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
    </div>
    <label class="sw" style="margin:10px 0"><span class="lb">${t('holiday_weekly')}</span><input type="checkbox" id="hd_weekly" style="width:20px;height:20px;accent-color:var(--green)" /></label>
    <button class="btn" onclick="addHoliday()">${t('add_holiday')}</button>
  </div>
  <div class="card"><h3>${t('holiday')}</h3>
    ${hs.length?hs.map(h=>`<div class="list-item"><div class="avatar" style="background:var(--amber-l);color:var(--amber)">🎉</div>
      <div class="li-main"><div class="t">${fmtDate(h.date)}</div><div class="s">${h.partyId?esc(partyName(h.partyId)):t('holiday_all')}</div></div>
      <button class="btn grey xs" onclick="editRec('holiday','${h.id}')">✏️</button>
      <button class="btn danger xs" onclick="delHoliday('${h.id}')">🗑</button></div>`).join(''):'<div class="empty">'+t('no_holidays')+'</div>'}
  </div>`;
}
function addHoliday(){
  const date=$('hd_date').value||todayStr(), partyId=$('hd_party').value||'';
  const weekly=!!($('hd_weekly')&&$('hd_weekly').checked);
  state.holidays.push({id:uid(),date,partyId,weekly:weekly}); save(); rerenderModule(); toast(t('holiday_added'));
}
function callParty(id){ const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; }
  try{ if(window.MilkNative&&window.MilkNative.dial){ window.MilkNative.dial(p.phone); return; } }catch(e){}
  try{ window.location.href='tel:'+p.phone; }catch(e){} }
function waParty(id){ const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; }
  const code=(state.settings.waCode||'91').replace(/\D/g,''); const ph=(p.phone||'').replace(/\D/g,'');
  const full=ph.startsWith(code)?ph:code+ph;
  try{ window.open('https://wa.me/'+full,'_blank'); }catch(e){} }
function delHoliday(id){ if(!confirm(t('c_holiday'))) return; state.holidays=state.holidays.filter(h=>h.id!==id); save(); rerenderModule(); toast(t('deleted')); }
function modMilkCard(){
  const month=monthStr();
  const opts=state.parties.filter(p=>p.type==='customer').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  return `<div class="card">
    <div class="hint" style="margin-bottom:10px">${t('milkcard_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('party_lbl')}</label><select id="mc_party" onchange="renderMilkCard()">${opts}</select></div>
      <div class="field" style="margin:0"><label>${t('month_lbl')}</label><input type="month" id="mc_month" value="${month}" onchange="renderMilkCard()" /></div>
    </div>
    <div style="overflow-x:auto"><table id="mcTable"></table></div>
  </div>`;
}
function renderMilkCard(){
  const id=$('mc_party').value, month=$('mc_month').value;
  const e=state.entries.filter(x=>x.partyId===id&&x.date.startsWith(month));
  if(!e.length){ $('mcTable').innerHTML=`<tbody><tr><td style="padding:16px;color:var(--muted)">${t('no_milkcard')}</td></tr></tbody>`; return; }
  const byDate={}; e.forEach(x=>{ const o=byDate[x.date]||(byDate[x.date]={m:0,ev:0,a:0}); if(x.shift==='evening') o.ev+=x.qty; else o.m+=x.qty; o.a+=x.amount; });
  const days=Object.keys(byDate).sort();
  let tot={m:0,ev:0,a:0};
  let html=`<thead><tr><th>${t('date')}</th><th>${t('morning')}</th><th>${t('evening')}</th><th>${t('total')}</th><th>${cur()}</th></tr></thead><tbody>`;
  days.forEach(d=>{ const o=byDate[d]; tot.m+=o.m; tot.ev+=o.ev; tot.a+=o.a;
    html+=`<tr><td>${fmtDate(d)}</td><td>${num(o.m)}</td><td>${num(o.ev)}</td><td>${num(o.m+o.ev)}</td><td>${num(o.a)}</td></tr>`; });
  html+=`<tr style="font-weight:800"><td>${t('total')}</td><td>${num(tot.m)}</td><td>${num(tot.ev)}</td><td>${num(tot.m+tot.ev)}</td><td>${num(tot.a)}</td></tr></tbody>`;
  $('mcTable').innerHTML=html;
}
function modLedger(){
  return `<div class="card">
    <div class="hint" style="margin-bottom:10px">${t('ledger_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('party_lbl')}</label><select id="ledParty" onchange="renderLedger()"></select></div>
      <div class="field" style="margin:0"><label>${t('month_lbl')}</label><input type="month" id="ledMonth" value="${monthStr()}" onchange="renderLedger()" /></div>
    </div>
    <div style="overflow-x:auto"><table id="ledgerTable"></table></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost" onclick="shareLedger()">${t('send')}</button><button class="btn ghost" onclick="printLedger()">${t('print')}</button></div>
  </div>`;
}
function fillLedParty(){ const sel=$('ledParty'); if(!sel) return; const curv=sel.value;
  sel.innerHTML=state.parties.slice().sort((a,b)=>(a.name||'').localeCompare(b.name||'')).map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  if(curv&&state.parties.some(p=>p.id===curv)) sel.value=curv; }
function openLedgerFor(id){ openModule('ledger'); fillLedParty(); $('ledParty').value=id; renderLedger(); }
function ledgerData(partyId,month){
  const p=partyById(partyId); if(!p) return {rows:[],open:0,close:0,p:null};
  let open=(parseFloat(p.opening)||0);
  state.entries.filter(e=>e.partyId===partyId&&e.date.slice(0,7)<month).forEach(e=>open+=e.amount);
  state.payments.filter(x=>x.partyId===partyId&&x.date.slice(0,7)<month).forEach(x=>open-=x.amount);
  const items=[];
  state.entries.filter(e=>e.partyId===partyId&&e.date.startsWith(month)).forEach(e=>items.push({date:e.date,t:'e',o:e}));
  state.payments.filter(x=>x.partyId===partyId&&x.date.startsWith(month)).forEach(x=>items.push({date:x.date,t:'p',o:x}));
  items.sort((a,b)=>a.date.localeCompare(b.date));
  let bal=open; const rows=[];
  items.forEach(it=>{ if(it.t==='e'){ bal+=it.o.amount; rows.push({date:it.date,label:(isSup(p)?t('purchase'):t('sale'))+' '+num(it.o.qty)+' L',debit:it.o.amount,credit:0,bal}); }
    else { bal-=it.o.amount; rows.push({date:it.date,label:t('payment_add')+(it.o.mode?' ('+it.o.mode+')':''),debit:0,credit:it.o.amount,bal}); } });
  return {rows,open,close:bal,p};
}
function renderLedger(){
  if(!$('ledMonth')) return; if(!$('ledMonth').value) $('ledMonth').value=monthStr();
  fillLedParty();
  const id=$('ledParty').value, month=$('ledMonth').value;
  if(!id){ $('ledgerTable').innerHTML=''; return; }
  const d=ledgerData(id,month);
  let html=`<thead><tr><th>${t('date')}</th><th>${t('particulars')}</th><th>${t('debit')}</th><th>${t('credit')}</th><th>${t('bal_col')}</th></tr></thead><tbody>`;
  html+=`<tr><td>${fmtMonth(month)} 01</td><td>${t('opening_bal')}</td><td></td><td></td><td>${num(d.open)}</td></tr>`;
  html+=d.rows.length?d.rows.map(r=>`<tr><td>${fmtDate(r.date)}</td><td>${esc(r.label)}</td><td>${r.debit?num(r.debit):''}</td><td>${r.credit?num(r.credit):''}</td><td>${num(r.bal)}</td></tr>`).join('')
    :`<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:14px">${t('no_ledger')}</td></tr>`;
  html+=`<tr style="font-weight:800"><td></td><td>${t('closing_bal')}</td><td>${num(d.rows.reduce((s,r)=>s+r.debit,0))}</td><td>${num(d.rows.reduce((s,r)=>s+r.credit,0))}</td><td>${num(d.close)}</td></tr></tbody>`;
  $('ledgerTable').innerHTML=html;
}
function ledgerText(){ const id=$('ledParty').value, month=$('ledMonth').value; const d=ledgerData(id,month);
  let s='📒 '+shopName()+'\n'+t('ledger')+' — '+(d.p?d.p.name:'')+'\n'+fmtMonth(month)+'\n────────────\n'+t('opening_bal')+': '+money(d.open)+'\n';
  d.rows.forEach(r=>{ s+=fmtDate(r.date)+' '+r.label+': '+(r.debit?'+'+money(r.debit):'-'+money(r.credit))+' → '+money(r.bal)+'\n'; });
  return s+t('closing_bal')+': '+money(d.close)+'\n────────────\n'+t('thank'); }
function shareLedger(){ const txt=ledgerText(); if(navigator.share) navigator.share({title:t('ledger'),text:txt}).catch(()=>{}); else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(()=>{}); toast(t('copied')); } }
function printLedger(){ const id=$('ledParty').value, month=$('ledMonth').value; const d=ledgerData(id,month);
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('ledger')}</title><style>body{font-family:Arial,'Noto Sans Devanagari',sans-serif;padding:22px;max-width:700px;margin:auto}h1{font-size:19px}h2{font-size:14px;color:#555;font-weight:500}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:6px;text-align:right}th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}th{background:#f2f6f4;font-size:11px}tr.t{font-weight:800}.hd{border-bottom:2px solid ${themeHex()};padding-bottom:10px;margin-bottom:14px}</style></head><body>
    <div class="hd"><h1>${esc(shopName())}</h1><h2>${t('ledger')} — ${esc(d.p?d.p.name:'')} · ${fmtMonth(month)}</h2></div>
    <table><thead><tr><th>${t('date')}</th><th>${t('particulars')}</th><th>${t('debit')}</th><th>${t('credit')}</th><th>${t('bal_col')}</th></tr></thead><tbody>
    <tr><td>${fmtMonth(month)} 01</td><td>${t('opening_bal')}</td><td></td><td></td><td>${num(d.open)}</td></tr>
    ${d.rows.map(r=>`<tr><td>${fmtDate(r.date)}</td><td>${esc(r.label)}</td><td>${r.debit?num(r.debit):''}</td><td>${r.credit?num(r.credit):''}</td><td>${num(r.bal)}</td></tr>`).join('')}
    <tr class="t"><td></td><td>${t('closing_bal')}</td><td>${num(d.rows.reduce((s,r)=>s+r.debit,0))}</td><td>${num(d.rows.reduce((s,r)=>s+r.credit,0))}</td><td>${num(d.close)}</td></tr></tbody></table>
    <script>setTimeout(function(){window.print();},350);<\/script></body></html>`); w.document.close(); }
function modStatement(){
  const opts=state.parties.filter(p=>p.type==='customer').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  return `<div class="card">
    <div class="hint" style="margin-bottom:10px">${t('st_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('st_party')}</label><select id="stParty" onchange="renderStatement()">${opts}</select></div>
      <div class="field" style="margin:0"><label>${t('st_month')}</label><input type="month" id="stMonth" value="${monthStr()}" onchange="renderStatement()" /></div>
    </div>
    <div id="stPreview"></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost" onclick="printStatement()">${t('print')}</button><button class="btn ghost" onclick="shareStatement()">${t('send')}</button></div>
    <button class="btn" style="margin-top:8px" onclick="printAllStatements()">${t('st_print_all')}</button>
  </div>`;
}
function statementData(partyId,month){
  const p=partyById(partyId); if(!p) return null;
  let opening=(parseFloat(p.opening)||0);
  state.entries.filter(e=>e.partyId===partyId&&e.date.slice(0,7)<month).forEach(e=>opening+=e.amount);
  state.payments.filter(x=>x.partyId===partyId&&x.date.slice(0,7)<month).forEach(x=>opening-=x.amount);
  const e=state.entries.filter(x=>x.partyId===partyId&&x.date.startsWith(month));
  const pays=state.payments.filter(x=>x.partyId===partyId&&x.date.startsWith(month)).sort((a,b)=>a.date.localeCompare(b.date));
  const qty=e.reduce((s,x)=>s+x.qty,0), billed=e.reduce((s,x)=>s+x.amount,0), paid=pays.reduce((s,x)=>s+x.amount,0);
  return {p,opening,entries:e,payments:pays,qty,billed,paid,closing:opening+billed-paid};
}
function renderStatement(){
  if(!$('stMonth')) return; const id=$('stParty').value; if(!id){ $('stPreview').innerHTML=''; return; }
  const d=statementData(id,$('stMonth').value);
  $('stPreview').innerHTML=`<div class="bill-box" style="margin-top:12px">
    <div class="bill-line"><span class="k">${t('opening_bal2')}</span><span class="v">${money2(d.opening)}</span></div>
    <div class="bill-line"><span class="k">${t('total_milk')}</span><span class="v">${num(d.qty)} ${t('litres')}</span></div>
    <div class="bill-line"><span class="k">${t('total_bill')}</span><span class="v">${money2(d.billed)}</span></div>
    <div class="bill-line"><span class="k">${t('paid_month')}</span><span class="v">${money2(d.paid)}</span></div>
    <div class="bill-line tot"><span class="k">${t('closing')}</span><span class="v">${money2(d.closing)}</span></div></div>`;
}
function printStatement(){ const id=$('stParty').value; if(!id){ toast(t('add_party_first')); return; }
  const month=$('stMonth').value||monthStr(); const r=rangeFor('month',month+'-01');
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('statement_word')}</title>${billPageCss()}</head><body>${billPageHtml(id,r)}<script>setTimeout(function(){window.print();},350);<\/script></body></html>`); w.document.close(); }
function shareStatement(){ const id=$('stParty').value; const d=statementData(id,$('stMonth').value); if(!d){ toast(t('add_party_first')); return; }
  const txt='📄 '+shopName()+'\n'+t('statement_word')+' — '+d.p.name+'\n'+fmtMonth($('stMonth').value)+'\n────────────\n'+t('opening_bal2')+': '+money(d.opening)+'\n'+t('total_milk')+': '+num(d.qty)+' '+t('litres')+'\n'+t('total_bill')+': '+money(d.billed)+'\n'+t('paid_month')+': '+money(d.paid)+'\n'+t('closing')+': '+money(d.closing)+'\n────────────\n'+t('thank');
  if(navigator.share) navigator.share({title:t('statement_word'),text:txt}).catch(()=>{}); else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(()=>{}); toast(t('copied')); } }
function modPayments(){
  return `<div class="card">
    <div class="seg"><button id="pay-d" class="on" onclick="renderPayments('d')">${t('pay_daily')}</button><button id="pay-m" onclick="renderPayments('m')">${t('pay_monthly')}</button></div>
    <div class="field" style="margin:0"><input type="date" id="payDate" value="${todayStr()}" onchange="renderPayments(window._payMode||'d')" /></div>
    <div class="bill-line tot" style="margin-top:10px"><span class="k">${t('pay_total')}</span><span class="v" id="payTotal">₹0</span></div>
    <div id="payList"></div>
  </div>`;
}
function renderPayments(mode){
  window._payMode=mode;
  $('pay-d').classList.toggle('on',mode==='d'); $('pay-m').classList.toggle('on',mode==='m');
  const d=$('payDate').value||todayStr(); const pre=mode==='m'?d.slice(0,7):d;
  const list=state.payments.filter(x=>mode==='m'?x.date.startsWith(pre):x.date===pre).sort((a,b)=>b.date.localeCompare(a.date));
  $('payTotal').textContent=money(list.reduce((s,x)=>s+x.amount,0));
  $('payList').innerHTML=list.length?list.map(x=>`<div class="list-item"><div class="avatar">💵</div>
    <div class="li-main"><div class="t">${esc(partyName(x.partyId))}</div><div class="s">${fmtDate(x.date)} • ${esc(x.mode||'')}</div></div>
    <div class="li-amt"><div class="a">${money(x.amount)}</div></div>
    <button class="btn grey xs" onclick="editPayment('${x.id}')">✏️</button>
    <button class="btn danger xs" onclick="delPayment('${x.id}')">🗑</button></div>`).join(''):'<div class="empty">'+t('no_pay')+'</div>';
}
function modDues(){
  return `<div class="card"><h3>${t('dues_cust')}</h3><div id="duesList"></div></div>
    <div class="card"><h3>${t('adv_cust')}</h3><div id="advList"></div></div>
    <div class="card"><h3>${t('pending_month')}</h3><div class="field" style="margin-bottom:8px"><input type="month" id="duesMonth" value="${monthStr()}" onchange="renderDues()" /></div><div style="overflow-x:auto"><table id="pendTable"></table></div></div>
    <div class="card"><h3>${t('ageing')}</h3><div id="ageList"></div></div>`;
}
function renderDues(){
  const dues=state.parties.filter(p=>p.type==='customer').map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal>0.5).sort((a,b)=>b.bal-a.bal);
  $('duesList').innerHTML=dues.length?dues.map(({p,bal})=>`<div class="list-item" onclick="openBillDetail('${p.id}',rangeFor('month',todayStr()))">${avatarHtml(p)}
      <div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||'')}</div></div><div class="li-amt"><div class="b due">${money(bal)}</div></div>
      ${p.phone?`<button class="btn wa xs" onclick="event.stopPropagation();waRemind('${p.id}')">🔔</button>`:''}</div>`).join(''):'<div class="empty">'+t('no_dues')+'</div>';
  const advs=state.parties.map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal<-0.5).sort((a,b)=>a.bal-b.bal);
  $('advList').innerHTML=advs.length?advs.map(({p,bal})=>`<div class="list-item">${avatarHtml(p)}<div class="li-main"><div class="t">${esc(p.name)}</div></div><div class="li-amt"><div class="b ok">${money(-bal)}</div></div></div>`).join(''):'<div class="empty">'+t('no_dues')+'</div>';
  const month=$('duesMonth').value||monthStr();
  const r=rangeFor('month',month+'-01');
  const rows=state.parties.filter(p=>p.type==='customer').map(p=>{
    const e=state.entries.filter(x=>x.partyId===p.id&&inRange(x.date,r.start,r.end));
    const amt=e.reduce((s,x)=>s+x.amount,0); const q=e.reduce((s,x)=>s+x.qty,0);
    const pd=state.payments.filter(x=>x.partyId===p.id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
    return {name:p.name,q,amt,pd,due:amt-pd};
  }).filter(x=>x.amt||x.pd).sort((a,b)=>b.due-a.due);
  $('pendTable').innerHTML=rows.length?`<thead><tr><th>${t('party_lbl')}</th><th>L</th><th>${t('total_bill')}</th><th>${t('paid_month')}</th><th>${t('remaining')}</th></tr></thead>
    <tbody>${rows.map(x=>`<tr><td>${esc(x.name)}</td><td>${num(x.q)}</td><td>${num(x.amt)}</td><td>${num(x.pd)}</td><td style="color:${x.due>0.5?'var(--red)':'var(--green)'};font-weight:700">${num(x.due)}</td></tr>`).join('')}</tbody>`
    :`<tbody><tr><td colspan="5" style="text-align:center;color:var(--muted);padding:16px">${t('no_data')}</td></tr></tbody>`;
  renderAgeing();
}
function renderAgeing(){
  const today=new Date(); const b={a:0,b:0,c:0};
  state.parties.filter(p=>p.type==='customer').forEach(p=>{
    const es=state.entries.filter(e=>e.partyId===p.id).sort((x,y)=>x.date.localeCompare(y.date));
    let paid=state.payments.filter(x=>x.partyId===p.id).reduce((s,x)=>s+x.amount,0);
    es.forEach(e=>{ let due=e.amount; if(paid>0){ const use=Math.min(paid,due); due-=use; paid-=use; }
      if(due>0.5){ const days=Math.floor((today-new Date(e.date+'T00:00:00'))/86400000); if(days<=30) b.a+=due; else if(days<=60) b.b+=due; else b.c+=due; } });
    const op=parseFloat(p.opening)||0; if(op>0.5) b.c+=op;
  });
  const total=b.a+b.b+b.c;
  const el=$('ageList'); if(!el) return;
  el.innerHTML=total>0.5?`<div class="bill-line"><span class="k">${t('age_0_30')}</span><span class="v">${money(b.a)}</span></div>
    <div class="bill-line"><span class="k">${t('age_31_60')}</span><span class="v">${money(b.b)}</span></div>
    <div class="bill-line"><span class="k">${t('age_60')}</span><span class="v">${money(b.c)}</span></div>
    <div class="bill-line tot"><span class="k">${t('r_due')}</span><span class="v">${money(total)}</span></div>`
    :'<div class="empty">✅ '+t('no_dues')+'</div>';
}
function modReports(){
  const seg=REP_TYPES.map(tp=>`<button class="${tp===repType?'on':''}" onclick="setRepType('${tp}')">${t('rep_'+tp)}</button>`).join('');
  return `<div class="card">
    <div class="seg wrap">${seg}</div>
    <div class="field" style="margin:0"><label>${t('anchor')}</label><input type="date" id="repAnchor" value="${todayStr()}" onchange="renderReports()" /></div>
    <div class="hint" id="repPeriodLbl" style="margin-top:8px"></div>
    <div class="stats" style="margin:12px 0 0">
      <div class="stat green"><div class="lbl">${t('r_sales')}</div><div class="val" id="rp-sale">₹0</div></div>
      <div class="stat amber"><div class="lbl">${t('r_purch')}</div><div class="val" id="rp-purch">₹0</div></div>
      <div class="stat red"><div class="lbl">${t('r_exp')}</div><div class="val" id="rp-exp">₹0</div></div>
      <div class="stat blue"><div class="lbl">${t('r_profit')}</div><div class="val" id="rp-profit">₹0</div></div>
    </div>
    <div style="overflow-x:auto;margin-top:12px"><table id="reportTable"></table></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn grey" onclick="downloadReportCSV()">📄 CSV</button><button class="btn grey" onclick="exportXlsx()">${t('xlsx')}</button><button class="btn grey" onclick="reportChartImage()">📈 ${t('chart_img')||'Chart'}</button></div>
    <div class="btn-row" style="margin-top:8px"><button class="btn grey" onclick="printReport()">${t('print')}</button></div>
  </div>`;
}
function setRepType(tp){ repType=tp; rerenderModule(); renderReports(); }
const REP_TYPES=['day','week','tenday','month','datewise','monthwise','yearwise','partyyear'];
function reportData(type,anchor){
  const d=new Date(anchor+'T00:00:00'), y=d.getFullYear(), m=d.getMonth()+1; const p2=n=>String(n).padStart(2,'0');
  if(type==='datewise'){ const start=y+'-'+p2(m)+'-01', end=y+'-'+p2(m)+'-'+p2(lastDay(y,m)); const rows=[];
    for(let day=1;day<=lastDay(y,m);day++){ const ds=y+'-'+p2(m)+'-'+p2(day); const e=state.entries.filter(x=>x.date===ds);
      const q=e.reduce((s,x)=>s+x.qty,0); const sa=e.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0);
      const pu=e.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0); const ex=state.expenses.filter(x=>x.date===ds).reduce((s,x)=>s+x.amount,0);
      if(q||sa||pu||ex) rows.push({label:fmtDate(ds),q,sale:sa,purch:pu,exp:ex,profit:sa-pu-ex,extra:''}); }
    return {start,end,label:fmtMonth(y+'-'+p2(m)),rows,group:'date'}; }
  if(type==='monthwise'){ const start=y+'-01-01', end=y+'-12-31'; const rows=[];
    for(let mm=1;mm<=12;mm++){ const pre=y+'-'+p2(mm); const e=state.entries.filter(x=>x.date.startsWith(pre)); const q=e.reduce((s,x)=>s+x.qty,0);
      const sa=e.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0); const pu=e.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
      const ex=state.expenses.filter(x=>x.date.startsWith(pre)).reduce((s,x)=>s+x.amount,0);
      if(q||sa||pu||ex) rows.push({label:MONTHS[LANG][mm-1],q,sale:sa,purch:pu,exp:ex,profit:sa-pu-ex,extra:''}); }
    return {start,end,label:''+y,rows,group:'month'}; }
  if(type==='yearwise'){ const years={}; state.entries.forEach(x=>{years[x.date.slice(0,4)]=1;});
    const rows=Object.keys(years).sort().map(yy=>{ const e=state.entries.filter(x=>x.date.startsWith(yy)); const q=e.reduce((s,x)=>s+x.qty,0);
      const sa=e.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0); const pu=e.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
      const ex=state.expenses.filter(x=>x.date.startsWith(yy)).reduce((s,x)=>s+x.amount,0); return {label:yy,q,sale:sa,purch:pu,exp:ex,profit:sa-pu-ex,extra:''}; });
    return {start:'0000-01-01',end:'9999-12-31',label:t('rep_yearwise'),rows,group:'year'}; }
  if(type==='partyyear'){ const pre=''+y; const e=state.entries.filter(x=>x.date.startsWith(pre));
    const rows=state.parties.map(p=>{ const pe=e.filter(x=>x.partyId===p.id); const q=pe.reduce((s,x)=>s+x.qty,0);
      const sa=pe.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0); const pu=pe.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
      return {label:p.name,sup:isSup(p),q,sale:sa,purch:pu,exp:0,profit:sa-pu,extra:isSup(p)?'':money(partyBalance(p.id))}; }).filter(x=>x.q||x.sale||x.purch);
    return {start:pre+'-01-01',end:pre+'-12-31',label:pre,rows,group:'party'}; }
  const r=rangeFor(type,anchor);
  const e=state.entries.filter(x=>inRange(x.date,r.start,r.end));
  const rows=state.parties.map(p=>{ const pe=e.filter(x=>x.partyId===p.id); const q=pe.reduce((s,x)=>s+x.qty,0);
    const sa=pe.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0); const pu=pe.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
    return {label:p.name,sup:isSup(p),q,sale:sa,purch:pu,exp:0,profit:sa-pu,extra:isSup(p)?'':money(partyBalance(p.id))}; }).filter(x=>x.q||x.sale||x.purch);
  return {start:r.start,end:r.end,label:r.label,rows,group:'party'};
}
function renderReports(){
  const el=$('reportTable'); if(!el) return;
  const data=reportData(repType,$('repAnchor').value||todayStr());
  $('repPeriodLbl').textContent=data.label;
  const tot=data.rows.reduce((a,x)=>({q:a.q+x.q,sale:a.sale+x.sale,purch:a.purch+x.purch,exp:a.exp+x.exp,profit:a.profit+x.profit}),{q:0,sale:0,purch:0,exp:0,profit:0});
  $('rp-sale').textContent=money(tot.sale); $('rp-purch').textContent=money(tot.purch); $('rp-exp').textContent=money(tot.exp); $('rp-profit').textContent=money(tot.profit);
  const colHdr=data.group==='party'?t('remaining'):t('r_profit');
  $('reportTable').innerHTML=data.rows.length?`
    <thead><tr><th>${data.group==='party'?t('party_lbl'):(data.group==='date'?t('date'):t('month_lbl'))}</th><th>L</th><th>${cur()} ${t('sale')}</th><th>${cur()} ${t('purchase')}</th><th>${colHdr}</th></tr></thead>
    <tbody>${data.rows.map(x=>`<tr><td>${esc(x.label)}${x.sup?`<span class="tag sup">${t('purchase')}</span>`:''}</td><td>${num(x.q)}</td><td>${num(x.sale)}</td><td>${num(x.purch)}</td><td style="font-weight:700">${data.group==='party'?esc(x.extra||'—'):num(x.profit)}</td></tr>`).join('')}
      <tr style="font-weight:800"><td>${t('total')}</td><td>${num(tot.q)}</td><td>${num(tot.sale)}</td><td>${num(tot.purch)}</td><td>${data.group==='party'?'':num(tot.profit)}</td></tr></tbody>`
    :`<tbody><tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px">${t('no_data')}</td></tr></tbody>`;
}
function downloadReportCSV(){
  const data=reportData(repType,$('repAnchor').value||todayStr());
  if(!data.rows.length){ toast(t('no_data_toast')); return; }
  const csv='\uFEFF'+[['Label','Litres','Sale','Purchase','Expense','Profit'],...data.rows.map(x=>[x.label,x.q,x.sale,x.purch,x.exp,x.profit])].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  download('report-'+repType+'-'+($('repAnchor').value||todayStr())+'.csv',csv,'text/csv;charset=utf-8'); toast(t('csv_saved'));
}
function printReport(){
  const data=reportData(repType,$('repAnchor').value||todayStr());
  if(!data.rows.length){ toast(t('no_data_toast')); return; }
  const tot=data.rows.reduce((a,x)=>({q:a.q+x.q,sale:a.sale+x.sale,purch:a.purch+x.purch,exp:a.exp+x.exp,profit:a.profit+x.profit}),{q:0,sale:0,purch:0,exp:0,profit:0});
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('reports')}</title><style>body{font-family:Arial,'Noto Sans Devanagari',sans-serif;padding:22px;max-width:720px;margin:auto}h1{font-size:19px}h2{font-size:14px;color:#555;font-weight:500}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:7px;text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f2f6f4;font-size:11px}tr.t{font-weight:800}.hd{border-bottom:2px solid ${themeHex()};padding-bottom:10px;margin-bottom:14px}</style></head><body>
    <div class="hd"><h1>${esc(shopName())}</h1><h2>${t('reports')} — ${data.label}</h2></div>
    <table><thead><tr><th>${t('party_lbl')}</th><th>L</th><th>${t('sale')}</th><th>${t('purchase')}</th><th>${t('r_exp')}</th><th>${t('r_profit')}</th></tr></thead><tbody>
    ${data.rows.map(x=>`<tr><td>${esc(x.label)}</td><td>${num(x.q)}</td><td>${num(x.sale)}</td><td>${num(x.purch)}</td><td>${num(x.exp)}</td><td>${num(x.profit)}</td></tr>`).join('')}
    <tr class="t"><td>${t('total')}</td><td>${num(tot.q)}</td><td>${num(tot.sale)}</td><td>${num(tot.purch)}</td><td>${num(tot.exp)}</td><td>${num(tot.profit)}</td></tr></tbody></table>
    <script>setTimeout(function(){window.print();},350);<\/script></body></html>`); w.document.close();
}
function pnlData(period,anchor){
  const d=new Date(anchor+'T00:00:00'), y=d.getFullYear(); const p2=n=>String(n).padStart(2,'0');
  const pre=period==='year'?(''+y):(y+'-'+p2(d.getMonth()+1));
  const e=state.entries.filter(x=>x.date.startsWith(pre));
  const income=e.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0);
  const purchase=e.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
  const byCat={}; state.expenses.filter(x=>x.date.startsWith(pre)).forEach(x=>{ byCat[x.cat]=(byCat[x.cat]||0)+x.amount; });
  const expTotal=Object.values(byCat).reduce((s,v)=>s+v,0);
  const wastage=state.wastage.filter(x=>x.date.startsWith(pre)).reduce((s,x)=>s+(x.value||0),0);
  return {pre,label:period==='year'?(''+y):fmtMonth(pre),income,purchase,gross:income-purchase,byCat,expTotal,wastage,net:income-purchase-expTotal-wastage};
}
function modPnl(){
  return `<div class="card">
    <div class="seg"><button id="pnl-m" class="on" onclick="renderPnL('month')">${t('rep_month')}</button><button id="pnl-y" onclick="renderPnL('year')">${t('rep_yearwise')}</button></div>
    <div class="field" style="margin:0"><input type="date" id="pnlAnchor" value="${todayStr()}" onchange="renderPnL(window._pnl||'month')" /></div>
    <div class="bill-box" style="margin-top:10px" id="pnlBox"></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn grey" onclick="printPnL()">${t('print')}</button></div>
  </div>`;
}
function renderPnL(period){
  window._pnl=period;
  $('pnl-m').classList.toggle('on',period==='month'); $('pnl-y').classList.toggle('on',period==='year');
  const d=pnlData(period,$('pnlAnchor').value||todayStr());
  let html=`<div class="bill-line"><span class="k">${t('total_income')}</span><span class="v">${money2(d.income)}</span></div>
    <div class="bill-line"><span class="k">${t('total_purchase_cost')}</span><span class="v">- ${money2(d.purchase)}</span></div>
    <div class="bill-line big"><span class="k">${t('gross_profit')}</span><span class="v">${money2(d.gross)}</span></div>`;
  CATS.forEach(c=>{ if(d.byCat[c]) html+=`<div class="bill-line"><span class="k">${catLabel(c)}</span><span class="v">- ${money2(d.byCat[c])}</span></div>`; });
  (state.settings.customCats||[]).forEach(c=>{ if(d.byCat[c.id]) html+=`<div class="bill-line"><span class="k">${esc(c.name)}</span><span class="v">- ${money2(d.byCat[c.id])}</span></div>`; });
  if(d.wastage) html+=`<div class="bill-line"><span class="k">${t('wastage')}</span><span class="v">- ${money2(d.wastage)}</span></div>`;
  html+=`<div class="bill-line tot"><span class="k">${t('net_profit')}</span><span class="v" style="color:${d.net>=0?'var(--green)':'var(--red)'}">${money2(d.net)}</span></div>
    <div class="hint" style="margin-top:8px">${d.label}</div>`;
  $('pnlBox').innerHTML=html;
}
function printPnL(){
  const d=pnlData(window._pnl||'month',$('pnlAnchor').value||todayStr());
  const w=window.open('','_blank'); if(!w) return;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('pnl')}</title><style>body{font-family:Arial,'Noto Sans Devanagari',sans-serif;padding:22px;max-width:600px;margin:auto}h1{font-size:19px}h2{font-size:14px;color:#555;font-weight:500}.r{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #eee}.r.b{font-weight:700}.r.t{font-weight:800;border-top:2px solid #111;font-size:16px}.hd{border-bottom:2px solid ${themeHex()};padding-bottom:10px;margin-bottom:14px}</style></head><body>
    <div class="hd"><h1>${esc(shopName())}</h1><h2>${t('pnl')} — ${d.label}</h2></div>
    <div class="r"><span>${t('total_income')}</span><span>${money(d.income)}</span></div>
    <div class="r"><span>${t('total_purchase_cost')}</span><span>- ${money(d.purchase)}</span></div>
    <div class="r b"><span>${t('gross_profit')}</span><span>${money(d.gross)}</span></div>
    ${CATS.filter(c=>d.byCat[c]).map(c=>`<div class="r"><span>${catLabel(c)}</span><span>- ${money(d.byCat[c])}</span></div>`).join('')}
    ${d.wastage?`<div class="r"><span>${t('wastage')}</span><span>- ${money(d.wastage)}</span></div>`:''}
    <div class="r t"><span>${t('net_profit')}</span><span>${money(d.net)}</span></div>
    <script>setTimeout(function(){window.print();},350);<\/script></body></html>`); w.document.close();
}
function modRate(){
  return `<div class="card">
    <div class="field"><label>${t('fat_rate')}</label><input type="number" step="0.01" inputmode="decimal" id="rcFatRate" value="7" oninput="renderRateChart()" /></div>
    <div style="overflow-x:auto"><table id="rateTable"></table></div>
    <div class="divider"></div><h3 style="font-size:14px">${t('party_rates')}</h3><div id="partyRateList"></div>
  </div>`;
}
function renderRateChart(){
  const el=$('rateTable'); if(!el) return;
  const fr=parseFloat($('rcFatRate').value)||0;
  let html=`<thead><tr><th>${t('fat_point')}</th><th>${t('rate_l_col')}</th></tr></thead><tbody>`;
  for(let f=4;f<=9.001;f+=0.5) html+=`<tr><td>${f.toFixed(1)}</td><td>${num(f*fr)}</td></tr>`;
  $('rateTable').innerHTML=html+'</tbody>';
  const list=state.parties.slice().sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  $('partyRateList').innerHTML=list.length?list.map(p=>{ const it=p.items&&p.items.length?(' • '+p.items.map(i=>esc(i.name)+' '+cur()+num(i.rate)).join(', ')):'';
    return `<div class="list-item">${avatarHtml(p)}<div class="li-main"><div class="t">${esc(p.name)}<span class="tag ${isSup(p)?'sup':''}">${isSup(p)?t('purchase'):t('sale')}</span></div>
    <div class="s">${p.rateType==='fat'?t('per_fat'):t('per_liter')}${it}</div></div>
    <div class="li-amt"><div class="a">${cur()}${num(p.rate)}${p.rateType==='fat'?'':t('rate_per_l')}</div></div></div>`; }).join(''):'<div class="empty">'+t('no_parties')+'</div>';
}
function stockOf(itemId){ return state.moves.filter(m=>m.itemId===itemId).reduce((s,m)=>s+(m.type==='in'?m.qty:-m.qty),0); }
function modStock(){
  return `<div class="card"><h3><span>${t('stock')}</span><button class="btn ghost sm right" style="margin-left:auto" onclick="openStockItem()">➕</button></h3><div id="stockList"></div></div>`;
}
function renderStock(){
  const box=$('stockList'); if(!box) return;
  if(!state.items.length){ box.innerHTML='<div class="empty"><span class="big">📦</span>'+t('no_items2')+'</div>'; return; }
  box.innerHTML=state.items.map(it=>{ const st=stockOf(it.id), low=it.min>0&&st<it.min;
    return `<div class="list-item"><div class="avatar" style="background:var(--blue-l);color:var(--blue)">📦</div>
      <div class="li-main" onclick="openStockItem('${it.id}')"><div class="t">${esc(it.name)}${low?`<span class="tag warn">${t('low_stock')}</span>`:''}</div>
      <div class="s">${t('stock_qty')}: ${num(st)} ${esc(it.unit||'')}</div></div>
      <div class="li-amt"><div class="a">${num(st)} ${esc(it.unit||'')}</div></div>
      <button class="btn ghost xs" onclick="openStockMove('${it.id}','in')">➕</button><button class="btn ghost xs" onclick="openStockMove('${it.id}','out')">➖</button></div>`; }).join('');
}
function openStockItem(id){
  const edit=id?state.items.find(x=>x.id===id):null;
  openModal(`
    <div class="sheet-head"><h2>${edit?t('edit_item'):t('add_item')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('item_name')}</label><input type="text" id="i_name" value="${edit?esc(edit.name):''}" placeholder="${t('item_name_ph')}" /></div>
    <div class="row2"><div class="field"><label>${t('unit')}</label><input type="text" id="i_unit" value="${edit?esc(edit.unit||''):''}" placeholder="${t('unit_ph')}" /></div>
      <div class="field"><label>${t('min_stock')}</label><input type="number" step="0.01" inputmode="decimal" id="i_min" value="${edit?(edit.min||0):0}" /></div></div>
    <div class="btn-row">${edit?`<button class="btn danger" onclick="delStockItem('${edit.id}')">${t('del')}</button>`:''}<button class="btn" onclick="saveStockItem(${edit?"'"+edit.id+"'":'null'})">${t('save')}</button></div>
    ${edit?`<div class="divider"></div><h3 style="font-size:14px">${t('movement_history')}</h3>
      ${state.moves.filter(m=>m.itemId===edit.id).sort((a,b)=>b.date.localeCompare(a.date)).map(m=>`<div class="list-item"><div class="avatar" style="background:${m.type==='in'?'var(--green-l)':'var(--red-l)'};color:${m.type==='in'?'var(--green-d)':'var(--red)'}">${m.type==='in'?'➕':'➖'}</div>
        <div class="li-main"><div class="t">${m.type==='in'?t('in_short'):t('out_short')}</div><div class="s">${fmtDate(m.date)}</div></div>
        <div class="li-amt"><div class="a">${m.type==='in'?'+':'-'}${num(m.qty)}</div></div>
        <button class="btn danger xs" onclick="delStockMove('${m.id}','${edit.id}')">🗑</button></div>`).join('')||'<div class="empty">'+t('movement_history')+'</div>'}`:''}`);
}
function saveStockItem(id){
  const name=$('i_name').value.trim(); if(!name){ toast(t('enter_name')); return; }
  const rec={id:id||uid(),name,unit:$('i_unit').value.trim(),min:parseFloat($('i_min').value)||0};
  if(id) state.items[state.items.findIndex(x=>x.id===id)]=rec; else state.items.push(rec);
  save(); closeModal(); toast(t('saved')); rerenderModule(); renderLowStock();
}
function delStockItem(id){ if(!confirm(t('c_del'))) return; state.items=state.items.filter(x=>x.id!==id); state.moves=state.moves.filter(m=>m.itemId!==id); save(); closeModal(); toast(t('deleted')); rerenderModule(); renderLowStock(); }
function openStockMove(itemId,type){
  const it=state.items.find(x=>x.id===itemId);
  openModal(`<div class="sheet-head"><h2>${type==='in'?t('stock_in'):t('stock_out')} — ${esc(it.name)}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('date')}</label><input type="date" id="m_date" value="${todayStr()}" /></div>
    <div class="field"><label>${t('move_qty')}</label><input type="number" step="0.01" inputmode="decimal" id="m_qty" placeholder="0" /></div>
    <button class="btn" onclick="saveStockMove('${itemId}','${type}')">${t('save_move')}</button>`);
}
function saveStockMove(itemId,type){
  const qty=parseFloat($('m_qty').value); if(!qty||qty<=0){ toast(t('enter_qty')); return; }
  state.moves.push({id:uid(),itemId,type,date:$('m_date').value||todayStr(),qty}); save(); closeModal(); toast(t('saved')); rerenderModule(); renderLowStock();
}
function delStockMove(id,itemId){ state.moves=state.moves.filter(m=>m.id!==id); save(); openStockItem(itemId); rerenderModule(); renderLowStock(); toast(t('deleted')); }
const CATS=['feed','transport','diesel','labour','electric','rent','other'];
function catLabel(c){ if(CATS.indexOf(c)>=0) return t('cat_'+c)||t('cat_other'); const cc=(state.settings.customCats||[]).find(x=>x.id===c); return cc?cc.name:t('cat_other'); }
function allCats(){ return CATS.map(c=>({key:c,name:catLabel(c)})).concat((state.settings.customCats||[]).map(c=>({key:c.id,name:c.name}))); }
function modExpenses(){
  return `<div class="card"><h3><span>${t('expenses')}</span><span class="sub" id="expMonthLbl"></span></h3>
    <div class="field" style="margin:0 0 10px"><label>${t('exp_month')}</label><input type="month" id="expMonth" value="${monthStr()}" onchange="renderExpenses()" /></div>
    <div class="bill-line tot" style="margin-top:0;border-top:none"><span class="k">${t('exp_total')}</span><span class="v" id="expTotal">₹0</span></div>
    <div id="expensesList"></div>
    <button class="btn ghost" style="margin-top:12px" onclick="openExpense()">➕</button></div>`;
}
function renderExpenses(){
  const el=$('expensesList'); if(!el) return;
  const month=($('expMonth')?$('expMonth').value:'')||monthStr();
  $('expMonthLbl').textContent=fmtMonth(month);
  const list=state.expenses.filter(x=>x.date.startsWith(month)).sort((a,b)=>b.date.localeCompare(a.date));
  $('expTotal').textContent=money(list.reduce((s,x)=>s+x.amount,0));
  el.innerHTML=list.length?list.map(x=>`<div class="list-item"><div class="avatar" style="background:var(--red-l);color:var(--red)">💸</div>
    <div class="li-main"><div class="t">${esc(catLabel(x.cat))}${x.sub?`<span class="tag">${esc(x.sub)}</span>`:''}</div><div class="s">${fmtDate(x.date)}${x.note?' • '+esc(x.note):''}</div>${x.photo?`<img src="${x.photo}" style="max-width:110px;border-radius:8px;margin-top:5px;border:1px solid var(--line)" onclick="viewPhoto('${x.id}')" />`:''}</div>
    <div class="li-amt"><div class="a">${money(x.amount)}</div></div>
    <button class="btn danger xs" onclick="delExpense('${x.id}')">🗑</button></div>`).join(''):'<div class="empty">'+t('no_expenses')+'</div>';
}
function openExpense(){
  openModal(`<div class="sheet-head"><h2>${t('add_expense')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('date')}</label><input type="date" id="x_date" value="${todayStr()}" /></div>
    <div class="field"><label>${t('exp_cat')}</label><select id="x_cat">${allCats().map(c=>`<option value="${c.key}">${esc(c.name)}</option>`).join('')}</select></div>
    <div class="field"><label>${t('amount')}</label><input type="number" step="0.01" inputmode="decimal" id="x_amt" placeholder="${t('amount_ph')}" /></div>
    <div class="field"><label>${t('exp_tag')}</label><input type="text" id="x_tag" placeholder="चारा-भैंस / ट्रांसपोर्ट-ट्रक" /></div>
    <div class="field"><label>${t('exp_photo')}</label><div id="x_photoBox"></div><button class="btn grey sm" onclick="pickExpPhoto()">📷 ${t('photo_add')}</button></div>
    <div class="field"><label>${t('note')}</label><input type="text" id="x_note" placeholder="${t('note_ph')}" /></div>
    <button class="btn" onclick="saveExpense()">${t('save')}</button>`);
}
function saveExpense(){
  const amt=parseFloat($('x_amt').value); if(!amt||amt<=0){ toast(t('enter_amount')); return; }
  const cat=$('x_cat').value;
  state.expenses.push({id:uid(),date:$('x_date').value||todayStr(),cat:cat,amount:amt,note:$('x_note').value.trim(),sub:($('x_tag')?$('x_tag').value.trim():''),photo:(window._expPhoto||'')});
  window._expPhoto='';
  save(); closeModal(); toast(t('expense_saved')); rerenderModule(); renderHome();
  try{ checkBudgetAlert(cat); }catch(e){}
}
function pickExpPhoto(){
  const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; try{ inp.setAttribute('capture','environment'); }catch(e){}
  inp.onchange=function(){ const f=inp.files[0]; if(!f) return;
    shrink(f,760,function(d){ window._expPhoto=d; const b=$('x_photoBox'); if(b) b.innerHTML='<img src="'+d+'" style="max-width:100%;border-radius:10px;margin-bottom:6px" />'; }); };
  inp.click();
}
function checkBudgetAlert(cat){
  const b=(state.settings.budget||{})[cat]; if(!b) return;
  const m=monthStr(); const act=state.expenses.filter(x=>x.date.startsWith(m)&&x.cat===cat).reduce((s,x)=>s+x.amount,0);
  if(act>b) toast('⚠️ '+t('budget_over')+' '+catLabel(cat)+' ('+money(act)+' / '+money(b)+')');
}
function budgetAlertSend(){
  const m=monthStr(); const b=state.settings.budget||{};
  const act={}; state.expenses.filter(x=>x.date.startsWith(m)).forEach(x=>{ act[x.cat]=(act[x.cat]||0)+x.amount; });
  const over=Object.keys(b).filter(k=>b[k]>0&&(act[k]||0)>b[k]).map(k=>catLabel(k)+': '+money(act[k]||0)+' / '+money(b[k]));
  if(!over.length){ toast(t('budget_ok')); return; }
  const msg=shopName()+' — '+fmtMonth(m)+'\n'+t('budget_over')+'\n'+over.join('\n');
  const ph=(state.settings.bizPhone||'').replace(/\D/g,'');
  if(ph){ try{ window.open('https://wa.me/'+((state.settings.waCode||'91')+ph)+'?text='+encodeURIComponent(msg),'_blank'); return; }catch(e){} }
  try{ window.location.href='sms:?body='+encodeURIComponent(msg); }catch(e){}
}
function viewPhoto(id){ const x=state.expenses.find(e=>e.id===id); if(!x||!x.photo) return;
  openModal('<div class="sheet-head"><h2>📷 '+t('exp_photo')+'</h2><button class="x" onclick="closeModal()">✕</button></div><img src="'+x.photo+'" style="width:100%;border-radius:12px" />'); }
function delExpense(id){
  const rec=state.expenses.find(x=>x.id===id); if(!rec) return;
  state.expenses=state.expenses.filter(x=>x.id!==id); save(); rerenderModule(); renderHome();
  toast(t('deleted_undo'),t('undo'),()=>{ state.expenses.push(rec); save(); rerenderModule(); renderHome(); });
}
function modExpLog(){
  const month=monthStr();
  const list=state.expenses.filter(x=>x.date.startsWith(month)).sort((a,b)=>a.date.localeCompare(b.date));
  let run=0;
  return `<div class="card"><h3><span>${t('expense_ledger')}</span><span class="sub">${fmtMonth(month)}</span></h3>
    <div style="overflow-x:auto"><table><thead><tr><th>${t('date')}</th><th>${t('exp_cat')}</th><th>${cur()}</th><th>${t('exp_running')}</th></tr></thead>
    <tbody>${list.map(x=>{ run+=x.amount; return `<tr><td>${fmtDate(x.date)}</td><td>${esc(catLabel(x.cat))}${x.note?' · '+esc(x.note):''}</td><td>${num(x.amount)}</td><td>${num(run)}</td></tr>`; }).join('')||`<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:16px">${t('no_expenses')}</td></tr>`}
    <tr style="font-weight:800"><td colspan="2">${t('exp_total')}</td><td>${num(run)}</td><td></td></tr></tbody></table></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost" onclick="openExpense()">➕</button></div></div>`;
}
function modReminders(){
  const dues=state.parties.map(p=>({p,bal:partyBalance(p.id)})).filter(x=>x.bal>0.5).sort((a,b)=>b.bal-a.bal);
  return `<div class="card"><h3><span>${t('reminders')}</span><button class="btn grey sm right" style="margin-left:auto" onclick="openBulkRemind()">📢</button></h3>
    <div class="hint" style="margin-bottom:10px">${t('remind_hint')}</div>
    ${dues.length?dues.map(({p,bal})=>`<div class="list-item">${avatarHtml(p)}
      <div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||t('no_phone'))}</div></div>
      <div class="li-amt"><div class="b due">${money(bal)}</div></div>
      ${p.phone?`<button class="btn wa xs" onclick="waRemind('${p.id}')">🔔</button><button class="btn sms xs" onclick="smsRemind('${p.id}')">✉️</button>`:''}</div>`).join(''):'<div class="empty">✅ '+t('rem_none')+'</div>'}</div>`;
}
function modBackup(){
  return `<div class="card"><h3>${t('backup')}</h3>
    <div class="btn-row" style="margin-bottom:9px"><button class="btn grey sm" style="flex:1" onclick="exportBackup()">${t('save_backup')}</button>
      <button class="btn grey sm" style="flex:1" onclick="document.getElementById('importFile').click()">${t('load_backup')}</button></div>
    <input type="file" id="importFile" accept=".json,application/json" style="display:none" onchange="importBackup(event)" />
    <button class="btn grey sm" style="width:100%;margin-bottom:9px" onclick="restoreAutoBackup()">${t('restore_auto')}</button>
    <button class="btn grey sm" style="width:100%;margin-bottom:9px" onclick="exportCSV()">${t('export_csv')}</button>
    <div class="divider"></div><h3 style="font-size:14px">${t('cloud')}</h3>
    <button class="btn sm" style="width:100%;margin-bottom:9px" onclick="shareBackup()">☁️ ${t('drive_save')}</button>
    <button class="btn grey sm" style="width:100%;margin-bottom:9px" onclick="linkBackupFile()">${t('link_file')}</button>
    <div class="bill-line"><span class="k">${t('linked_to')}</span><span class="v" id="cloudStatus">—</span></div>
    <div class="btn-row" style="margin-top:9px"><button class="btn grey sm" style="flex:1" onclick="restoreLinked()">♻️</button><button class="btn grey sm" style="flex:1" onclick="unlinkBackup()">✖️</button></div>
    <div class="hint" style="margin-top:8px">${t('drive_hint')}</div>
    <div class="bill-line" style="border-top:1px solid var(--line);margin-top:9px;padding-top:9px"><span class="k">${t('data_usage')}</span><span class="v" id="dataUsage">—</span></div>
    <button class="btn grey sm" style="width:100%;margin:9px 0" onclick="cleanNow()">${t('clean_now')}</button>
    <button class="btn danger sm" style="width:100%" onclick="clearAll()">${t('clear_all')}</button>
    <div class="hint" style="margin-top:10px">${t('backup_hint')}</div></div>`;
}
/* ================= GOOGLE LOGIN ================= */
const GOOGLE_CLIENT_ID='825594104011-h02pqq57t6iasr2h2qgnqceu1tbbp7oe.apps.googleusercontent.com';
let gisInited=false, gisTries=0;
function waitGis(){
  if(gisInited) return;
  if(window.google&&google.accounts&&google.accounts.id){ initGoogle(); return; }
  if(gisTries++<25) setTimeout(waitGis,300);
}
function initGoogle(){
  if(!(window.google&&google.accounts&&google.accounts.id)) return;
  if(gisInited) return;
  try{
    google.accounts.id.initialize({ client_id:GOOGLE_CLIENT_ID, callback:handleGoogleCredential, auto_select:false, cancel_on_tap_outside:true });
    gisInited=true;
    if($('gSignInBtn')) renderGoogleButton();
  }catch(e){}
}
function decodeJwt(tok){
  const base=tok.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');
  const bin=atob(base);
  const json=decodeURIComponent(bin.split('').map(c=>'%'+('00'+c.charCodeAt(0).toString(16)).slice(-2)).join(''));
  return JSON.parse(json);
}
function handleGoogleCredential(res){
  try{
    const p=decodeJwt(res.credential);
    state.account={ name:p.name||'', email:p.email||'', picture:p.picture||'', sub:p.sub||'', at:Date.now() };
    save();
    toast(t('g_signedin')+(p.name?(' — '+p.name):''));
    renderHeaderAvatar();
    if(curModule==='account') rerenderModule();
  }catch(e){ toast(t('g_error')); }
}
function googleSignOut(){
  try{ if(window.google&&google.accounts&&google.accounts.id) google.accounts.id.disableAutoSelect(); }catch(e){}
  state.account=null; save(); toast(t('g_signedout'));
  renderHeaderAvatar();
  if(curModule==='account') rerenderModule();
}
function renderGoogleButton(){
  const el=$('gSignInBtn'); if(!el) return;
  if(!(window.google&&google.accounts&&google.accounts.id)){ el.innerHTML='<div class="hint">'+t('g_loading')+'</div>'; waitGis(); return; }
  try{ el.innerHTML=''; google.accounts.id.renderButton(el,{ theme:'outline', size:'large', shape:'pill', text:'signin_with', logo_alignment:'left', width:280 }); }
  catch(e){ el.innerHTML='<div class="hint">'+t('g_error')+'</div>'; }
}
function renderAccountBits(){ if(!$('gSignInBtn')) return; initGoogle(); renderGoogleButton(); }
function renderHeaderAvatar(){
  const img=$('acctImg'), ico=$('acctIco'); if(!img||!ico) return;
  const a=state.account;
  if(a&&a.picture){ img.src=a.picture; img.style.display='block'; ico.style.display='none'; }
  else { img.removeAttribute('src'); img.style.display='none'; ico.style.display='block'; ico.textContent='👤'; }
}
function fillOwnerFromGoogle(){
  if(!state.account||!state.account.name) return;
  const b=state.settings.business;
  if(!b.owner||confirm(t('g_owner_fill')+'?')){ b.owner=state.account.name; save(); rerenderModule(); toast(t('saved')); }
}
function modAccount(){
  const a=state.account;
  if(a&&a.email){
    return `<div class="card"><h3>${t('g_account')}</h3>
      <div class="list-item" style="padding:10px 0">
        <img class="g-ava" src="${esc(a.picture)}" alt="" onerror="this.style.display='none'"/>
        <div class="li-main"><div class="t">${esc(a.name||a.email)}</div><div class="s">${esc(a.email)}</div></div>
      </div>
      <div class="btn-row" style="margin-top:12px">
        <button class="btn ghost" onclick="fillOwnerFromGoogle()">${t('g_owner_fill')}</button>
        <button class="btn" onclick="openModule('drive')">${t('dr_go')}</button>
      </div>
      <div class="btn-row" style="margin-top:9px">
        <button class="btn danger" style="flex:1" onclick="googleSignOut()">${t('g_signout')}</button>
      </div>
      <div class="hint" style="margin-top:10px">${t('g_note')}</div></div>`;
  }
  return `<div class="card"><h3>${t('g_account')}</h3>
    <div class="hint" style="margin-bottom:14px">${t('g_intro')}</div>
    <div id="gSignInBtn"><div class="hint">${t('g_loading')}</div></div>
    <div class="hint" style="margin-top:12px">${t('g_origin_hint')}</div>
    <div class="hint" style="margin-top:8px;color:var(--amber)">${t('g_test_hint')}</div></div>`;
}
function setBillLang(v){ state.settings.billLang=v; save(); toast(t('saved')); }
function setBillColor(v){ state.settings.billColor=v; save(); toast(t('saved')); }
/* ---- encrypted backup (.milk) ---- */
function b64buf(u8){ let s=''; const CH=0x8000; for(let i=0;i<u8.length;i+=CH) s+=String.fromCharCode.apply(null,u8.subarray(i,i+CH)); return btoa(s); }
function buf64(b){ const s=atob(b); const u=new Uint8Array(s.length); for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u; }
async function encKey(pass,salt){
  const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pass),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt:salt,iterations:150000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function exportEncrypted(){
  try{
    const pass=prompt(t('enc_pass')); if(!pass) return;
    const salt=crypto.getRandomValues(new Uint8Array(16)), iv=crypto.getRandomValues(new Uint8Array(12));
    const key=await encKey(pass,salt);
    const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv:iv},key,new TextEncoder().encode(JSON.stringify(state)));
    const out={v:1,app:'milk-hisaab',salt:b64buf(salt),iv:b64buf(iv),data:b64buf(new Uint8Array(ct))};
    const blob=new Blob([JSON.stringify(out)],{type:'application/octet-stream'});
    const fname='milk-backup-'+todayStr()+'.milk';
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fname; document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(url); a.remove(); }catch(e){} },1500);
    toast('🔒 '+t('enc_saved'));
  }catch(e){ toast(t('enc_fail')); }
}
function importEncrypted(){
  const inp=document.createElement('input'); inp.type='file'; inp.accept='.milk,application/octet-stream,application/json';
  inp.onchange=async function(){
    const f=inp.files[0]; if(!f) return;
    try{
      const pass=prompt(t('enc_pass')); if(!pass) return;
      const obj=JSON.parse(await f.text());
      const key=await encKey(pass,buf64(obj.salt));
      const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:buf64(obj.iv)},key,buf64(obj.data));
      const data=JSON.parse(new TextDecoder().decode(pt));
      if(!data||!data.parties){ toast(t('enc_bad')); return; }
      if(!confirm(t('enc_confirm'))) return;
      setState(migrate(data)); save(); toast('🔓 '+t('enc_restored')); location.reload();
    }catch(e){ toast(t('enc_bad')); }
  };
  inp.click();
}
/* ---- error boundary + log ---- */
function logError(msg,src,line){
  try{ const L=state.settings.errlog||(state.settings.errlog=[]);
    L.unshift({t:Date.now(),m:String(msg).slice(0,220),s:String(src||'').slice(-80)+':'+(line||'')});
    if(L.length>40) L.length=40; save(); }catch(e){}
}
window.addEventListener('error',function(e){ logError(e.message,e.filename,e.lineno); });
window.addEventListener('unhandledrejection',function(e){ logError('promise: '+((e.reason&&e.reason.message)||e.reason)); });
function showErrLog(){
  const L=(state.settings.errlog||[]);
  openModal('<div class="sheet-head"><h2>🩺 '+t('errlog')+'</h2><button class="x" onclick="closeModal()">✕</button></div>'
    +(L.length?L.map(x=>'<div class="list-item"><div class="li-main"><div class="t" style="font-size:12.5px">'+esc(x.m)+'</div><div class="s">'+fmtDateTime(x.t)+' • '+esc(x.s||'')+'</div></div></div>').join(''):'<div class="empty">'+t('errlog_none')+'</div>')
    +'<button class="btn grey" style="margin-top:10px" onclick="state.settings.errlog=[];save();closeModal();toast(\''+t('deleted')+'\')">'+t('errlog_clear')+'</button>');
}
/* ---- data cleanup (3 saal purani entry) ---- */
function dataCleanup(){
  const cut=new Date(); cut.setFullYear(cut.getFullYear()-3); const cs=ymd(cut);
  const old=state.entries.filter(e=>e.date<cs);
  if(!old.length){ toast(t('clean_none')); return; }
  if(!confirm(old.length+' '+t('clean_confirm'))) return;
  const agg={};
  old.forEach(function(e){ const k=e.partyId+'|'+e.date.slice(0,7)+'|'+e.kind; const a=agg[k]||(agg[k]={partyId:e.partyId,month:e.date.slice(0,7),kind:e.kind,qty:0,amt:0,n:0}); a.qty+=e.qty; a.amt+=e.amount; a.n++; });
  state.archive=state.archive||[];
  Object.keys(agg).forEach(function(k){ state.archive.push(agg[k]); });
  state.entries=state.entries.filter(e=>e.date>=cs);
  save(); toast('🧹 '+old.length+' '+t('clean_done'));
}
/* ---- report chart image ---- */
/* ---- Excel (.xlsx) export ---- */
function crc32(buf){ let crc=0xFFFFFFFF;
  for(let i=0;i<buf.length;i++){ crc^=buf[i]; for(let j=0;j<8;j++) crc=(crc>>>1)^(0xEDB88320 & -(crc&1)); }
  return (crc^0xFFFFFFFF)>>>0; }
function zipStore(files){
  const enc=new TextEncoder(), chunks=[], central=[]; let offset=0;
  files.forEach(function(f){
    const nb=enc.encode(f.name), crc=crc32(f.data), size=f.data.length;
    const lh=new Uint8Array(30+nb.length), dv=new DataView(lh.buffer);
    dv.setUint32(0,0x04034b50,true); dv.setUint16(4,20,true); dv.setUint16(8,0,true); dv.setUint32(14,crc,true);
    dv.setUint32(18,size,true); dv.setUint32(22,size,true); dv.setUint16(26,nb.length,true); lh.set(nb,30);
    chunks.push(lh,f.data);
    const ch=new Uint8Array(46+nb.length), cv=new DataView(ch.buffer);
    cv.setUint32(0,0x02014b50,true); cv.setUint16(4,20,true); cv.setUint16(6,20,true);
    cv.setUint32(16,crc,true); cv.setUint32(20,size,true); cv.setUint32(24,size,true);
    cv.setUint16(28,nb.length,true); cv.setUint32(42,offset,true); ch.set(nb,46);
    central.push(ch); offset+=lh.length+size;
  });
  const cdSize=central.reduce((s,c)=>s+c.length,0);
  const end=new Uint8Array(22), ev=new DataView(end.buffer);
  ev.setUint32(0,0x06054b50,true); ev.setUint16(8,files.length,true); ev.setUint16(10,files.length,true);
  ev.setUint32(12,cdSize,true); ev.setUint32(16,offset,true);
  const all=chunks.concat(central,[end]); const total=all.reduce((s,c)=>s+c.length,0);
  const out=new Uint8Array(total); let o=0; all.forEach(c=>{ out.set(c,o); o+=c.length; }); return out;
}
function xmlEsc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function colName(i){ let s=''; i++; while(i>0){ const m=(i-1)%26; s=String.fromCharCode(65+m)+s; i=Math.floor((i-1)/26); } return s; }
function sheetXml(rows, boldFirst){
  let body='';
  rows.forEach(function(row,ri){
    let cells='';
    row.forEach(function(v,ci){
      const ref=colName(ci)+(ri+1);
      const isNum=(typeof v==='number' && isFinite(v));
      const st=(boldFirst&&ri===0)?' s="1"':'';
      cells+='<c r="'+ref+'"'+(isNum?'':' t="inlineStr"')+st+'>'+(isNum?('<v>'+v+'</v>'):('<is><t>'+xmlEsc(v)+'</t></is>'))+'</c>';
    });
    body+='<row r="'+(ri+1)+'">'+cells+'</row>';
  });
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+body+'</sheetData></worksheet>';
}
function exportXlsx(){
  try{
    const months=[]; const now=new Date();
    for(let i=11;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); months.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')); }
    const s1=[[t('exp_month'),t('r_sales'),t('r_purch'),t('r_exp'),t('r_profit')]];
    months.forEach(function(m){
      const sale=state.entries.filter(e=>e.kind==='sale'&&e.date.startsWith(m)).reduce((s,e)=>s+e.amount,0);
      const pur=state.entries.filter(e=>e.kind==='purchase'&&e.date.startsWith(m)).reduce((s,e)=>s+e.amount,0);
      const exp=state.expenses.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+x.amount,0);
      s1.push([m,sale,pur,exp,sale-pur-exp]);
    });
    const s2=[['Date',t('party_lbl'),t('shift'),'Litres',t('rate'),t('amount'),t('sale')]];
    state.entries.slice().sort((a,b)=>a.date.localeCompare(b.date)).slice(-3000).forEach(function(e){
      s2.push([e.date,partyName(e.partyId),shiftLbl(e.shift),e.qty||0,e.rate||0,e.amount||0,e.kind==='sale'?'Sale':'Purchase']);
    });
    const enc=new TextEncoder();
    const files=[
      {name:'[Content_Types].xml',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>')},
      {name:'_rels/.rels',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')},
      {name:'xl/workbook.xml',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Entries" sheetId="2" r:id="rId2"/></sheets></workbook>')},
      {name:'xl/_rels/workbook.xml.rels',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')},
      {name:'xl/styles.xml',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7F5EE"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs></styleSheet>')},
      {name:'xl/worksheets/sheet1.xml',data:enc.encode(sheetXml(s1,true))},
      {name:'xl/worksheets/sheet2.xml',data:enc.encode(sheetXml(s2,true))}
    ];
    const bytes=zipStore(files);
    const blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    const fname='milk-report-'+todayStr()+'.xlsx';
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=fname; document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(url); a.remove(); }catch(e){} },1500);
    toast(t('xlsx_saved'));
  }catch(e){ toast(t('xlsx_fail')); }
}
function reportChartImage(){
  try{
    const months=[]; const now=new Date();
    for(let i=11;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); months.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')); }
    const sale=months.map(m=>state.entries.filter(e=>e.kind==='sale'&&e.date.startsWith(m)).reduce((s,e)=>s+e.amount,0));
    const exp=months.map(m=>state.expenses.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+x.amount,0));
    const W=1000,H=560; const c=document.createElement('canvas'); c.width=W; c.height=H; const g=c.getContext('2d');
    g.fillStyle='#fff'; g.fillRect(0,0,W,H);
    g.fillStyle='#0f7b53'; g.font='bold 22px Arial'; g.fillText(shopName(),40,44);
    g.fillStyle='#666'; g.font='14px Arial'; g.fillText(t('r_sales')+' / '+t('r_exp'),40,68);
    const max=Math.max(1,Math.max.apply(null,sale.concat(exp)));
    const base=H-70, top=100, slot=(W-100)/12, bw=slot*0.34;
    g.strokeStyle='#e2e8e4'; g.beginPath(); g.moveTo(50,base); g.lineTo(W-50,base); g.stroke();
    months.forEach(function(m,i){
      const x=60+i*slot;
      const hs=(base-top)*(sale[i]/max), he=(base-top)*(exp[i]/max);
      g.fillStyle='#0f7b53'; g.fillRect(x,base-hs,bw,hs);
      g.fillStyle='#c0392b'; g.fillRect(x+bw+4,base-he,bw,he);
      g.fillStyle='#666'; g.font='12px Arial'; g.textAlign='center';
      g.fillText(MONTHS[Number(m.slice(5,7))-1], x+bw, base+20); g.textAlign='left';
    });
    const png=c.toDataURL('image/png');
    const a=document.createElement('a'); a.href=png; a.download='report-chart-'+todayStr()+'.png'; document.body.appendChild(a); a.click(); a.remove();
    toast('📈 '+t('chart_saved'));
  }catch(e){ toast(t('dr_fail')); }
}
/* ---- route map (Leaflet) ---- */
function modRouteMap(){
  const list=state.parties.filter(p=>p.type==='customer').sort((a,b)=>(a.route||'').localeCompare(b.route||'')||a.name.localeCompare(b.name));
  return `<div class="card"><h3>📍 ${t('routemap')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('map_hint')}</div>
    <div id="mapBox" style="height:280px;border-radius:14px;overflow:hidden;background:var(--soft);display:grid;place-items:center;color:var(--muted);font-size:13px">${t('map_offline')}</div>
    <div class="btn-row" style="margin-top:10px"><button class="btn grey sm" style="flex:1" onclick="loadLeaflet()">🗺️ ${t('routemap')}</button><button class="btn grey sm" style="flex:1" onclick="loadLeaflet();drawMap()">🔄 ${t('refresh')||'↻'}</button></div>
    <div class="divider"></div>
    ${list.length?list.map(p=>`<div class="list-item"><div class="avatar">🏠</div><div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.route||'—')}${(p.lat&&p.lng)?(' • 📍 '+p.lat.toFixed(4)+', '+p.lng.toFixed(4)):' • '+t('loc_na')}</div></div><button class="btn grey xs" onclick="markPartyLoc('${p.id}')">📍</button></div>`).join(''):'<div class="empty">'+t('no_parties')+'</div>'}
  </div>`;
}
function loadLeaflet(){
  if(window._leafletLoaded && window.L){ try{ drawMap(); }catch(e){} return; }
  try{
    if(!document.getElementById('leaflet-css')){ const css=document.createElement('link'); css.id='leaflet-css'; css.rel='stylesheet'; css.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css); }
    if(document.getElementById('leaflet-js')) return;
    const s=document.createElement('script'); s.id='leaflet-js'; s.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    s.onload=function(){ window._leafletLoaded=true; try{ drawMap(); }catch(e){} };
    s.onerror=function(){ toast(t('map_offline')); };
    document.head.appendChild(s);
  }catch(e){ toast(t('map_offline')); }
}
function drawMap(){
  const box=$('mapBox'); if(!box) return;
  if(!window.L){ toast(t('map_offline')); return; }
  try{
    box.innerHTML=''; box.style.display='block';
    const pts=state.parties.filter(p=>p.type==='customer'&&p.lat&&p.lng);
    const center=pts.length?[pts[0].lat,pts[0].lng]:[22.9734,78.6569];
    const map=L.map(box).setView(center, pts.length?12:5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
    pts.forEach(function(p,i){ L.marker([p.lat,p.lng]).addTo(map).bindPopup((i+1)+'. '+esc(p.name)+(p.route?(' — '+esc(p.route)):'')); });
    if(pts.length>1){ try{ L.polyline(pts.map(function(p){ return [p.lat,p.lng]; }),{color:'#0f7b53',weight:3}).addTo(map); }catch(e){} }
  }catch(e){ toast(t('map_offline')); }
}
function markPartyLoc(id){
  if(!navigator.geolocation){ toast(t('loc_na')); return; }
  navigator.geolocation.getCurrentPosition(function(pos){
    const p=partyById(id); if(!p) return;
    p.lat=pos.coords.latitude; p.lng=pos.coords.longitude;
    save(); toast(t('loc_saved')); rerenderModule();
  },function(){ toast(t('loc_na')); },{enableHighAccuracy:true,timeout:12000});
}
function toggleShiftRemind(){ state.settings.shiftRemind=(state.settings.shiftRemind===false); save(); try{ if($('sw-remind')) $('sw-remind').classList.toggle('on',state.settings.shiftRemind!==false); }catch(e){} toast(state.settings.shiftRemind!==false?'⏰ रिमाइंडर चालू':'⏰ रिमाइंडर बंद'); }
function modSettings(){
  return `<div class="card"><h3>${t('settings')}</h3>
    <div class="field"><label>${t('language')}</label><div class="seg" style="margin-bottom:0"><button id="lang-hi" onclick="setLang('hi')">हिंदी</button><button id="lang-en" onclick="setLang('en')">English</button></div></div>
    <div class="field"><label>${t('biz_name')}</label><input type="text" id="setName" /></div>
    <div class="field"><label>${t('owner')}</label><input type="text" id="setOwner" /></div>
    <div class="field"><label>${t('biz_phone')}</label><input type="tel" id="setPhone" /></div>
    <div class="field"><label>${t('biz_addr')}</label><input type="text" id="setAddr" /></div>
    <div class="sw"><span class="lb">📍 ${t('my_location')}</span><button class="btn grey xs" onclick="getLocation()">${t('get_loc')}</button></div>
    <div class="field" style="margin-top:12px"><label>🤖 ${t('ai_key')}</label><input type="password" id="setAiKey" placeholder="…" /><div class="hint">${t('ai_key_hint')}</div></div>
    <div class="btn-row" style="margin-bottom:8px"><button class="btn grey sm" style="flex:1" onclick="saveAiKey()">${t('save')}</button><button class="btn grey sm" style="flex:1" onclick="clearAiKey()">${t('ai_key_clear')}</button></div>
    <div class="hint" id="locInfo" style="margin-top:-4px"></div>
    <div class="row2"><div class="field"><label>${t('currency')}</label><input type="text" id="setCurrency" maxlength="3" /></div>
      <div class="field"><label>${t('def_rate')}</label><input type="number" step="0.01" inputmode="decimal" id="setDefRate" /></div></div>
    <div class="row2"><div class="field"><label>${t('def_shift')}</label><select id="setDefShift"><option value="morning" id="o-mor"></option><option value="evening" id="o-eve"></option></select></div>
      <div class="field"><label>${t('wa_code')}</label><input type="tel" id="setWaCode" placeholder="91" /></div></div>
    <div class="row2"><div class="field"><label>${t('upi_id')}</label><input type="text" id="setUpi" /></div>
      <div class="field"><label>${t('upi_name')}</label><input type="text" id="setUpiName" /></div></div>
    <div class="field"><label>${t('theme')}</label><div class="themes" id="themeBox"></div></div>
    <div class="row2"><div class="field"><label>🧾 ${t('bill_lang')}</label><select id="setBillLang" onchange="setBillLang(this.value)"><option value="hi">हिंदी</option><option value="en">English</option></select></div>
      <div class="field"><label>🎨 ${t('bill_color')}</label><select id="setBillColor" onchange="setBillColor(this.value)"><option value="">${t('theme')}</option><option value="green">हरा</option><option value="blue">नीला</option><option value="purple">बैंगनी</option><option value="teal">टील</option><option value="maroon">मैरून</option></select></div></div>
    <div class="btn-row" style="margin-bottom:8px"><button class="btn grey sm" style="flex:1" onclick="exportEncrypted()">🔒 ${t('enc_backup')}</button><button class="btn grey sm" style="flex:1" onclick="importEncrypted()">🔓 ${t('enc_restore')}</button></div>
    <div class="btn-row" style="margin-bottom:8px"><button class="btn grey sm" style="flex:1" onclick="dataCleanup()">🧹 ${t('cleanup')}</button><button class="btn grey sm" style="flex:1" onclick="showErrLog()">🩺 ${t('errlog')}</button></div>
    <div class="sw"><span class="lb">${t('dark')}</span><div class="tr" id="sw-dark" onclick="toggleDark()"></div></div>
    <div class="sw"><span class="lb">${t('auto_shift')}</span><div class="tr" id="sw-autoshift" onclick="toggleAutoShift()"></div></div>
    <div class="hint" style="margin-top:-4px">${t('auto_shift_hint')}</div>
    <div class="sw"><span class="lb">⏰ ${t('shift_remind')}</span><div class="tr" id="sw-remind" onclick="toggleShiftRemind()"></div></div>
    <div class="btn-row" style="margin:-2px 0 8px"><button class="btn grey sm" style="flex:1" onclick="requestNotif()">🔔 ${t('notif_on')}</button><button class="btn grey sm" style="flex:1" onclick="testAlarm()">${t('notif_test')}</button></div>
    <div class="hint" style="margin-top:-4px">${t('alarm_hint')}</div>
    <div class="sw"><span class="lb">${t('round')}</span><div class="tr" id="sw-round" onclick="toggleRound()"></div></div>
    <div class="sw"><span class="lb">${t('pin')}</span><div class="tr" id="sw-pin" onclick="togglePin()"></div></div>
    <div class="sw"><span class="lb">${t('bio')}</span><div class="tr" id="sw-bio" onclick="toggleBio()"></div></div>
    <div class="hint" style="margin-top:-4px">${t('bio_hint')}</div>
    <div class="sw"><span class="lb">${t('auto_backup')}</span><div class="tr" id="sw-ab" onclick="toggleAutoBackup()"></div></div>
    <div class="field" style="margin-top:12px"><label>${t('retention')}</label><select id="setRetention" onchange="saveSettings()"><option value="6" id="o-r6"></option><option value="12" id="o-r12"></option><option value="24" id="o-r24"></option><option value="36" id="o-r36"></option><option value="0" id="o-r0"></option></select><div class="hint">${t('retention_hint')}</div></div>
    <div class="field"><label>${t('backup_days')}</label><input type="number" id="setBackupDays" min="1" value="7" /></div>
    <div class="field"><label>${t('target')}</label><input type="number" step="1" inputmode="numeric" id="setTarget" value="0" /></div>
    <div class="field"><label>${t('cat_mgr')}</label><div id="catList"></div>
      <div style="display:flex;gap:8px;margin-top:8px"><input type="text" id="newCat" style="flex:1" /><button class="btn ghost sm" onclick="addCat()">➕</button></div></div>
    <button class="btn" style="margin-top:12px" onclick="saveSettings()">${t('save')}</button></div>`;
}
function renderSettingsBits(){
  if($('sw-dark')) $('sw-dark').classList.toggle('on',!!state.settings.dark);
  if($('sw-autoshift')) $('sw-autoshift').classList.toggle('on',state.settings.autoShift!==false);
  if($('sw-remind')) $('sw-remind').classList.toggle('on',state.settings.shiftRemind!==false);
  try{ if($('setBillLang')) $('setBillLang').value=state.settings.billLang||LANG; }catch(e){}
  try{ if($('setBillColor')) $('setBillColor').value=state.settings.billColor||''; }catch(e){}
  if($('sw-round')) $('sw-round').classList.toggle('on',!!state.settings.roundOff);
  if($('sw-pin')) $('sw-pin').classList.toggle('on',!!state.settings.pin);
  if($('sw-bio')) $('sw-bio').classList.toggle('on',!!state.settings.biometricLock);
  try{ renderLocInfo(); }catch(e){}
  try{ if($('setAiKey')) $('setAiKey').value=getAiKey(); }catch(e){}
  if($('sw-ab')) $('sw-ab').classList.toggle('on',!!state.settings.autoBackup);
  if($('themeBox')){ const themes=[['green','theme_green','#0f7b53'],['blue','theme_blue','#1d6fb8'],['purple','theme_purple','#7b3fb0'],['teal','theme_teal','#0c7b7b']];
    $('themeBox').innerHTML=themes.map(([k,lbl,c])=>`<button class="theme-dot ${state.settings.theme===k?'on':''}" style="background:${c}" onclick="setTheme('${k}')"></button>`).join(''); }
  if($('catList')){ const cc=state.settings.customCats||[];
    $('catList').innerHTML=cc.length?cc.map(c=>`<div class="list-item" style="padding:8px 0"><div class="avatar" style="background:var(--blue-l);color:var(--blue)">🏷️</div>
      <div class="li-main"><div class="t">${esc(c.name)}</div></div><button class="btn danger xs" onclick="delCat('${c.id}')">🗑</button></div>`).join(''):'<div class="hint">'+t('no_custom_cat')+'</div>'; }
  fillSettings();
}
function fillSettings(){
  const b=state.settings.business;
  if($('setName')){ $('setName').value=b.name; $('setOwner').value=b.owner||''; $('setPhone').value=b.phone||''; $('setAddr').value=b.address||'';
    $('setCurrency').value=state.settings.currency; $('setDefRate').value=state.settings.defaultRate; $('setDefShift').value=state.settings.defaultShift||'morning';
    $('setWaCode').value=state.settings.waCode||'91'; $('setUpi').value=state.settings.upi||''; $('setUpiName').value=state.settings.upiName||'';
    $('setRetention').value=String(state.settings.retention==null?12:state.settings.retention); $('setBackupDays').value=state.settings.autoBackupDays||7;
    $('setTarget').value=state.settings.target||0; }
  if($('lang-hi')) $('lang-hi').classList.toggle('on',LANG==='hi');
  if($('lang-en')) $('lang-en').classList.toggle('on',LANG==='en');
  if($('o-mor')) $('o-mor').textContent=t('morning');
  if($('o-eve')) $('o-eve').textContent=t('evening');
  ['6','12','24','36','0'].forEach(v=>{ const el=$('o-r'+v); if(el) el.textContent=t('ret_'+v); });
}
function addCat(){ const v=$('newCat').value.trim(); if(!v){ toast(t('enter_name')); return; }
  state.settings.customCats=state.settings.customCats||[]; state.settings.customCats.push({id:'c'+uid(),name:v}); $('newCat').value=''; save(); renderSettingsBits(); toast(t('cat_added')); }
function delCat(id){ state.settings.customCats=(state.settings.customCats||[]).filter(c=>c.id!==id); save(); renderSettingsBits(); toast(t('deleted')); }
function saveSettings(){
  const b=state.settings.business;
  b.name=$('setName').value.trim()||b.name; b.owner=$('setOwner').value.trim(); b.phone=$('setPhone').value.trim(); b.address=$('setAddr').value.trim();
  state.settings.currency=($('setCurrency').value.trim()||'₹').slice(0,3);
  state.settings.defaultRate=parseFloat($('setDefRate').value)||state.settings.defaultRate;
  state.settings.defaultShift=$('setDefShift').value; state.settings.waCode=$('setWaCode').value.replace(/\D/g,'')||'91';
  state.settings.upi=$('setUpi').value.trim(); state.settings.upiName=$('setUpiName').value.trim();
  state.settings.retention=parseInt($('setRetention').value,10)||0; state.settings.autoBackupDays=parseInt($('setBackupDays').value,10)||7;
  state.settings.target=parseFloat($('setTarget').value)||0;
  save(); applyStatic(); applyTheme(); refreshAll(); rerenderModule(); toast(t('saved'));
}
function modHelp(){
  return `<div class="card"><h3>${t('help')}</h3><div style="white-space:pre-line;font-size:14.5px;line-height:1.6">${t('help_body')}</div>
    <div class="divider"></div><div class="hint">${shopName()} · v11 · ${state.parties.length} ${t('party_lbl')} · ${state.entries.length} ${t('entry_count')}</div></div>`;
}

/* ================= BACKUP / CLOUD ================= */
let fsHandle=null;
function idbOpen(){ return new Promise((res,rej)=>{ try{ const r=indexedDB.open('milkdb',1); r.onupgradeneeded=()=>{ if(!r.result.objectStoreNames.contains('kv')) r.result.createObjectStore('kv'); }; r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }catch(e){ rej(e); } }); }
async function idbSet(k,v){ const db=await idbOpen(); return new Promise((res,rej)=>{ const t=db.transaction('kv','readwrite'); t.objectStore('kv').put(v,k); t.oncomplete=()=>res(); t.onerror=()=>rej(t.error); }); }
async function idbGet(k){ const db=await idbOpen(); return new Promise((res,rej)=>{ const t=db.transaction('kv','readonly'); const q=t.objectStore('kv').get(k); q.onsuccess=()=>res(q.result); q.onerror=()=>rej(q.error); }); }
async function idbDel(k){ const db=await idbOpen(); return new Promise((res)=>{ const t=db.transaction('kv','readwrite'); t.objectStore('kv').delete(k); t.oncomplete=()=>res(); }); }
async function loadHandle(){ try{ fsHandle=(await idbGet('backupFile'))||null; }catch(e){ fsHandle=null; } cloudStatus(); }
function cloudStatus(){ const el=$('cloudStatus'); if(!el) return; el.textContent=fsHandle?((fsHandle.name||'file')+(state.settings.lastExport?' · '+fmtDate(ymd(new Date(state.settings.lastExport))):'')):t('no_link'); }
function download(name,content,type){
  try{ if(window.MilkNative&&window.MilkNative.saveText){ window.MilkNative.saveText(name, (typeof content==='string')?content:JSON.stringify(content)); toast(t('saved')); return; } }catch(e){}
  const blob=new Blob([content],{type:type||'text/plain;charset=utf-8'});
  const url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download=name; document.body.appendChild(a); a.click();
  setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},100);
}
function shareBackup(){
  const data=JSON.stringify(state,null,2); state.settings.lastExport=Date.now(); try{ localStorage.setItem(STORE_KEY,JSON.stringify(state)); }catch(e){}
  const file=new File([data],'milk-backup-'+todayStr()+'.json',{type:'application/json'});
  if(navigator.canShare&&navigator.canShare({files:[file]})){ navigator.share({files:[file],title:'Milk backup'}).then(()=>{ toast(t('cloud_saved')); renderBackupReminder(); cloudStatus(); }).catch(()=>{}); return; }
  download('milk-backup-'+todayStr()+'.json',data,'application/json'); toast(t('backup_saved')); renderBackupReminder(); cloudStatus();
}
async function linkBackupFile(){
  if(!window.showSaveFilePicker){ toast(t('link_fail')); return; }
  try{ const h=await window.showSaveFilePicker({suggestedName:'milk-backup.json',types:[{description:'JSON',accept:{'application/json':['.json']}}]});
    fsHandle=h; await idbSet('backupFile',h); cloudStatus(); toast(t('linked_ok')); await writeBackupToLinked(); cloudStatus(); }catch(e){}
}
async function unlinkBackup(){ fsHandle=null; try{ await idbDel('backupFile'); }catch(e){} cloudStatus(); toast(t('saved')); }
async function writeBackupToLinked(){
  if(!fsHandle) return false;
  try{ let perm='granted'; if(fsHandle.queryPermission){ perm=await fsHandle.queryPermission({mode:'readwrite'}); if(perm!=='granted'&&fsHandle.requestPermission) perm=await fsHandle.requestPermission({mode:'readwrite'}); }
    if(perm!=='granted') return false; const w=await fsHandle.createWritable(); await w.write(JSON.stringify(state)); await w.close(); state.settings.lastExport=Date.now(); return true; }catch(e){ return false; }
}
async function restoreLinked(){ if(!fsHandle){ toast(t('no_link')); return; }
  try{ const f=await fsHandle.getFile(); const txt=await f.text(); applyImported(txt); }catch(e){ toast(t('backup_bad')); } }
function applyImported(txt){ try{ const d=JSON.parse(txt); if(!d.parties||!d.entries) throw 0; if(!confirm(t('c_load_backup'))) return;
    setState(deepDefaults(d)); save(); applyTheme(); applyStatic(); refreshAll(); rerenderModule(); toast(t('backup_loaded')); }catch(e){ toast(t('backup_bad')); } }
function exportBackup(){ state.settings.lastExport=Date.now(); try{ localStorage.setItem(STORE_KEY,JSON.stringify(state)); }catch(e){}
  download('milk-backup-'+todayStr()+'.json',JSON.stringify(state,null,2),'application/json'); toast(t('backup_saved')); renderBackupReminder(); cloudStatus(); }
function importBackup(ev){ const f=ev.target.files[0]; if(!f) return; const r=new FileReader(); r.onload=()=>applyImported(r.result); r.readAsText(f); ev.target.value=''; }
function exportCSV(){
  if(!state.entries.length){ toast(t('no_data_toast')); return; }
  const head=['Date','Party','Item','Type','Shift','Litres','Fat','Rate','Amount'];
  const rows=state.entries.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(e=>{ const p=partyById(e.partyId); const it=itemById(p,e.itemId);
    return [e.date,partyName(e.partyId),it?it.name:'',e.kind,shiftLbl(e.shift),e.qty,e.fat||'',e.rate,e.amount]; });
  const csv='\uFEFF'+[head,...rows].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  download('milk-entries-'+todayStr()+'.csv',csv,'text/csv;charset=utf-8'); toast(t('csv_saved'));
}
function purgeOld(){ const months=state.settings.retention; if(!months) return 0;
  const cut=new Date(); cut.setMonth(cut.getMonth()-months); const cutStr=ymd(cut);
  const before=state.entries.length+state.payments.length+state.expenses.length;
  /* ज़िप: हटाने से पहले पुरानी एंट्री का सारांश सुरक्षित रखें */
  try{
    const oldE=state.entries.filter(e=>e.date<cutStr);
    if(oldE.length){
      state.archive=state.archive||[];
      const agg={};
      oldE.forEach(function(e){ const k=e.partyId+'|'+e.date.slice(0,7)+'|'+e.kind; const a=agg[k]||(agg[k]={partyId:e.partyId,month:e.date.slice(0,7),kind:e.kind,qty:0,amt:0,n:0}); a.qty+=e.qty; a.amt+=e.amount; a.n++; });
      Object.keys(agg).forEach(function(k){ state.archive.push(agg[k]); });
      state.archiveMeta={at:Date.now(),from:cutStr,entries:oldE.length};
    }
  }catch(e){}
  state.entries=state.entries.filter(e=>e.date>=cutStr); state.payments=state.payments.filter(x=>x.date>=cutStr); state.expenses=state.expenses.filter(x=>x.date>=cutStr);
  return before-(state.entries.length+state.payments.length+state.expenses.length);
}
function takeAutoBackup(){
  try{ localStorage.setItem('milk_auto_backup',JSON.stringify({ts:Date.now(),data:state})); }
  catch(e){ try{ const slim=JSON.parse(JSON.stringify(state)); slim.parties.forEach(p=>p.photo=''); localStorage.setItem('milk_auto_backup',JSON.stringify({ts:Date.now(),data:slim})); }catch(e2){ return; } }
  state.settings.lastBackup=Date.now(); try{ localStorage.setItem(STORE_KEY,JSON.stringify(state)); }catch(e){}
}
function restoreAutoBackup(){ const raw=localStorage.getItem('milk_auto_backup'); if(!raw){ toast(t('no_auto')); return; }
  try{ const snap=JSON.parse(raw); if(!confirm(t('c_restore'))) return; setState(deepDefaults(snap.data)); save(); applyTheme(); applyStatic(); refreshAll(); rerenderModule(); toast(t('restored')); }catch(e){ toast(t('backup_bad')); } }
function cleanNow(){ const n=purgeOld(); save(); refreshAll(); rerenderModule(); toast(n?n+' '+t('purged'):t('no_data_toast')); }
function renderDataUsage(){ const el=$('dataUsage'); if(!el) return;
  let bytes=0; try{ bytes=new Blob([JSON.stringify(state)]).size; }catch(e){ bytes=JSON.stringify(state).length; }
  const kb=bytes/1024; const size=kb>1024?(kb/1024).toFixed(1)+' MB':kb.toFixed(0)+' KB';
  el.textContent=size+' · '+state.entries.length+' '+t('entries_count'); }
function renderBackupReminder(){ const card=$('bkRemindCard'); if(!card) return;
  if(!state.settings.autoBackup){ card.style.display='none'; return; }
  const days=state.settings.autoBackupDays||7, last=state.settings.lastExport||0;
  if((Date.now()-last)<=days*86400000){ card.style.display='none'; return; }
  card.style.display='block'; $('bkRemindTxt').textContent=t('backup_reminder'); }
function autoMaintenance(){ try{
  if(state.settings.autoBackup && (Date.now()-(state.settings.lastBackup||0))>20*3600*1000) takeAutoBackup();
  const n=purgeOld(); if(n>0){ save(); toast(n+' '+t('purged')); }
  if(state.settings.autoBackup) writeBackupToLinked();
}catch(e){} }
function clearAll(){ if(!confirm(t('c_clear1'))) return; if(!confirm(t('c_clear2'))) return;
  const keep={lang:state.settings.lang,theme:state.settings.theme,dark:state.settings.dark,business:state.settings.business};
  setState(defaultState()); Object.assign(state.settings,keep); save(); applyTheme(); applyStatic(); refreshAll(); rerenderModule(); toast(t('all_cleared')); }
function chartCanvas(){
  const days=[], now=new Date(); for(let i=6;i>=0;i--){ const d=new Date(now); d.setDate(now.getDate()-i); days.push(d); }
  const vals=days.map(d=>{ const ds=ymd(d); return (IDX.date[ds]||{}).sale||0; });
  const max=Math.max(1,...vals); const W=900,H=520,pad=60,base=H-90,bw=(W-pad*2)/7*0.6,gap=(W-pad*2)/7;
  const c=document.createElement('canvas'); c.width=W; c.height=H; const g=c.getContext('2d');
  g.fillStyle='#fff'; g.fillRect(0,0,W,H);
  g.fillStyle='#0f7b53'; g.font='bold 34px Arial'; g.fillText(shopName(),pad,58);
  g.fillStyle='#666'; g.font='20px Arial'; g.fillText(t('chart'),pad,90);
  days.forEach((d,i)=>{ const x=pad+i*gap+(gap-bw)/2, h=Math.max(6,Math.round(vals[i]/max*300)), y=base-h;
    g.fillStyle=(i===6)?'#b7791f':'#0f7b53'; g.beginPath(); const rr=10; g.moveTo(x,y+rr); g.arcTo(x,y,x+rr,y,rr); g.arcTo(x+bw,y,x+bw,y+rr,rr); g.lineTo(x+bw,base); g.lineTo(x,base); g.closePath(); g.fill();
    g.fillStyle='#333'; g.font='16px Arial'; g.textAlign='center'; g.fillText(cur()+Math.round(vals[i]),x+bw/2,y-10);
    g.fillStyle='#666'; g.fillText(DOW[LANG][d.getDay()],x+bw/2,base+28); g.textAlign='left'; });
  g.strokeStyle='#ddd'; g.beginPath(); g.moveTo(pad,base); g.lineTo(W-pad,base); g.stroke(); return c;
}
function shareChart(){ const c=chartCanvas();
  c.toBlob(async blob=>{ const file=new File([blob],'milk-chart.png',{type:'image/png'});
    try{ if(navigator.canShare&&navigator.canShare({files:[file]})){ await navigator.share({files:[file],title:t('chart')}); return; } }catch(e){}
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='milk-chart-'+todayStr()+'.png'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); toast(t('saved')); },'image/png'); }

/* ================= DAILY REGISTER (morning + evening) ================= */
function regEntry(partyId,date,shift){ return state.entries.find(e=>e.partyId===partyId&&e.date===date&&e.shift===shift); }
function modRegister(){
  const routes=[...new Set(state.parties.filter(p=>p.type==='customer').map(p=>p.route).filter(Boolean))];
  return `<div class="card">
    <div class="hint" style="margin-bottom:10px">${t('register_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('date')}</label><input type="date" id="regDate" value="${todayStr()}" onchange="renderRegister()" /></div>
      <div class="field" style="margin:0"><label>${t('route_filter')}</label><select id="regRoute" onchange="renderRegister()"><option value="">${t('all_routes')}</option>${routes.map(r=>`<option>${esc(r)}</option>`).join('')}</select></div>
    </div>
    <div style="overflow-x:auto"><table id="regTable"></table></div>
    <div class="hint" style="margin-top:6px">${t('reg_clear')}</div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost" onclick="shareRegister()">${t('send')}</button><button class="btn ghost" onclick="printRegister()">${t('print')}</button></div>
  </div>`;
}
function renderRegister(){
  const el=$('regTable'); if(!el) return;
  const date=$('regDate').value||todayStr(); const route=$('regRoute').value||'';
  let custs=state.parties.filter(p=>p.type==='customer'&&p.active!==false);
  if(route) custs=custs.filter(c=>c.route===route);
  if(!custs.length){ el.innerHTML=`<tbody><tr><td style="padding:16px;color:var(--muted)">${t('reg_none')}</td></tr></tbody>`; return; }
  let tm=0,te=0,ta=0;
  let html=`<thead><tr><th>${t('party_lbl')}</th><th>${t('reg_morning')}</th><th>${t('reg_evening')}</th><th>${t('reg_total')}</th><th>${cur()}</th></tr></thead><tbody>`;
  custs.forEach(c=>{ const me=regEntry(c.id,date,'morning'), ev=regEntry(c.id,date,'evening');
    const mq=me?me.qty:0, eq=ev?ev.qty:0, amt=(me?me.amount:0)+(ev?ev.amount:0); tm+=mq; te+=eq; ta+=amt;
    const inp=(shift,val)=>`<input type="number" step="0.01" inputmode="decimal" value="${val||''}" placeholder="0" style="width:70px;padding:6px;border:1.5px solid var(--line);border-radius:8px;background:var(--card);text-align:right" onchange="regSet('${c.id}','${shift}',this.value)" />`;
    html+=`<tr><td>${esc(c.name)}</td><td>${inp('morning',mq)}</td><td>${inp('evening',eq)}</td><td>${num(mq+eq)}</td><td>${num(amt)}</td></tr>`; });
  html+=`<tr style="font-weight:800"><td>${t('total')}</td><td>${num(tm)}</td><td>${num(te)}</td><td>${num(tm+te)}</td><td>${num(ta)}</td></tr></tbody>`;
  el.innerHTML=html;
}
function regSet(partyId,shift,val){
  const date=$('regDate').value||todayStr(); const c=partyById(partyId); const qty=parseFloat(val)||0;
  const ex=regEntry(partyId,date,shift);
  if(qty<=0){ if(ex) state.entries=state.entries.filter(e=>e.id!==ex.id); }
  else { const r=calcAmount(c,qty,0,'','');
    if(ex){ ex.qty=qty; ex.rate=r.rate; ex.amount=r.amount; }
    else state.entries.push({id:uid(),date,partyId,itemId:'',kind:'sale',shift,qty,fat:0,rate:r.rate,amount:r.amount}); }
  save(); renderRegister(); renderHome(); toast(t('reg_saved'));
}
function registerText(){
  const date=$('regDate').value||todayStr(); const route=$('regRoute').value||'';
  let custs=state.parties.filter(p=>p.type==='customer'&&p.active!==false); if(route) custs=custs.filter(c=>c.route===route);
  let s='🥛 '+shopName()+'\n'+t('register')+' — '+fmtDate(date)+'\n────────────\n'; let tm=0,te=0;
  custs.forEach(c=>{ const me=regEntry(c.id,date,'morning'), ev=regEntry(c.id,date,'evening'); const mq=me?me.qty:0, eq=ev?ev.qty:0; tm+=mq; te+=eq;
    if(mq||eq) s+=c.name+': '+t('morning')+' '+num(mq)+' | '+t('evening')+' '+num(eq)+'\n'; });
  s+='────────────\n'+t('total')+': '+t('morning')+' '+num(tm)+' | '+t('evening')+' '+num(te)+'\n'+t('thank'); return s;
}
function shareRegister(){ const txt=registerText(); if(navigator.share) navigator.share({title:t('register'),text:txt}).catch(()=>{}); else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(()=>{}); toast(t('copied')); } }
function printRegister(){
  const date=$('regDate').value||todayStr(); const route=$('regRoute').value||'';
  let custs=state.parties.filter(p=>p.type==='customer'&&p.active!==false); if(route) custs=custs.filter(c=>c.route===route);
  const w=window.open('','_blank'); if(!w) return;
  let tm=0,te=0,ta=0; let rows='';
  custs.forEach(c=>{ const me=regEntry(c.id,date,'morning'), ev=regEntry(c.id,date,'evening'); const mq=me?me.qty:0, eq=ev?ev.qty:0, amt=(me?me.amount:0)+(ev?ev.amount:0); tm+=mq; te+=eq; ta+=amt;
    rows+=`<tr><td>${esc(c.name)}</td><td>${num(mq)}</td><td>${num(eq)}</td><td>${num(mq+eq)}</td><td>${num(amt)}</td></tr>`; });
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t('register')}</title><style>body{font-family:Arial,'Noto Sans Devanagari',sans-serif;padding:20px;max-width:700px;margin:auto}h1{font-size:19px}h2{font-size:14px;color:#555;font-weight:500}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:6px;text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f2f6f4;font-size:11px}tr.t{font-weight:800}.hd{border-bottom:2px solid ${themeHex()};padding-bottom:10px;margin-bottom:12px}</style></head><body>
    <div class="hd"><h1>${esc(shopName())}</h1><h2>${t('register')} — ${fmtDate(date)}</h2></div>
    <table><thead><tr><th>${t('party_lbl')}</th><th>${t('reg_morning')}</th><th>${t('reg_evening')}</th><th>${t('reg_total')}</th><th>${cur()}</th></tr></thead><tbody>${rows}
    <tr class="t"><td>${t('total')}</td><td>${num(tm)}</td><td>${num(te)}</td><td>${num(tm+te)}</td><td>${num(ta)}</td></tr></tbody></table>
    <script>setTimeout(function(){window.print();},350);<\/script></body></html>`); w.document.close();
}

/* ================= GOOGLE DRIVE ================= */
/* ================= GOOGLE DRIVE BACKUP ================= */
function modDrive(){
  const signed=!!(state.account&&state.account.email);
  const ready=driveReady();
  const last=state.settings.lastDriveBackup||0;
  return `<div class="card"><h3>${t('dr_title')}</h3>
    <div class="hint" style="margin-bottom:12px">${t('dr_intro')}</div>
    ${signed?'':`<div class="hint" style="color:var(--amber);margin-bottom:10px">${t('dr_login_first')}</div>`}
    <div class="bill-line"><span class="k">${t('dr_status')}</span><span class="v" id="drStatus">${ready?t('dr_connected'):t('dr_notconn')}</span></div>
    <div class="btn-row" style="margin:10px 0">
      <button class="btn ${ready?'ghost':''}" onclick="connectDrive()">${ready?t('dr_reconnect'):t('dr_connect')}</button>
      <button class="btn" onclick="driveBackupNow(false)">${t('dr_backup_now')}</button>
    </div>
    <div class="sw"><span class="lb">${t('dr_auto')}</span><div class="tr" id="sw-driveauto" onclick="toggleDriveAuto()"></div></div>
    <div class="hint">${t('dr_auto_hint')}</div>
    <div class="bill-line" style="margin-top:10px"><span class="k">${t('dr_last')}</span><span class="v" id="drLast">${last?fmtDateTime(last):t('dr_never')}</span></div>
    <div class="btn-row" style="margin-top:10px">
      <button class="btn grey sm" onclick="driveRestoreLatest()">♻️ ${t('dr_restore')}</button>
      <button class="btn grey sm" onclick="driveOpenFile()">🔗 ${t('dr_open_file')}</button>
    </div>
    <div class="hint" style="margin-top:10px">${t('dr_scope_hint')}</div></div>`;
}
function fmtDateTime(ts){ const d=new Date(ts); const p=n=>String(n).padStart(2,'0'); return p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear()+' '+p(d.getHours())+':'+p(d.getMinutes()); }
function renderDriveBits(){
  const el=$('sw-driveauto'); if(el) el.classList.toggle('on',!!state.settings.driveAuto);
  const st=$('drStatus'); if(st) st.textContent=driveReady()?t('dr_connected'):t('dr_notconn');
  const la=$('drLast'); if(la) la.textContent=(state.settings.lastDriveBackup||0)?fmtDateTime(state.settings.lastDriveBackup):t('dr_never');
}
function toggleDriveAuto(){
  state.settings.driveAuto=!state.settings.driveAuto; save();
  renderDriveBits(); if(curModule==='drive') rerenderModule();
  toast(state.settings.driveAuto?t('dr_auto_on'):t('dr_auto_off'));
  if(state.settings.driveAuto && !driveReady()) connectDrive();
}
function initDriveAuth(){
  if(!(window.google&&google.accounts&&google.accounts.oauth2)) return;
  if(tokenClient) return;
  try{
    tokenClient=google.accounts.oauth2.initTokenClient({
      client_id:GOOGLE_CLIENT_ID,
      scope:'https://www.googleapis.com/auth/drive.file',
      callback:function(resp){
        if(resp&&resp.access_token){ driveToken=resp.access_token; driveTokenExp=Date.now()+(((resp.expires_in||3600)-60)*1000); onDriveConnected(); }
        else { toast(t('dr_authfail')); }
      }
    });
  }catch(e){}
}
function connectDrive(){ initDriveAuth(); if(!tokenClient){ toast(t('dr_needlogin')); return; } try{ tokenClient.requestAccessToken({prompt:''}); }catch(e){ toast(t('dr_authfail')); } }
function driveReady(){ return !!driveToken && Date.now()<driveTokenExp; }
function onDriveConnected(){ state.settings.driveConnected=true; try{ save(); }catch(e){} toast(t('dr_connected')); renderDriveBits(); if(curModule==='drive') rerenderModule(); if(state.settings.driveAuto) driveBackupNow(true); try{ markSynced(); state.settings.lastDriveBackup=Date.now(); save(); renderSyncCard(); }catch(e){} }
function driveHeaders(extra){ return Object.assign({Authorization:'Bearer '+driveToken}, extra||{}); }
async function findBackupFile(){
  const q=encodeURIComponent("name='milk-backup.json' and trashed=false");
  const res=await fetch('https://www.googleapis.com/drive/v3/files?spaces=drive&q='+q+'&fields=files(id,name,modifiedTime)&orderBy=modifiedTime desc',{headers:driveHeaders()});
  if(!res.ok) throw new Error('find '+res.status);
  const j=await res.json(); return (j.files&&j.files[0])||null;
}
async function driveUpload(){
  const body=JSON.stringify(state);
  let id=state.settings.driveFileId||'';
  if(id){
    const res=await fetch('https://www.googleapis.com/upload/drive/v3/files/'+encodeURIComponent(id)+'?uploadType=media&fields=id',{method:'PATCH',headers:driveHeaders({'Content-Type':'application/json'}),body});
    if(!res.ok){ if(res.status===404) id=''; else throw new Error('upd '+res.status); }
  }
  if(!id){
    const found=await findBackupFile();
    if(found){
      id=found.id;
      const res=await fetch('https://www.googleapis.com/upload/drive/v3/files/'+encodeURIComponent(id)+'?uploadType=media&fields=id',{method:'PATCH',headers:driveHeaders({'Content-Type':'application/json'}),body});
      if(!res.ok) throw new Error('upd2 '+res.status);
    } else {
      const meta={name:'milk-backup.json',mimeType:'application/json'};
      const boundary='milkbnd'+Date.now();
      const mp='--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'+JSON.stringify(meta)+'\r\n--'+boundary+'\r\nContent-Type: application/json\r\n\r\n'+body+'\r\n--'+boundary+'--';
      const res=await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id',{method:'POST',headers:driveHeaders({'Content-Type':'multipart/related; boundary='+boundary}),body:mp});
      if(!res.ok){ const tx=await res.text(); throw new Error('new '+res.status+' '+tx.slice(0,150)); }
      const j=await res.json(); id=j.id;
    }
  }
  state.settings.driveFileId=id; state.settings.lastDriveBackup=Date.now();
  driveSelfSave=true; save(); driveSelfSave=false;
}
async function driveBackupNow(silent){
  if(driveBusy) return false;
  if(!driveReady()){ if(!silent) connectDrive(); return false; }
  if(!navigator.onLine){ if(!silent) toast(t('off_msg')); return false; }
  driveBusy=true;
  const st=$('drStatus'); if(st) st.textContent=t('dr_syncing');
  try{ await driveUpload(); if(!silent) toast(t('dr_saved')); return true; }
  catch(e){ if(!silent) toast(t('dr_fail')); return false; }
  finally{ driveBusy=false; renderDriveBits(); if(curModule==='drive') rerenderModule(); }
}
function scheduleAutoDriveBackup(){
  if(driveSelfSave) return;
  if(!state.settings.driveAuto||!driveReady()||!navigator.onLine) return;
  clearTimeout(autoBackupTimer);
  autoBackupTimer=setTimeout(function(){ driveBackupNow(true); },6000);
}
async function driveRestoreLatest(){
  if(!driveReady()){ connectDrive(); return; }
  try{
    const f=await findBackupFile(); if(!f){ toast(t('dr_none')); return; }
    const res=await fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(f.id)+'?alt=media',{headers:driveHeaders()});
    if(!res.ok){ toast(t('dr_fail')); return; }
    const txt=await res.text(); applyImported(txt);
  }catch(e){ toast(t('dr_fail')); }
}
function driveOpenFile(){ if(state.settings.driveFileId) window.open('https://drive.google.com/file/d/'+state.settings.driveFileId+'/view','_blank'); else toast(t('dr_none')); }
/* ---- online / offline + PWA ---- */
function updateOnlineStatus(){
  const bar=$('netBar'); if(!bar) return;
  if(navigator.onLine){ bar.style.display='none'; }
  else { bar.textContent=t('off_msg'); bar.style.display='block'; }
}
function initOnline(){
  window.addEventListener('online',function(){ updateOnlineStatus(); toast(t('on_msg')); if(state.settings.driveAuto) scheduleAutoDriveBackup(); });
  window.addEventListener('offline',updateOnlineStatus);
  updateOnlineStatus();
}
function registerSW(){ try{ if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(function(){}); }catch(e){} }

/* ================= NEW MODULES ================= */
/* ---- 📅 Calendar ---- */
let calMonth='';
function modCalendar(){
  if(!calMonth) calMonth=monthStr();
  return `<div class="card">
    <div class="btn-row" style="margin-bottom:10px">
      <button class="btn grey sm" onclick="calMove(-1)">◀</button>
      <button class="btn ghost sm" onclick="calToday()">${fmtMonth(calMonth)}</button>
      <button class="btn grey sm" onclick="calMove(1)">▶</button>
    </div>
    <div id="calBox"></div>
    <div class="hint" style="margin-top:10px">${t('cal_hint')}</div></div>`;
}
function calMove(d){ const [y,m]=calMonth.split('-').map(Number); const dt=new Date(y,m-1+d,1); calMonth=dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0'); rerenderModule(); }
function calToday(){ calMonth=monthStr(); rerenderModule(); }
function calOpen(date){ const el=$('entryDate'); if(el) el.value=date; switchTab('entries'); renderEntries(); }
function renderCalendar(){
  const box=$('calBox'); if(!box) return;
  const [y,m]=calMonth.split('-').map(Number);
  const startDow=(new Date(y,m-1,1).getDay()+6)%7;
  const days=lastDay(y,m); const D=IDX.date; const today=todayStr();
  const dow=DOW[LANG].slice(1).concat(DOW[LANG][0]);
  const calAgg={};
  state.entries.forEach(function(e){ if(e.kind!=='sale'||!e.date||!e.date.startsWith(calMonth)) return;
    const r=calAgg[e.date]||(calAgg[e.date]={m:0,e:0}); if(e.shift==='evening') r.e+=e.qty; else r.m+=e.qty; });
  let html='<div class="cal">'+dow.map(d=>`<div class="cal-h">${d}</div>`).join('');
  for(let i=0;i<startDow;i++) html+='<div class="cal-c empty"></div>';
  for(let d=1;d<=days;d++){
    const ds=y+'-'+String(m).padStart(2,'0')+'-'+String(d).padStart(2,'0');
    const rec=D[ds]; const q=rec?rec.qty:0; const a=rec?rec.sale:0;
    const ag=calAgg[ds]||{m:0,e:0};
    const bar=`<div class="bar ${(ag.m>0&&ag.e>0)?'both':''}"><i class="${ag.m>0?'m':''}"></i><i class="${ag.e>0?'e':''}"></i></div>`;
    html+=`<div class="cal-c ${ds===today?'today':''}" onclick="calOpen('${ds}')"><span class="d">${d}</span>${q?`<span class="q">${num(q)}L</span>`:''}${bar}</div>`;
  }
  html+='</div>';
  box.innerHTML=html;
}
/* ---- 🏆 Top customers ---- */
function modTopCust(){
  return `<div class="card">
    <div class="seg"><button id="tc-m" class="on" onclick="renderTopCust('month')">${t('rep_month')}</button><button id="tc-y" onclick="renderTopCust('year')">${t('rep_yearwise')}</button></div>
    <div id="tcBox" style="margin-top:12px"></div></div>`;
}
function renderTopCust(period){
  window._tc=period; if($('tc-m')) $('tc-m').classList.toggle('on',period==='month'); if($('tc-y')) $('tc-y').classList.toggle('on',period==='year');
  const pre=period==='year'?(''+new Date().getFullYear()):monthStr();
  const byP={}; state.entries.filter(e=>e.date.startsWith(pre)&&e.kind==='sale').forEach(e=>{ const o=byP[e.partyId]||(byP[e.partyId]={q:0,a:0}); o.q+=e.qty; o.a+=e.amount; });
  const rows=Object.keys(byP).map(id=>({p:partyById(id),q:byP[id].q,a:byP[id].a})).filter(x=>x.p).sort((a,b)=>b.a-a.a);
  const box=$('tcBox'); if(!box) return;
  box.innerHTML=rows.length?rows.map((r,i)=>`<div class="list-item" onclick="openBillDetail('${r.p.id}',rangeFor('${period}','${todayStr()}'))">${avatarHtml(r.p)}
    <div class="li-main"><div class="t">${i+1}. ${esc(r.p.name)}</div><div class="s">${num(r.q)} L • ${money(r.a)}</div></div>
    <div class="li-amt"><div class="b">${money(r.a)}</div></div></div>`).join(''):'<div class="empty"><span class="big">📊</span>'+t('no_data_toast')+'</div>';
}
/* ---- 🚚 Route summary ---- */
function modRoutes(){
  return `<div class="card"><div class="hint" style="margin-bottom:10px">${t('route_hint')}</div><div id="routeBox"></div></div>`;
}
function renderRoutes(){
  const box=$('routeBox'); if(!box) return;
  const byR={};
  state.parties.forEach(p=>{ const r=(p.route||'').trim()||t('no_route'); (byR[r]=byR[r]||[]).push(p); });
  const pre=monthStr();
  const keys=Object.keys(byR).sort((a,b)=>a.localeCompare(b));
  box.innerHTML=keys.map(r=>{
    const ps=byR[r]; const ids=ps.map(p=>p.id);
    let q=0,a=0,due=0;
    state.entries.filter(e=>e.date.startsWith(pre)&&e.kind==='sale'&&ids.indexOf(e.partyId)>=0).forEach(e=>{ q+=e.qty; a+=e.amount; });
    ps.forEach(p=>{ due+=Math.max(0,partyBalance(p.id)); });
    return `<div class="list-item"><div class="avatar">🚚</div><div class="li-main"><div class="t">${esc(r)}</div><div class="s">${ps.length} ${t('party_lbl')} • ${num(q)} L</div></div><div class="li-amt"><div class="a">${money(a)}</div>${due?`<div class="b due">${money(due)}</div>`:''}</div></div>`;
  }).join('')||'<div class="empty">'+t('no_data_toast')+'</div>';
}
/* ---- 📉 Wastage / loss ---- */
function modWastage(){
  const m=monthStr(); const list=state.wastage.filter(w=>w.date.startsWith(m));
  const tot=list.reduce((s,w)=>s+(w.value||0),0), totQ=list.reduce((s,w)=>s+(w.qty||0),0);
  return `<div class="card"><h3>${t('wastage')}</h3>
    <button class="btn" style="width:100%;margin-bottom:12px" onclick="openWastage()">➕ ${t('w_add')}</button>
    <div class="bill-line"><span class="k">${t('w_month_qty')}</span><span class="v">${num(totQ)} L</span></div>
    <div class="bill-line"><span class="k">${t('w_month_value')}</span><span class="v" style="color:var(--red)">${money(tot)}</span></div>
    <div class="divider"></div>
    <div>${list.length?list.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(wastageRow).join(''):'<div class="empty">'+t('no_data_toast')+'</div>'}</div></div>`;
}
function wastageRow(w){
  return `<div class="list-item"><div class="avatar" style="background:var(--red-l);color:var(--red)">📉</div>
    <div class="li-main"><div class="t">${fmtDate(w.date)}</div><div class="s">${num(w.qty)} L${w.reason?(' • '+esc(w.reason)):''}</div></div>
    <div class="li-amt"><div class="b due">${money(w.value||0)}</div></div>
    <button class="btn danger xs" onclick="delWastage('${w.id}')">🗑</button></div>`;
}
function openWastage(){
  openModal(`<div class="sheet-head"><h2>${t('wastage')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('date')}</label><input type="date" id="w_date" value="${todayStr()}" /></div>
    <div class="row2"><div class="field"><label>${t('litres')}</label><input type="number" step="0.1" inputmode="decimal" id="w_qty" /></div>
      <div class="field"><label>${t('rate')}</label><input type="number" step="0.01" inputmode="decimal" id="w_rate" value="${state.settings.defaultRate||0}" /></div></div>
    <div class="field"><label>${t('reason')}</label><input type="text" id="w_reason" placeholder="${t('reason_ph')}" /></div>
    <button class="btn" onclick="saveWastage()">${t('save')}</button>`);
}
function saveWastage(){
  const qty=parseFloat($('w_qty').value)||0; if(qty<=0){ toast(t('enter_qty')); return; }
  const rate=parseFloat($('w_rate').value)||0;
  state.wastage.push({id:uid(),date:$('w_date').value||todayStr(),qty:qty,rate:rate,value:Math.round(qty*rate),reason:$('w_reason').value.trim()});
  save(); closeModal(); rerenderModule(); renderHome(); toast(t('saved'));
}
function delWastage(id){ const rec=state.wastage.find(w=>w.id===id); if(!rec) return;
  state.wastage=state.wastage.filter(w=>w.id!==id); save(); rerenderModule(); renderHome();
  toast(t('deleted_undo'),t('undo'),function(){ state.wastage.push(rec); save(); rerenderModule(); renderHome(); }); }
/* ---- 🐄 Cattle register ---- */
function modAnimals(){
  const list=state.animals.filter(a=>a.active!==false);
  const daily=list.reduce((s,a)=>s+(parseFloat(a.dailyYield)||0),0);
  return `<div class="card"><h3>${t('animals')}</h3>
    <button class="btn" style="width:100%;margin-bottom:12px" onclick="openAnimal('')">➕ ${t('add')}</button>
    <div class="bill-line"><span class="k">${t('a_count')}</span><span class="v">${list.length}</span></div>
    <div class="bill-line"><span class="k">${t('a_daily')}</span><span class="v">${num(daily)} L</span></div>
    <div class="bill-line"><span class="k">${t('a_month')}</span><span class="v">${num(daily*30)} L</span></div>
    <div class="divider"></div>
    <div>${state.animals.length?state.animals.map(animalRow).join(''):'<div class="empty">'+t('no_data_toast')+'</div>'}</div></div>`;
}
function animalRow(a){
  return `<div class="list-item"><div class="avatar">${a.type==='buffalo'?'🐃':'🐄'}</div>
    <div class="li-main"><div class="t">${esc(a.tag||'—')}</div><div class="s">${esc(a.type==='buffalo'?t('buffalo'):t('cow'))} • ${num(a.dailyYield||0)} L/${t('day')}</div></div>
    <button class="btn grey xs" onclick="openAnimal('${a.id}')">✏️</button>
    <button class="btn danger xs" onclick="delAnimal('${a.id}')">🗑</button></div>`;
}
function openAnimal(id){
  const a=id?state.animals.find(x=>x.id===id):null;
  openModal(`<div class="sheet-head"><h2>${t('animals')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('a_tag')}</label><input type="text" id="an_tag" value="${a?esc(a.tag||''):''}" /></div>
    <div class="field"><label>${t('a_type')}</label><select id="an_type"><option value="cow" ${a&&a.type==='buffalo'?'':'selected'}>${t('cow')}</option><option value="buffalo" ${a&&a.type==='buffalo'?'selected':''}>${t('buffalo')}</option></select></div>
    <div class="field"><label>${t('a_yield')}</label><input type="number" step="0.1" inputmode="decimal" id="an_yield" value="${a?(a.dailyYield||0):''}" /></div>
    <button class="btn" onclick="saveAnimal('${id||''}')">${t('save')}</button>`);
}
function saveAnimal(id){
  const tag=$('an_tag').value.trim(); if(!tag){ toast(t('enter_name')); return; }
  const obj={tag:tag,type:$('an_type').value,dailyYield:parseFloat($('an_yield').value)||0,active:true};
  if(id){ const a=state.animals.find(x=>x.id===id); if(a) Object.assign(a,obj); }
  else { state.animals.push(Object.assign({id:uid()},obj)); }
  save(); closeModal(); rerenderModule(); toast(t('saved'));
}
function delAnimal(id){ state.animals=state.animals.filter(a=>a.id!==id); save(); rerenderModule(); toast(t('deleted')); }
/* ---- 🧮 Calculator ---- */
let calcBuf='';
function modCalc(){
  const keys=['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+','C','⌫','%','00'];
  return `<div class="card"><h3>${t('calc')}</h3>
    <div class="field" style="margin:0 0 10px"><input type="text" id="calcScreen" readonly value="0" style="text-align:right;font-size:26px;font-weight:800;letter-spacing:1px" /></div>
    <div class="calc-grid">${keys.map(k=>`<button class="calc-k ${'/=*+-%'.indexOf(k)>=0?'op':''} ${k==='C'?'clr':''}" onclick="calcPress('${k}')">${k}</button>`).join('')}</div>
    <div class="hint" style="margin-top:10px">${t('calc_hint')}</div></div>`;
}
function calcPress(k){
  const s=$('calcScreen'); if(!s) return;
  if(k==='C'){ calcBuf=''; s.value='0'; return; }
  if(k==='⌫'){ calcBuf=calcBuf.slice(0,-1); s.value=calcBuf||'0'; return; }
  if(k==='='){
    try{
      const expr=calcBuf.replace(/[^0-9+\-*/.%()]/g,'');
      if(!expr){ s.value='0'; return; }
      const r=Function('return ('+expr+')')();
      if(isFinite(r)){ calcBuf=String(Math.round(r*10000)/10000); s.value=calcBuf; } else { calcBuf=''; s.value='0'; }
    }catch(e){ calcBuf=''; s.value='0'; }
    return;
  }
  calcBuf+=k; s.value=calcBuf;
}
/* ---- 📝 Notes ---- */
function modNotes(){
  const list=state.notes.slice().sort((a,b)=>(a.done?1:0)-(b.done?1:0)||(b.at||0)-(a.at||0));
  return `<div class="card"><h3>${t('notes')}</h3>
    <div style="display:flex;gap:8px;margin-bottom:12px"><input type="text" id="noteInput" style="flex:1" placeholder="${t('nt_ph')}" onkeydown="if(event.key==='Enter')addNote()" /><button class="btn ghost sm" onclick="addNote()">➕</button></div>
    <div>${list.length?list.map(noteRow).join(''):'<div class="empty">'+t('no_data_toast')+'</div>'}</div></div>`;
}
function noteRow(n){
  return `<div class="list-item"><div class="avatar" style="background:${n.done?'var(--green-l)':'var(--amber-l)'};color:${n.done?'var(--green-d)':'var(--amber)'}" onclick="toggleNote('${n.id}')">${n.done?'✔️':'📝'}</div>
    <div class="li-main" onclick="toggleNote('${n.id}')"><div class="t" style="${n.done?'text-decoration:line-through;opacity:.6':''}">${esc(n.text)}</div><div class="s">${fmtDateTime(n.at||Date.now())}</div></div>
    <button class="btn grey xs" onclick="editRec('note','${n.id}')">✏️</button>
    <button class="btn danger xs" onclick="delNote('${n.id}')">🗑</button></div>`;
}
function addNote(){ const el=$('noteInput'); if(!el) return; const v=el.value.trim(); if(!v) return;
  state.notes.unshift({id:uid(),text:v,done:false,at:Date.now()}); save(); rerenderModule(); }
function toggleNote(id){ const n=state.notes.find(x=>x.id===id); if(!n) return; n.done=!n.done; save(); rerenderModule(); }
function delNote(id){ state.notes=state.notes.filter(x=>x.id!==id); save(); rerenderModule(); toast(t('deleted')); }
/* ---- 🔍 Global search ---- */
function modSearch(){
  return `<div class="card"><h3>${t('search_all')}</h3>
    <div class="field" style="margin:0"><input type="text" id="gSearch" placeholder="${t('search_ph')}" oninput="runGlobalSearch()" /></div>
    <div id="gResults" style="margin-top:12px"></div></div>`;
}
function runGlobalSearch(){
  const box=$('gResults'); if(!box) return;
  const q=($('gSearch').value||'').trim().toLowerCase();
  if(q.length<2){ box.innerHTML='<div class="hint">'+t('search_min')+'</div>'; return; }
  const out=[];
  state.parties.filter(p=>p.name.toLowerCase().includes(q)||(p.phone||'').includes(q)||(p.route||'').toLowerCase().includes(q)).slice(0,20)
    .forEach(p=>out.push(`<div class="list-item" onclick="openBillDetail('${p.id}',rangeFor('month',todayStr()))">${avatarHtml(p)}<div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||p.route||'')}</div></div></div>`));
  const res=state.entries.filter(e=>partyName(e.partyId).toLowerCase().includes(q)||e.date.includes(q)).slice(0,20);
  if(res.length){ out.push(`<div class="hint" style="margin:12px 0 4px">${t('cat_entry')}</div>`); res.forEach(e=>out.push(entryRow(e))); }
  box.innerHTML=out.length?out.join(''):'<div class="empty">'+t('no_data_toast')+'</div>';
}

/* ================= MODERN UI: onboarding, search, notifications, profile ================= */
const OB=[{ic:'🥛',t:'ob1_t',x:'ob1_x'},{ic:'⚡',t:'ob2_t',x:'ob2_x'},{ic:'📊',t:'ob3_t',x:'ob3_x'},{ic:'☁️',t:'ob4_t',x:'ob4_x'}];
let obIdx=0;
function renderOnboard(){
  const el=$('onboard'); if(!el) return;
  const s=OB[obIdx], last=obIdx===OB.length-1;
  el.innerHTML=`<div class="ob-top"><button class="ob-skip" onclick="onboardDone()">${t('ob_skip')}</button></div>
    <div class="ob-body"><div class="ob-ic">${s.ic}</div><div class="ob-t">${t(s.t)}</div><div class="ob-x">${t(s.x)}</div></div>
    <div class="ob-dots">${OB.map((_,i)=>`<span class="ob-dot ${i===obIdx?'on':''}"></span>`).join('')}</div>
    <button class="btn" onclick="${last?'onboardDone()':'onboardNext()'}">${last?t('ob_start'):t('ob_next')}</button>`;
}
function showOnboard(){ obIdx=0; renderOnboard(); $('onboard').classList.add('on'); }
function onboardNext(){ if(obIdx<OB.length-1){ obIdx++; renderOnboard(); } }
function onboardDone(){ state.settings.onboarded=true; save(); $('onboard').classList.remove('on'); }
/* ---- local profile (no Google) ---- */
function openLocalProfile(){
  const a=state.account||{};
  openModal(`<div class="sheet-head"><h2>${t('profile')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('pf_name')}</label><input type="text" id="lp_name" value="${esc(a.name||'')}" /></div>
    <div class="field"><label>${t('pf_phone')}</label><input type="tel" id="lp_phone" value="${esc(a.phone||'')}" /></div>
    <button class="btn" onclick="saveLocalProfile()">${t('save')}</button>
    <div class="hint" style="margin-top:8px">${t('pf_local_note')}</div>`);
}
function saveLocalProfile(){
  const n=$('lp_name').value.trim(), p=$('lp_phone').value.replace(/\D/g,'');
  if(!n){ toast(t('enter_name')); return; }
  state.account=Object.assign({},state.account||{},{name:n,phone:p,local:true,at:Date.now()});
  save(); closeModal(); renderHeaderAvatar(); renderProfileCard(); if(curModule==='account') rerenderModule(); toast(t('pf_saved'));
}
function renderProfileCard(){
  const el=$('profileCard'); if(!el) return;
  const a=state.account;
  if(a&&(a.email||a.local)){
    el.innerHTML=`<div class="list-item" style="padding:0 0 8px;border:none">
      ${a.picture?`<img class="g-ava" src="${esc(a.picture)}" alt="" onerror="this.style.display='none'"/>`:'<div class="avatar" style="width:52px;height:52px;font-size:24px">👤</div>'}
      <div class="li-main"><div class="t" style="font-size:17px">${esc(a.name||'—')}</div><div class="s">${esc(a.email||a.phone||'')}</div></div>
      <button class="btn grey xs" onclick="openLocalProfile()">✏️</button></div>
      <div class="hint">${esc(shopName())} · ${t('pf_signedin')}</div>`;
  } else {
    el.innerHTML=`<div class="list-item" style="padding:0 0 8px;border:none"><div class="avatar" style="width:52px;height:52px;font-size:24px">👤</div>
      <div class="li-main"><div class="t" style="font-size:17px">${t('pf_guest')}</div><div class="s">${t('pf_guest_x')}</div></div></div>
      <div class="btn-row"><button class="btn" onclick="openModule('account')">${t('g_signin')}</button>
      <button class="btn ghost" onclick="openLocalProfile()">${t('pf_local')}</button></div>`;
  }
}
/* ---- search / explore ---- */
let srchCat='';
const SRCH_CATS=[['','cat_all'],['party','cat_party'],['entry','cat_entry'],['pay','cat_pay'],['mod','cat_mod']];
function setSrchCat(k){ srchCat=k; renderSearch(); }
function matchP(p,q){ return p.name.toLowerCase().includes(q)||(p.phone||'').includes(q)||(p.route||'').toLowerCase().includes(q); }
function partyRow(p){ return `<div class="list-item" onclick="openBillDetail('${p.id}',rangeFor('month',todayStr()))">${avatarHtml(p)}<div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${esc(p.phone||p.route||'')}</div></div></div>`; }
function emptyBox(){ return `<div class="empty"><span class="big">🔍</span>${t('no_res')}</div>`; }
function renderSearch(){
  const cats=$('srchCats');
  if(cats) cats.innerHTML=SRCH_CATS.map(([k,l])=>`<span class="chip ${srchCat===k?'on':''}" onclick="setSrchCat('${k}')">${t(l)}</span>`).join('');
  const hint=$('srchHint'); if(hint) hint.textContent=t('srch_hint');
  const box=$('srchResults'); if(!box) return;
  const q=($('srchInput')?$('srchInput').value:'').trim().toLowerCase();
  if(srchCat==='mod'){
    let html='';
    GROUPS.forEach(function(g){
      const list=MODULES.filter(function(m){ return (GMAP[m.id]||'app')===g.id && (q==='' || ((LANG==='hi'?m.hi:m.en)||'').toLowerCase().includes(q)); });
      if(!list.length) return;
      html+='<div class="srch-group">'+g.ic+' '+esc(LANG==='hi'?g.hi:g.en)+' · '+list.length+'</div>'+list.map(m=>`<div class="list-item" onclick="openModule('${m.id}')"><div class="avatar">${m.ic}</div><div class="li-main"><div class="t">${esc(LANG==='hi'?m.hi:m.en)}</div></div></div>`).join('');
    });
    box.innerHTML=html||emptyBox(); return;
  }
  if(q.length<2){
    let html='';
    const rec=(state.settings.srchRecent||[]);
    if(rec.length) html+='<div class="srch-group">🕘 '+t('recent_srch')+'</div>'+rec.map(r=>`<div class="list-item" onclick="srchUse('${esc(r)}')"><div class="avatar">🔍</div><div class="li-main"><div class="t">${esc(r)}</div></div><div class="li-amt"><div class="a">↗</div></div></div>`).join('');
    const favs=(state.settings.favs||[]).map(id=>MODULES.find(m=>m.id===id)).filter(Boolean).slice(0,6);
    if(favs.length) html+='<div class="srch-group">⭐ '+t('favs')+'</div>'+favs.map(m=>`<div class="list-item" onclick="openModule('${m.id}')"><div class="avatar">${m.ic}</div><div class="li-main"><div class="t">${esc(LANG==='hi'?m.hi:m.en)}</div></div></div>`).join('');
    box.innerHTML=html||`<div class="empty"><span class="big">🔍</span>${t('srch_hint')}</div>`;
    return;
  }
  try{ const r=state.settings.srchRecent||(state.settings.srchRecent=[]); if(r[0]!==q){ r.unshift(q); if(r.length>6) r.length=6; save(); } }catch(e){}
  let html='';
  if(!srchCat||srchCat==='party'){ const l=state.parties.filter(p=>matchP(p,q)).slice(0,15);
    if(l.length) html+='<div class="srch-group">👥 '+t('cat_party')+' · '+l.length+'</div>'+l.map(partyRow).join(''); }
  if(!srchCat||srchCat==='entry'){ const l=state.entries.filter(e=>partyName(e.partyId).toLowerCase().includes(q)||e.date.includes(q)).slice(0,15);
    if(l.length) html+='<div class="srch-group">🥛 '+t('cat_entry')+' · '+l.length+'</div>'+l.map(entryRow).join(''); }
  if(!srchCat||srchCat==='pay'){ const l=state.payments.filter(x=>partyName(x.partyId).toLowerCase().includes(q)||x.date.includes(q)).slice(0,10);
    if(l.length) html+='<div class="srch-group">💵 '+t('cat_pay')+' · '+l.length+'</div>'+l.map(x=>`<div class="list-item"><div class="avatar">💵</div><div class="li-main"><div class="t">${esc(partyName(x.partyId))}</div><div class="s">${fmtDate(x.date)}</div></div><div class="li-amt"><div class="a">${money(x.amount)}</div></div></div>`).join(''); }
  box.innerHTML=html||emptyBox();
}
function srchUse(q){ const i=$('srchInput'); if(i){ i.value=q; renderSearch(); } }
/* ---- notifications ---- */
function buildNotifications(){
  const out=[];
  const dues=state.parties.filter(p=>!isSup(p)).map(p=>({p,b:partyBalance(p.id)})).filter(x=>x.b>0.5);
  if(dues.length) out.push({ic:'⏳',t:t('n_dues'),x:dues.length+' '+t('party_lbl')+' · '+money(dues.reduce((s,x)=>s+x.b,0)),go:function(){closeModal();openModule('dues');}});
  const days=state.settings.autoBackupDays||7, last=state.settings.lastExport||0;
  if(state.settings.autoBackup && (Date.now()-last)>days*86400000) out.push({ic:'☁️',t:t('n_backup'),x:t('backup_reminder'),go:function(){closeModal();openModule('drive');}});
  const low=state.items.filter(it=>stockOf(it.id)<0);
  if(low.length) out.push({ic:'📦',t:t('n_stock'),x:low.length+' '+t('item_lbl'),go:function(){closeModal();openModule('stock');}});
  const tgt=state.settings.target||0;
  if(tgt){ const m=monthStr(); const sale=state.entries.filter(e=>e.date.startsWith(m)&&e.kind==='sale').reduce((s,e)=>s+e.amount,0);
    out.push({ic:'🎯',t:t('n_target'),x:Math.round(sale/tgt*100)+'% — '+money(sale)+' / '+money(tgt),go:function(){closeModal();switchTab('home');}}); }
  if(state.settings.driveAuto && !driveReady()) out.push({ic:'🔌',t:t('n_drive'),x:t('dr_reconnect'),go:function(){closeModal();openModule('drive');}});
  return out;
}
function updateBell(){ const b=$('bellBadge'); if(!b) return; const n=buildNotifications().length; if(n){ b.textContent=n; b.style.display='grid'; } else b.style.display='none'; }
function openNotifications(){
  const list=buildNotifications(); window.__notifList=list;
  openModal(`<div class="sheet-head"><h2>🔔 ${t('notif')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    ${list.length?list.map((n,i)=>`<div class="list-item" onclick="__notifGo(${i})"><div class="avatar">${n.ic}</div><div class="li-main"><div class="t">${esc(n.t)}</div><div class="s">${esc(n.x)}</div></div></div>`).join(''):`<div class="empty"><span class="big">✅</span>${t('notif_none')}</div>`}`);
}
function __notifGo(i){ const n=(window.__notifList||[])[i]; if(n&&n.go) n.go(); }
/* ---- home highlights + quick actions ---- */
let hlIdx=0, hlTimer=null;
function buildHighlights(){
  const out=[]; const today=todayStr(), m=monthStr();
  const tE=state.entries.filter(e=>e.date===today);
  const q=tE.filter(e=>e.kind==='sale').reduce((s,e)=>s+e.qty,0);
  const a=tE.filter(e=>e.kind==='sale').reduce((s,e)=>s+e.amount,0);
  out.push({ic:'🥛',t:t('hl1_t'),x:t('hl1_x').replace('{q}',num(q)).replace('{a}',money(a))});
  const dues=state.parties.filter(p=>!isSup(p)).reduce((s,p)=>s+Math.max(0,partyBalance(p.id)),0);
  if(dues>0) out.push({ic:'⏳',t:t('hl2_t'),x:t('hl2_x').replace('{a}',money(dues))});
  const tgt=state.settings.target||0;
  if(tgt){ const ms=state.entries.filter(e=>e.date.startsWith(m)&&e.kind==='sale').reduce((s,e)=>s+e.amount,0);
    out.push({ic:'🎯',t:t('hl3_t'),x:Math.min(100,Math.round(ms/tgt*100))+'% — '+money(ms)}); }
  if(state.settings.autoShift!==false) out.push({ic:'⏱️',t:t('hl4_t'),x:t('hl4_x')});
  if(state.settings.autoBackup) out.push({ic:'☁️',t:t('hl5_t'),x:t('hl5_x')});
  return out;
}
function renderHighlights(){
  const el=$('hlCard'); if(!el) return;
  const hs=buildHighlights(); if(!hs.length){ el.style.display='none'; return; } el.style.display='block';
  if(hlIdx>=hs.length) hlIdx=0; const h=hs[hlIdx];
  el.innerHTML=`<div class="hl-ic">${h.ic}</div><div class="hl-t">${esc(h.t)}</div><div class="hl-x">${esc(h.x)}</div>
    <div class="hl-dots">${hs.map((_,i)=>`<span class="hl-dot ${i===hlIdx?'on':''}"></span>`).join('')}</div>`;
  el.onclick=function(){ hlIdx=(hlIdx+1)%hs.length; renderHighlights(); };
}
function startHighlightTimer(){ clearInterval(hlTimer); hlTimer=setInterval(function(){ const n=buildHighlights().length||1; hlIdx=(hlIdx+1)%n; renderHighlights(); },5000); }
function renderQuick(){
  const el=$('quickActions'); if(!el) return;
  const qs=[['➕',t('add_entry'),'openEntry()'],['🧺',t('bulk_entry'),'openBulk()'],['🧾',t('qa_bills'),"switchTab('bills')"],['💵',t('qa_pay'),"openModule('payments')"],['📊',t('qa_rep'),"openModule('reports')"],['☁️',t('qa_drive'),"openModule('drive')"],['📅',t('qa_cal'),"openModule('calendar')"],['🆘',t('qa_help'),"openModule('support')"]];
  el.innerHTML=qs.map(([ic,lb,fn])=>`<button class="qbtn" onclick="${fn}"><span class="qi">${ic}</span><span class="qt">${esc(lb)}</span></button>`).join('');
}
/* ---- help & support ---- */
const HELP_KB=[
 {k:['backup','बैकअप','drive','ड्राइव'],a:'help_a_backup'},
 {k:['shift','सुबह','शाम','शिफ्ट','subah','shaam'],a:'help_a_shift'},
 {k:['bill','बिल','print','प्रिंट','pdf'],a:'help_a_bill'},
 {k:['pin','पिन','lock','लॉक'],a:'help_a_pin'},
 {k:['lang','भाषा','language','english','हिंदी'],a:'help_a_lang'},
 {k:['offline','ऑफ़लाइन','internet','इंटरनेट','net'],a:'help_a_offline'}
];
function modSupport(){
  const faqs=[['faq1_q','faq1_a'],['faq2_q','faq2_a'],['faq3_q','faq3_a'],['faq4_q','faq4_a'],['faq5_q','faq5_a']];
  return `<div class="card"><h3>🆘 ${t('support')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('support_x')}</div>
    <div>${faqs.map(([q,a])=>`<details class="faq"><summary>${esc(t(q))}</summary><p>${esc(t(a))}</p></details>`).join('')}</div></div>
    <div class="card"><h3>💬 ${t('helper')}</h3>
    <div class="hint" style="margin-bottom:8px">${t('helper_x')}</div>
    <div id="helperChat"></div>
    <div style="display:flex;gap:8px;margin-top:8px"><input type="text" id="helperIn" style="flex:1" placeholder="${t('helper_ph')}" onkeydown="if(event.key==='Enter')askHelper()" /><button class="btn ghost sm" onclick="askHelper()">➤</button></div>
    <div class="chips" style="margin-top:10px">${['backup','drive','shift','bill','print','pin','lang'].map(k=>`<span class="chip" onclick="askHelper('${k}')">${t('hp_'+k)}</span>`).join('')}</div></div>
    <div class="card"><h3>📞 ${t('contact')}</h3>
    <div class="btn-row"><button class="btn wa" onclick="contactWA()">💬 WhatsApp</button><button class="btn ghost" onclick="contactMail()">✉️ Email</button></div>
    <div class="hint" style="margin-top:8px">${t('contact_x')}</div></div>`;
}
function askHelper(preset){
  const inp=$('helperIn'); const qt=(preset?t('hp_'+preset):(inp?inp.value:'')).trim(); if(!qt) return; if(inp) inp.value='';
  const box=$('helperChat'); if(!box) return;
  const low=qt.toLowerCase(); let ans=t('help_a_default');
  for(const e of HELP_KB){ if(e.k.some(k=>low.includes(k.toLowerCase()))){ ans=t(e.a); break; } }
  window._chat=(window._chat||[]); window._chat.push({u:qt,a:ans});
  box.innerHTML=window._chat.slice(-6).map(c=>`<div class="chat-u">${esc(c.u)}</div><div class="chat-b">${esc(c.a)}</div>`).join('');
}
function contactWA(){ const ph=((state.settings.business&&state.settings.business.phone)||'').replace(/\D/g,''); if(!ph){ toast(t('contact_no')); return; } window.open('https://wa.me/'+(state.settings.waCode||'91')+ph,'_blank'); }
function contactMail(){ const e=(state.account&&state.account.email)||''; window.open('mailto:'+e+'?subject=Milk%20Hisaab%20help','_blank'); }
/* ---- legal ---- */
function modLegal(){
  return `<div class="card"><h3>🔒 ${t('privacy')}</h3><div style="font-size:13.5px;line-height:1.7;color:var(--muted);white-space:pre-line">${esc(t('privacy_body'))}</div></div>
    <div class="card"><h3>📜 ${t('terms')}</h3><div style="font-size:13.5px;line-height:1.7;color:var(--muted);white-space:pre-line">${esc(t('terms_body'))}</div></div>`;
}

/* ================= SHIFT COLLECTION + BULK BILL SEND ================= */
function renderShiftCard(){
  const el=$('shiftCard'); if(!el) return;
  const t0=todayStr(); const e=state.entries.filter(x=>x.date===t0&&x.kind==='sale');
  const m=e.filter(x=>x.shift==='morning'), v=e.filter(x=>x.shift==='evening');
  const sm=m.reduce((s,x)=>s+x.qty,0), sa=m.reduce((s,x)=>s+x.amount,0);
  const vm=v.reduce((s,x)=>s+x.qty,0), va=v.reduce((s,x)=>s+x.amount,0);
  el.innerHTML=`<h3>${t('shift_coll')}</h3>
    <div class="bill-line"><span class="k">🌅 ${t('morning')}</span><span class="v">${num(sm)} L • ${money(sa)}</span></div>
    <div class="bill-line"><span class="k">🌙 ${t('evening')}</span><span class="v">${num(vm)} L • ${money(va)}</span></div>
    <div class="bill-line tot"><span class="k">${t('total')}</span><span class="v">${num(sm+vm)} L • ${money(sa+va)}</span></div>`;
}
let bbPeriod='month';
function modBulkBill(){
  return `<div class="card"><h3>📤 ${t('bulkbill')}</h3>
    <div class="seg wrap">
      <button id="bb-day" onclick="setBbPeriod('day')">${t('rep_day')}</button>
      <button id="bb-d10" onclick="setBbPeriod('d10')">${t('rep_tenday')}</button>
      <button id="bb-d15" onclick="setBbPeriod('d15')">${t('rep_d15')}</button>
      <button id="bb-month" onclick="setBbPeriod('month')">${t('rep_month')}</button>
    </div>
    <div class="field" style="margin:10px 0 0"><label>${t('anchor')}</label><input type="date" id="bbAnchor" value="${todayStr()}" onchange="renderBulkBill()" /></div>
    <div class="hint" id="bbLbl" style="margin-top:8px"></div>
    <div class="btn-row" style="margin-top:10px">
      <button class="btn grey sm" onclick="bbSelect(true)">${t('select_all')}</button>
      <button class="btn grey sm" onclick="bbSelect(false)">${t('clear_all_sel')}</button>
    </div>
    <div id="bbList" style="margin-top:8px"></div>
    <button class="btn" style="margin-top:12px" onclick="startBillQueue()">📤 ${t('bb_start')}</button>
    <div class="hint" style="margin-top:8px">${t('bb_hint')}</div></div>`;
}
function setBbPeriod(p){ bbPeriod=p; renderBulkBill(); }
function bbData(){
  const r=rangeFor(bbPeriod,($('bbAnchor')&&$('bbAnchor').value)||todayStr());
  const list=state.parties.filter(p=>p.type==='customer').map(p=>{
    const e=state.entries.filter(x=>x.partyId===p.id&&inRange(x.date,r.start,r.end));
    const q=e.reduce((s,x)=>s+x.qty,0), amt=e.reduce((s,x)=>s+x.amount,0);
    const pd=state.payments.filter(x=>x.partyId===p.id&&inRange(x.date,r.start,r.end)).reduce((s,x)=>s+x.amount,0);
    return {p,q,amt,pd,due:amt-pd};
  }).filter(b=>b.q||b.amt).sort((a,b)=>b.due-a.due);
  return {r,list};
}
function renderBulkBill(){
  if(!$('bbList')) return;
  ['day','d10','d15','month'].forEach(p=>{ const el=$('bb-'+p); if(el) el.classList.toggle('on',p===bbPeriod); });
  const d=bbData(); if($('bbLbl')) $('bbLbl').textContent=d.r.label;
  window._bb={r:d.r,list:d.list,sel:{}};
  d.list.forEach(b=>{ if(b.p.phone) window._bb.sel[b.p.id]=true; });
  bbPaint();
}
function bbPaint(){
  const bb=window._bb||{list:[],sel:{}};
  $('bbList').innerHTML=bb.list.length?bb.list.map(b=>`<div class="list-item">
      <input type="checkbox" ${bb.sel[b.p.id]?'checked':''} ${b.p.phone?'':'disabled'} onchange="window._bb.sel['${b.p.id}']=this.checked" style="width:22px;height:22px;flex:none;accent-color:var(--green)" />
      ${avatarHtml(b.p)}<div class="li-main"><div class="t">${esc(b.p.name)}</div><div class="s">${num(b.q)} L • ${esc(b.p.phone||t('no_phone'))}</div></div>
      <div class="li-amt"><div class="a">${money(b.due)}</div></div></div>`).join(''):'<div class="empty">'+t('no_data')+'</div>';
}
function bbSelect(v){ const bb=window._bb; if(!bb) return; bb.list.forEach(b=>{ if(b.p.phone) bb.sel[b.p.id]=v; }); bbPaint(); }
function startBillQueue(){
  const bb=window._bb; if(!bb) return;
  const ps=bb.list.filter(b=>bb.sel[b.p.id]&&b.p.phone).map(b=>b.p);
  if(!ps.length){ toast(t('no_sel')); return; }
  window._bq={r:bb.r,ps:ps,i:0}; renderBillQueue();
}
function renderBillQueue(){
  const q=window._bq, p=q.ps[q.i], r=q.r;
  openModal(`<div class="sheet-head"><h2>📤 ${t('bulkbill')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="text-align:center;margin-bottom:10px">${t('party_x_of_y').replace('{a}',q.i+1).replace('{b}',q.ps.length)}</div>
    <div style="display:flex;justify-content:center">${avatarHtml(p,'lg')}</div>
    <div style="text-align:center;font-weight:800;font-size:17px;margin-top:8px">${esc(p.name)}</div>
    <div style="text-align:center;color:var(--muted);font-size:13px;margin-bottom:8px">${esc(p.phone)} · ${r.label}</div>
    <div class="bill-box" style="margin-bottom:12px"><div style="white-space:pre-line;font-size:13px">${esc(billText(p.id,r))}</div></div>
    <button class="btn wa" style="margin-bottom:8px" onclick="bqSendWa()">💬 ${t('btn_send')}</button>
    <button class="btn grey" style="margin-bottom:8px" onclick="bqPdf()">📄 ${t('bb_pdf')}</button>
    <div class="btn-row"><button class="btn grey" ${q.i===0?'disabled':''} onclick="bqPrev()">${t('prev')}</button>
      <button class="btn" onclick="bqNext()">${q.i>=q.ps.length-1?t('done_all'):t('next')}</button></div>`);
}
function bqCur(){ return window._bq.ps[window._bq.i]; }
function bqSendWa(){ const p=bqCur(); window.open('https://wa.me/'+dial(p)+'?text='+encodeURIComponent(billText(p.id,window._bq.r)),'_blank'); }
function bqPdf(){ const p=bqCur(), r=window._bq.r; printBillR(p.id,r); }
function bqNext(){ const q=window._bq; if(q.i>=q.ps.length-1){ closeModal(); toast(t('bb_done')); return; } q.i++; renderBillQueue(); }
function bqPrev(){ const q=window._bq; if(q.i>0){ q.i--; renderBillQueue(); } }
function printBillR(id,r){
  const w=window.open('','_blank'); if(!w) return;
  w.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+t('bill_title')+'</title>'+billPageCss()+'</head><body>'+billPageHtml(id,r)+'<script>setTimeout(function(){window.print();},350);<\/script></body></html>');
  w.document.close();
}

/* ================= AUTO BACKUP (Android-friendly) ================= */
let driveSilentTried=false;
function driveAutoSync(){
  if(!state.settings.driveAuto) return;
  if(driveReady()){ scheduleAutoDriveBackup(); return; }
  if(driveSilentTried) return;
  driveSilentTried=true;
  try{ initDriveAuth(); if(tokenClient&&state.settings.driveConnected) tokenClient.requestAccessToken({prompt:''}); }catch(e){}
}
function registerPeriodicSync(){
  try{
    if(!('serviceWorker' in navigator) || !navigator.serviceWorker.ready) return;
    navigator.serviceWorker.ready.then(function(r){
      try{ if(r.periodicSync&&r.periodicSync.register){ r.periodicSync.register('milk-drive-sync',{minInterval:6*60*60*1000}).catch(function(){}); } }catch(e){}
    }).catch(function(){});
  }catch(e){}
}
/* ================= EXTRA MODULES ================= */
/* ---- 📊 Month comparison ---- */
function monthStats(pre){
  const e=state.entries.filter(x=>x.date.startsWith(pre));
  const sale=e.filter(x=>x.kind==='sale').reduce((s,x)=>s+x.amount,0);
  const purch=e.filter(x=>x.kind==='purchase').reduce((s,x)=>s+x.amount,0);
  const exp=state.expenses.filter(x=>x.date.startsWith(pre)).reduce((s,x)=>s+x.amount,0);
  const wast=state.wastage.filter(x=>x.date.startsWith(pre)).reduce((s,x)=>s+(x.value||0),0);
  return {sale,purch,exp,wast,net:sale-purch-exp-wast};
}
function modCompare(){ return `<div class="card"><h3>📊 ${t('compare')}</h3><div id="cmpBox"></div></div>`; }
function renderCompare(){
  const box=$('cmpBox'); if(!box) return;
  const now=new Date(); const p2=n=>String(n).padStart(2,'0');
  const cur=now.getFullYear()+'-'+p2(now.getMonth()+1);
  const pd=new Date(now.getFullYear(),now.getMonth()-1,1); const prev=pd.getFullYear()+'-'+p2(pd.getMonth()+1);
  const a=monthStats(cur), b=monthStats(prev);
  const row=(lbl,x,y,goodUp)=>{ const d=x-y; const ar=d>0?'▲':d<0?'▼':'—'; const col=(Math.abs(d)<0.5)?'var(--muted)':((d>0)===!!goodUp?'var(--green)':'var(--red)');
    return `<div class="bill-line"><span class="k">${lbl}</span><span class="v">${money(x)} <span style="font-size:11px;color:${col}">${ar}</span></span></div>`; };
  box.innerHTML=`<div class="hint" style="margin-bottom:8px">${fmtMonth(prev)} → ${fmtMonth(cur)}</div>
    ${row(t('c_sale'),a.sale,b.sale,true)}
    ${row(t('c_purch'),a.purch,b.purch,false)}
    ${row(t('c_exp'),a.exp,b.exp,false)}
    ${row(t('wastage'),a.wast,b.wast,false)}
    <div class="bill-line tot"><span class="k">${t('net_profit')}</span><span class="v">${money(a.net)}</span></div>
    <div class="hint" style="margin-top:8px">${t('c_prev')}: ${t('net_profit')} ${money(b.net)}</div>`;
}
/* ---- 🚚 Delivery sheet ---- */
function modDelivery(){
  return `<div class="card"><h3>🚚 ${t('delivery')}</h3>
    <div class="row2"><div class="field"><label>${t('date')}</label><input type="date" id="dlDate" value="${todayStr()}" /></div>
    <div class="field"><label>${t('shift')}</label><select id="dlShift"><option value="morning">${t('morning')}</option><option value="evening">${t('evening')}</option><option value="both">${t('both')}</option></select></div></div>
    <div class="btn-row"><button class="btn" onclick="renderDelivery()">${t('show')}</button><button class="btn grey" onclick="printDelivery()">🖨️ ${t('print')}</button></div>
    <div id="dlBox" style="margin-top:12px"></div></div>`;
}
function deliveryRows(){
  const date=($('dlDate')&&$('dlDate').value)||todayStr();
  const sh=($('dlShift')&&$('dlShift').value)||'both';
  const shifts=sh==='both'?['morning','evening']:[sh];
  const rows=[];
  state.parties.filter(p=>p.type==='customer'&&p.active!==false).forEach(p=>{
    if(isHoliday(date,p.id)) return;
    shifts.forEach(s=>{ const ex=state.entries.find(e=>e.partyId===p.id&&e.date===date&&e.shift===s);
      const q=ex?ex.qty:(p.defaultQty||0); if(q>0) rows.push({p,shift:s,qty:q,done:!!ex,route:(p.route||'').trim()||t('no_route')}); });
  });
  rows.sort((a,b)=>a.route.localeCompare(b.route)||a.p.name.localeCompare(b.p.name));
  return {date,rows};
}
function renderDelivery(){
  const box=$('dlBox'); if(!box) return; const d=deliveryRows();
  if(!d.rows.length){ box.innerHTML='<div class="empty">'+t('no_data')+'</div>'; return; }
  const tot=d.rows.reduce((s,r)=>s+r.qty,0);
  box.innerHTML=d.rows.map(r=>`<div class="list-item"><div class="avatar">${r.done?'✅':'⬜'}</div>
    <div class="li-main"><div class="t">${esc(r.p.name)}</div><div class="s">${esc(r.route)} • ${r.shift==='evening'?t('evening'):t('morning')}</div></div>
    <div class="li-amt"><div class="a">${num(r.qty)} L</div></div></div>`).join('')
    +`<div class="bill-line tot" style="margin-top:10px"><span class="k">${t('total')}</span><span class="v">${num(tot)} L</span></div>`;
}
function printDelivery(){
  const d=deliveryRows(); const w=window.open('','_blank'); if(!w) return;
  w.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+t('delivery')+'</title>'+billPageCss()+'</head><body>'
    +'<div class="hd"><div><h1>'+esc(shopName())+'</h1><h2>'+t('delivery')+' — '+fmtDate(d.date)+'</h2></div></div>'
    +'<table><thead><tr><th>'+t('party_lbl')+'</th><th>'+t('route_lbl')+'</th><th>'+t('shift')+'</th><th>L</th><th>✔</th></tr></thead><tbody>'
    +d.rows.map(r=>'<tr><td>'+esc(r.p.name)+'</td><td>'+esc(r.route)+'</td><td>'+(r.shift==='evening'?t('evening'):t('morning'))+'</td><td>'+num(r.qty)+'</td><td></td></tr>').join('')
    +'</tbody></table><div class="ft">'+t('total')+': '+num(d.rows.reduce((s,r)=>s+r.qty,0))+' L</div></body></html>');
  w.document.close();
}
/* ---- 🥛 Quality (FAT) ---- */
function modQuality(){
  return `<div class="card"><h3>🥛 ${t('quality')}</h3>
    <div class="seg"><button id="q-m" class="on" onclick="renderQuality('month')">${t('rep_month')}</button><button id="q-y" onclick="renderQuality('year')">${t('rep_yearwise')}</button></div>
    <div id="qBox" style="margin-top:12px"></div></div>`;
}
function renderQuality(period){
  window._q=period; if($('q-m')) $('q-m').classList.toggle('on',period==='month'); if($('q-y')) $('q-y').classList.toggle('on',period==='year');
  const pre=period==='year'?(''+new Date().getFullYear()):monthStr();
  const es=state.entries.filter(e=>e.date.startsWith(pre)&&e.kind==='sale'&&e.fat>0);
  const box=$('qBox'); if(!box) return;
  if(!es.length){ box.innerHTML='<div class="empty">'+t('no_fat')+'</div>'; return; }
  const totQ=es.reduce((s,e)=>s+e.qty,0), wfat=es.reduce((s,e)=>s+e.qty*e.fat,0);
  const b={'<4':0,'4-5':0,'5-6':0,'6-7':0,'7+':0};
  es.forEach(e=>{ const f=e.fat; if(f<4)b['<4']+=e.qty; else if(f<5)b['4-5']+=e.qty; else if(f<6)b['5-6']+=e.qty; else if(f<7)b['6-7']+=e.qty; else b['7+']+=e.qty; });
  box.innerHTML=`<div class="bill-line"><span class="k">${t('q_avg')}</span><span class="v">${num(Math.round((totQ?wfat/totQ:0)*100)/100)}</span></div>
    <div class="bill-line"><span class="k">${t('q_samples')}</span><span class="v">${es.length}</span></div>
    <div class="divider"></div>
    ${Object.keys(b).map(k=>`<div class="bill-line"><span class="k">${t('fat_short')} ${k}</span><span class="v">${num(b[k])} L</span></div>`).join('')}`;
}
/* ---- 😴 Inactive customers ---- */
function modInactive(){
  return `<div class="card"><h3>😴 ${t('inactive')}</h3>
    <div class="field" style="margin:0 0 10px"><label>${t('in_days')}</label><input type="number" id="inDays" value="7" min="1" oninput="renderInactive()" /></div>
    <div id="inBox"></div></div>`;
}
function renderInactive(){
  const box=$('inBox'); if(!box) return;
  const days=parseInt(($('inDays')&&$('inDays').value)||'7',10)||7;
  const cut=new Date(); cut.setDate(cut.getDate()-days); const cutStr=ymd(cut);
  const last={}; state.entries.forEach(e=>{ if(!last[e.partyId]||e.date>last[e.partyId]) last[e.partyId]=e.date; });
  const list=state.parties.filter(p=>p.type==='customer'&&p.active!==false).map(p=>({p,last:last[p.id]||''}))
    .filter(x=>!x.last||x.last<cutStr).sort((a,b)=>(a.last||'').localeCompare(b.last||''));
  box.innerHTML=list.length?list.map(({p,last})=>`<div class="list-item">${avatarHtml(p)}
      <div class="li-main"><div class="t">${esc(p.name)}</div><div class="s">${last?(t('last_seen')+' '+fmtDate(last)):t('never_seen')}</div></div>
      ${p.phone?`<button class="btn wa xs" onclick="waRemind('${p.id}')">🔔</button>`:''}</div>`).join('')
    :'<div class="empty"><span class="big">✅</span>'+t('all_active')+'</div>';
}
/* ---- 💳 Loans / credit ---- */
function modLoans(){
  const lent=(state.loans||[]).filter(l=>l.kind==='lent'&&!l.settled).reduce((s,l)=>s+l.amount,0);
  const bor=(state.loans||[]).filter(l=>l.kind==='borrowed'&&!l.settled).reduce((s,l)=>s+l.amount,0);
  return `<div class="card"><h3>💳 ${t('loans')}</h3>
    <button class="btn" style="width:100%;margin-bottom:12px" onclick="openLoan()">➕ ${t('l_add')}</button>
    <div class="bill-line"><span class="k">${t('l_lent')}</span><span class="v" style="color:var(--green-d)">${money(lent)}</span></div>
    <div class="bill-line"><span class="k">${t('l_borrowed')}</span><span class="v" style="color:var(--red)">${money(bor)}</span></div>
    <div class="divider"></div>
    <div>${(state.loans||[]).length?state.loans.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(loanRow).join(''):'<div class="empty">'+t('no_data')+'</div>'}</div></div>`;
}
function loanRow(l){
  return `<div class="list-item"><div class="avatar" style="background:${l.kind==='lent'?'var(--green-l)':'var(--red-l)'};color:${l.kind==='lent'?'var(--green-d)':'var(--red)'}">${l.kind==='lent'?'📤':'📥'}</div>
    <div class="li-main"><div class="t" style="${l.settled?'text-decoration:line-through;opacity:.6':''}">${esc(l.name)}</div><div class="s">${fmtDate(l.date)}${l.note?' • '+esc(l.note):''}</div></div>
    <div class="li-amt"><div class="a">${money(l.amount)}</div></div>
    <button class="btn grey xs" onclick="toggleLoan('${l.id}')">${l.settled?'↺':'✔'}</button>
    <button class="btn grey xs" onclick="editRec('loan','${l.id}')">✏️</button>
    <button class="btn danger xs" onclick="delLoan('${l.id}')">🗑</button></div>`;
}
function openLoan(){
  openModal(`<div class="sheet-head"><h2>${t('loans')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('l_name')}</label><input type="text" id="ln_name" /></div>
    <div class="field"><label>${t('l_kind')}</label><select id="ln_kind"><option value="lent">${t('l_lent')}</option><option value="borrowed">${t('l_borrowed')}</option></select></div>
    <div class="row2"><div class="field"><label>${t('amount')}</label><input type="number" inputmode="numeric" id="ln_amt" /></div>
    <div class="field"><label>${t('date')}</label><input type="date" id="ln_date" value="${todayStr()}" /></div></div>
    <div class="field"><label>${t('note')}</label><input type="text" id="ln_note" /></div>
    <button class="btn" onclick="saveLoan()">${t('save')}</button>`);
}
function saveLoan(){
  const n=$('ln_name').value.trim(), a=parseFloat($('ln_amt').value)||0;
  if(!n){ toast(t('enter_name')); return; } if(a<=0){ toast(t('enter_amount')); return; }
  state.loans=state.loans||[];
  state.loans.push({id:uid(),date:$('ln_date').value||todayStr(),name:n,amount:a,kind:$('ln_kind').value,note:$('ln_note').value.trim(),settled:false});
  save(); closeModal(); rerenderModule(); toast(t('saved'));
}
function toggleLoan(id){ const l=(state.loans||[]).find(x=>x.id===id); if(!l) return; l.settled=!l.settled; save(); rerenderModule(); }
function delLoan(id){ state.loans=(state.loans||[]).filter(x=>x.id!==id); save(); rerenderModule(); toast(t('deleted')); }
/* ---- 🔁 Recurring expenses ---- */
function modRecurring(){
  const list=state.recurring||[];
  return `<div class="card"><h3>🔁 ${t('recurring')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('rec_hint')}</div>
    <button class="btn" style="width:100%;margin-bottom:10px" onclick="openRecurring('')">➕ ${t('add')}</button>
    <div>${list.length?list.map(recurringRow).join(''):'<div class="empty">'+t('no_data')+'</div>'}</div>
    ${list.length?`<button class="btn grey" style="margin-top:12px" onclick="runRecurring()">${t('rec_run')}</button>`:''}</div>`;
}
function recurringRow(r){
  return `<div class="list-item"><div class="avatar">🔁</div>
    <div class="li-main"><div class="t">${esc(r.name)}</div><div class="s">${catLabel(r.cat)} • ${t('day')} ${r.day}</div></div>
    <div class="li-amt"><div class="a">${money(r.amount)}</div></div>
    <button class="btn grey xs" onclick="openRecurring('${r.id}')">✏️</button>
    <button class="btn danger xs" onclick="delRecurring('${r.id}')">🗑</button></div>`;
}
function openRecurring(id){
  const r=id?(state.recurring||[]).find(x=>x.id===id):null;
  openModal(`<div class="sheet-head"><h2>${t('recurring')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('enter_name')}</label><input type="text" id="rc_name" value="${r?esc(r.name):''}" /></div>
    <div class="row2"><div class="field"><label>${t('amount')}</label><input type="number" id="rc_amt" value="${r?r.amount:''}" /></div>
    <div class="field"><label>${t('day')}</label><input type="number" min="1" max="28" id="rc_day" value="${r?r.day:1}" /></div></div>
    <div class="field"><label>${t('category')}</label><select id="rc_cat">${CATS.map(c=>`<option value="${c}" ${r&&r.cat===c?'selected':''}>${catLabel(c)}</option>`).join('')}</select></div>
    <button class="btn" onclick="saveRecurring('${id||''}')">${t('save')}</button>`);
}
function saveRecurring(id){
  const n=$('rc_name').value.trim(); if(!n){ toast(t('enter_name')); return; }
  const obj={name:n,amount:parseFloat($('rc_amt').value)||0,day:Math.min(28,Math.max(1,parseInt($('rc_day').value,10)||1)),cat:$('rc_cat').value,active:true};
  state.recurring=state.recurring||[];
  if(id){ const r=state.recurring.find(x=>x.id===id); if(r) Object.assign(r,obj); } else state.recurring.push(Object.assign({id:uid()},obj));
  save(); closeModal(); rerenderModule(); toast(t('saved'));
}
function delRecurring(id){ state.recurring=(state.recurring||[]).filter(x=>x.id!==id); save(); rerenderModule(); toast(t('deleted')); }
function runRecurring(){
  const m=monthStr(); const list=(state.recurring||[]).filter(r=>r.active!==false); if(!list.length){ toast(t('no_data')); return; }
  let n=0;
  list.forEach(r=>{ const date=m+'-'+String(r.day).padStart(2,'0');
    if(state.expenses.some(x=>x.date===date&&x.cat===r.cat&&x.amount===r.amount&&(x.note||'')===r.name)) return;
    state.expenses.push({id:uid(),date:date,amount:r.amount,cat:r.cat,note:r.name}); n++; });
  save(); refreshAll(); rerenderModule(); toast(n?(n+' '+t('saved')):t('rec_already'));
}

/* ================= FINGERPRINT / BIOMETRIC LOCK ================= */
function bioNative(){ try{ return (typeof window.MilkBio !== 'undefined' && window.MilkBio); }catch(e){ return false; } }
function bioSupported(){
  if(bioNative()) return true;
  try{ return !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create && window.isSecureContext); }catch(e){ return false; }
}
function b64(buf){ let s=''; const b=new Uint8Array(buf); for(let i=0;i<b.length;i++) s+=String.fromCharCode(b[i]); return btoa(s); }
function b64d(s){ const bin=atob(s); const a=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) a[i]=bin.charCodeAt(i); return a; }
function toggleBio(){
  if(state.settings.biometricLock){ state.settings.biometricLock=false; state.settings.bioCredId=''; save(); renderSettingsBits(); toast(t('bio_off')); try{ if(bioNative()&&window.MilkBio.disable) window.MilkBio.disable(); }catch(e){} return; }
  enableBiometric();
}
function enableBiometric(){
  if(!bioSupported()){ toast(t('bio_na')); return; }
  if(bioNative()){ try{ window.MilkBio.enable(); state.settings.biometricLock=true; save(); renderSettingsBits(); toast(t('bio_on')); }catch(e){ toast(t('bio_na')); } return; }
  try{
    const challenge=new Uint8Array(32); crypto.getRandomValues(challenge);
    const uid=new Uint8Array(16); crypto.getRandomValues(uid);
    navigator.credentials.create({ publicKey:{
      challenge:challenge,
      rp:{ name:'Milk Hisaab', id:location.hostname },
      user:{ id:uid, name:'owner', displayName:'Owner' },
      pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
      authenticatorSelection:{ authenticatorAttachment:'platform', userVerification:'required' },
      timeout:60000, attestation:'none'
    }}).then(function(cred){
      if(cred && cred.rawId){ state.settings.bioCredId=b64(cred.rawId); state.settings.biometricLock=true; save(); renderSettingsBits(); toast(t('bio_on')); }
      else { toast(t('bio_na')); }
    }).catch(function(){ toast(t('bio_na')); });
  }catch(e){ toast(t('bio_na')); }
}
function showBioLock(){
  const el=$('bioLock'); if(!el) return;
  if($('bioTitle')) $('bioTitle').textContent=t('bio_title');
  if($('bioSub')) $('bioSub').textContent=t('bio_sub');
  if($('bioBtn')) $('bioBtn').textContent='🔒 '+t('bio_open');
  if($('bioPinBtn')) $('bioPinBtn').textContent=t('bio_use_pin');
  el.classList.add('on');
  setTimeout(function(){ try{ bioUnlock(); }catch(e){} }, 350);
}
function hideBioLock(){ const el=$('bioLock'); if(el) el.classList.remove('on'); }
function bioUsePin(){ hideBioLock(); if(state.settings.pin) showLock(); }
function bioUnlock(){
  if(bioNative()){ try{ window.MilkBio.authenticate(); return; }catch(e){} }
  if(!state.settings.bioCredId){ toast(t('bio_na')); return; }
  try{
    const challenge=new Uint8Array(32); crypto.getRandomValues(challenge);
    navigator.credentials.get({ publicKey:{
      challenge:challenge,
      allowCredentials:[{ id:b64d(state.settings.bioCredId), type:'public-key' }],
      userVerification:'required', timeout:60000
    }}).then(function(r){ if(r) hideBioLock(); else toast(t('bio_fail')); })
     .catch(function(){ toast(t('bio_fail')); });
  }catch(e){ toast(t('bio_fail')); }
}
function __bioOk(){ hideBioLock(); }
function __bioFail(){ toast(t('bio_fail')); }

/* ================= POWER MODULES ================= */
/* ---- 🧾 Invoices / bill numbers ---- */
function nextInvNo(){ return state.settings.invNext||1; }
function modInvoices(){
  const list=(state.invoices||[]).slice().sort((a,b)=>b.no-a.no);
  return `<div class="card"><h3>🧾 ${t('invoices')}</h3>
    <div class="bill-line"><span class="k">${t('inv_next')}</span><span class="v">#${nextInvNo()}</span></div>
    <div class="btn-row" style="margin-top:10px"><button class="btn" onclick="openInvoice()">➕ ${t('inv_new')}</button></div>
    <div class="divider"></div>
    <div>${list.length?list.map(invRow).join(''):'<div class="empty">'+t('no_data')+'</div>'}</div></div>`;
}
function invRow(v){
  const p=partyById(v.partyId);
  return `<div class="list-item"><div class="avatar">🧾</div>
    <div class="li-main"><div class="t">#${v.no} · ${esc(p?p.name:'—')}</div><div class="s">${fmtDate(v.date)} · ${esc(v.label||'')}</div></div>
    <div class="li-amt"><div class="a">${money(v.amount)}</div></div>
    <button class="btn grey xs" onclick="shareInvoice('${v.id}')">📤</button>
    <button class="btn danger xs" onclick="delInvoice('${v.id}')">🗑</button></div>`;
}
function openInvoice(){
  if(!state.parties.length){ toast(t('add_party_first')); return; }
  const opts=state.parties.filter(p=>p.type==='customer').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  openModal(`<div class="sheet-head"><h2>${t('inv_new')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('party_lbl')}</label><select id="iv_party" onchange="calcInvoiceAmt()">${opts}</select></div>
    <div class="row2"><div class="field"><label>${t('rep_month')}</label><input type="month" id="iv_month" value="${monthStr()}" onchange="calcInvoiceAmt()" /></div>
    <div class="field"><label>${t('amount')}</label><input type="number" id="iv_amt" placeholder="auto" /></div></div>
    <div class="field"><label>${t('note')}</label><input type="text" id="iv_note" /></div>
    <div class="hint" style="margin-bottom:8px">${t('inv_hint')}</div>
    <button class="btn" onclick="saveInvoice()">${t('save')}</button>`);
  calcInvoiceAmt();
}
function invAutoAmt(){
  const pid=$('iv_party')?$('iv_party').value:''; const m=($('iv_month')&&$('iv_month').value)||monthStr();
  return state.entries.filter(e=>e.partyId===pid&&e.kind==='sale'&&e.date.startsWith(m)).reduce((s,e)=>s+e.amount,0);
}
function calcInvoiceAmt(){ const el=$('iv_amt'); if(el && !el.value) el.placeholder=String(Math.round(invAutoAmt())); }
function saveInvoice(){
  const pid=$('iv_party').value, m=($('iv_month').value)||monthStr();
  const amt=parseFloat($('iv_amt').value)||Math.round(invAutoAmt());
  if(amt<=0){ toast(t('enter_amount')); return; }
  const no=nextInvNo();
  state.invoices=state.invoices||[];
  state.invoices.push({id:uid(),no:no,date:todayStr(),partyId:pid,amount:amt,label:fmtMonth(m),note:$('iv_note').value.trim()});
  state.settings.invNext=no+1;
  save(); closeModal(); rerenderModule(); toast(t('inv_saved')+' #'+no);
}
function delInvoice(id){ state.invoices=(state.invoices||[]).filter(v=>v.id!==id); save(); rerenderModule(); toast(t('deleted')); }
function shareInvoice(id){
  const v=(state.invoices||[]).find(x=>x.id===id); if(!v) return;
  const p=partyById(v.partyId);
  const txt='🧾 '+shopName()+'\n'+t('bill_title')+' #'+v.no+'\n'+((p&&p.name)||'')+'\n'+v.label+'\n────────────\n'+t('total_bill')+': '+money(v.amount)+'\n────────────\n'+t('thank');
  if(navigator.share){ navigator.share({title:t('bill_title'),text:txt}).catch(function(){}); }
  else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(function(){}); toast(t('copied')); }
}
/* ---- 👷 Staff & wages ---- */
function modStaff(){
  const list=(state.staff||[]).filter(s=>s.active!==false);
  return `<div class="card"><h3>👷 ${t('staff')}</h3>
    <button class="btn" style="width:100%;margin-bottom:10px" onclick="openStaff('')">➕ ${t('add')}</button>
    <div>${(state.staff||[]).length?state.staff.map(staffRow).join(''):'<div class="empty">'+t('no_data')+'</div>'}</div>
    ${list.length?`<div class="divider"></div><div class="hint" style="margin-bottom:8px">${t('att_hint')}</div>
      <div class="btn-row"><button class="btn grey" onclick="openAttendance()">🗓️ ${t('attendance')}</button>
      <button class="btn grey" onclick="payWages()">💰 ${t('pay_wages')}</button></div>`:''}</div>`;
}
function staffRow(s){
  const m=monthStr(); const days=(state.att||[]).filter(a=>a.staffId===s.id&&a.date.startsWith(m)&&a.p).length;
  return `<div class="list-item"><div class="avatar">👷</div>
    <div class="li-main"><div class="t">${esc(s.name)}</div><div class="s">${esc(s.phone||'')} • ${t('attendance')}: ${days} • ${money(s.wage)}</div></div>
    <button class="btn grey xs" onclick="openStaff('${s.id}')">✏️</button>
    <button class="btn danger xs" onclick="delStaff('${s.id}')">🗑</button></div>`;
}
function openStaff(id){
  const s=id?(state.staff||[]).find(x=>x.id===id):null;
  openModal(`<div class="sheet-head"><h2>${t('staff')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="field"><label>${t('enter_name')}</label><input type="text" id="st_name" value="${s?esc(s.name):''}" /></div>
    <div class="row2"><div class="field"><label>${t('biz_phone')}</label><input type="tel" id="st_phone" value="${s?esc(s.phone||''):''}" /></div>
    <div class="field"><label>${t('wage')}</label><input type="number" id="st_wage" value="${s?s.wage:''}" /></div></div>
    <button class="btn" onclick="saveStaff('${id||''}')">${t('save')}</button>`);
}
function saveStaff(id){
  const n=$('st_name').value.trim(); if(!n){ toast(t('enter_name')); return; }
  const obj={name:n,phone:$('st_phone').value.trim(),wage:parseFloat($('st_wage').value)||0,active:true};
  state.staff=state.staff||[];
  if(id){ const s=state.staff.find(x=>x.id===id); if(s) Object.assign(s,obj); } else state.staff.push(Object.assign({id:uid()},obj));
  save(); closeModal(); rerenderModule(); toast(t('saved'));
}
function delStaff(id){ state.staff=(state.staff||[]).filter(s=>s.id!==id); state.att=(state.att||[]).filter(a=>a.staffId!==id); save(); rerenderModule(); toast(t('deleted')); }
function openAttendance(){
  const m=monthStr(); const A={};
  (state.att||[]).forEach(a=>{ if(a.date.startsWith(m)) A[a.staffId+'|'+a.date]=a.p?1:0; });
  window._att=A; window._attMonth=m; renderAtt();
}
function renderAtt(){
  const m=window._attMonth||monthStr(), A=window._att||{};
  const yy=+m.slice(0,4), mm=+m.slice(5,7), days=lastDay(yy,mm);
  const list=(state.staff||[]).filter(s=>s.active!==false);
  openModal(`<div class="sheet-head"><h2>${t('attendance')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    <div class="hint" style="margin-bottom:8px">${fmtMonth(m)} — ${t('att_tap')}</div>
    <div style="overflow:auto;max-height:50vh"><table style="font-size:12px"><thead><tr><th></th>${Array.from({length:days},(_,i)=>`<th>${i+1}</th>`).join('')}</tr></thead><tbody>
    ${list.map(s=>`<tr><td style="white-space:nowrap;font-weight:700">${esc(s.name)}</td>${Array.from({length:days},(_,i)=>{ const d=m+'-'+String(i+1).padStart(2,'0'); const v=A[s.id+'|'+d]; return `<td onclick="toggleAtt('${s.id}','${d}')" style="text-align:center;cursor:pointer;background:${v===1?'var(--green-l)':v===0?'var(--red-l)':''}">${v===1?'✔':v===0?'✕':''}</td>`; }).join('')}</tr>`).join('')}
    </tbody></table></div>
    <button class="btn" style="margin-top:12px" onclick="saveAtt()">${t('save')}</button>`);
}
function toggleAtt(sid,d){ const A=window._att||(window._att={}); const k=sid+'|'+d; A[k]=(A[k]===1)?0:1; renderAtt(); }
function saveAtt(){
  const m=window._attMonth||monthStr(), A=window._att||{};
  state.att=(state.att||[]).filter(a=>!a.date.startsWith(m));
  Object.keys(A).forEach(k=>{ const parts=k.split('|'); state.att.push({staffId:parts[0],date:parts[1],p:A[k]?1:0}); });
  save(); closeModal(); rerenderModule(); toast(t('saved'));
}
function payWages(){
  const m=monthStr(); const yy=+m.slice(0,4), mm=+m.slice(5,7); const lastD=lastDay(yy,mm);
  let n=0;
  (state.staff||[]).filter(s=>s.active!==false).forEach(s=>{
    const days=(state.att||[]).filter(a=>a.staffId===s.id&&a.date.startsWith(m)&&a.p).length;
    if(!days) return;
    const per=Math.round((s.wage||0)/26*days);
    const note=s.name+' ('+days+')';
    if(state.expenses.some(x=>x.date.startsWith(m)&&x.cat==='labour'&&x.note===note)) return;
    state.expenses.push({id:uid(),date:m+'-'+String(lastD).padStart(2,'0'),amount:per,cat:'labour',note:note}); n++;
  });
  save(); refreshAll(); rerenderModule(); toast(n?(n+' '+t('saved')):t('rec_already'));
}
/* ---- 📈 Yearly trend ---- */
function modTrend(){ return `<div class="card"><h3>📈 ${t('trend')}</h3><div id="trBox"></div></div>`; }
function renderTrend(){
  const box=$('trBox'); if(!box) return;
  const now=new Date(); const months=[];
  for(let i=11;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); months.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')); }
  const sales=months.map(m=>state.entries.filter(e=>e.date.startsWith(m)&&e.kind==='sale').reduce((s,e)=>s+e.amount,0));
  const nets=months.map(m=>monthStats(m).net);
  const max=Math.max(1,...sales,...nets);
  const W=900,H=460,pad=40,base=H-70,bw=(W-pad*2)/12*0.62,gap=(W-pad*2)/12;
  const c=document.createElement('canvas'); c.width=W; c.height=H; const g=c.getContext('2d');
  g.fillStyle='#fff'; g.fillRect(0,0,W,H);
  g.strokeStyle='#e6ece8'; g.lineWidth=1;
  for(let i=1;i<=4;i++){ const y=base-(300/4)*i; g.beginPath(); g.moveTo(pad,y); g.lineTo(W-pad,y); g.stroke(); }
  months.forEach(function(m,i){
    const x=pad+i*gap+(gap-bw)/2;
    const h=Math.max(4,Math.round(sales[i]/max*300));
    g.fillStyle='#0f7b53'; g.fillRect(x,base-h,bw*0.55,h);
    const h2=Math.max(0,Math.round(Math.max(0,nets[i])/max*300));
    g.fillStyle='#b7791f'; g.fillRect(x+bw*0.55,base-h2,bw*0.45,h2);
    g.fillStyle='#666'; g.font='13px Arial'; g.textAlign='center';
    g.fillText(MONTHS[LANG][(+m.slice(5,7))-1].slice(0,3),x+bw/2,base+18);
  });
  g.strokeStyle='#bbb'; g.beginPath(); g.moveTo(pad,base); g.lineTo(W-pad,base); g.stroke();
  box.innerHTML='<img alt="" src="'+c.toDataURL('image/png')+'" style="width:100%;border-radius:12px" />'
    +`<div class="hint" style="margin-top:8px">🟩 ${t('c_sale')} · 🟨 ${t('net_profit')} — ${t('last12')}</div>`;
}
/* ---- 🌙 Day-end summary ---- */
function modDayEnd(){
  return `<div class="card"><h3>🌙 ${t('dayend')}</h3>
    <div class="field" style="margin:0 0 10px"><label>${t('date')}</label><input type="date" id="deDate" value="${todayStr()}" onchange="renderDayEnd()" /></div>
    <div id="deBox"></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn" onclick="shareDayEnd()">📤 ${t('send')}</button></div></div>`;
}
function dayEndData(date){
  const e=state.entries.filter(x=>x.date===date);
  const sale=e.filter(x=>x.kind==='sale'), pur=e.filter(x=>x.kind==='purchase');
  const m=sale.filter(x=>x.shift==='morning'), v=sale.filter(x=>x.shift==='evening');
  const qty=sale.reduce((s,x)=>s+x.qty,0), amt=sale.reduce((s,x)=>s+x.amount,0);
  const purch=pur.reduce((s,x)=>s+x.amount,0);
  const pays=state.payments.filter(x=>x.date===date).reduce((s,x)=>s+x.amount,0);
  const exp=state.expenses.filter(x=>x.date===date).reduce((s,x)=>s+x.amount,0);
  const wast=state.wastage.filter(x=>x.date===date).reduce((s,x)=>s+(x.value||0),0);
  const cust={}; sale.forEach(x=>cust[x.partyId]=1);
  const defCust=state.parties.filter(p=>p.type==='customer'&&p.active!==false&&(p.defaultQty>0)).length;
  return {date,e,sale,pur,m,v,qty,amt,purch,pays,exp,wast,cust:Object.keys(cust).length,defCust,net:amt-purch-exp-wast};
}
function renderDayEnd(){
  const box=$('deBox'); if(!box) return; const d=dayEndData(($('deDate')&&$('deDate').value)||todayStr());
  box.innerHTML=`<div class="bill-line"><span class="k">🌅 ${t('morning')}</span><span class="v">${num(d.m.reduce((s,x)=>s+x.qty,0))} L • ${money(d.m.reduce((s,x)=>s+x.amount,0))}</span></div>
    <div class="bill-line"><span class="k">🌙 ${t('evening')}</span><span class="v">${num(d.v.reduce((s,x)=>s+x.qty,0))} L • ${money(d.v.reduce((s,x)=>s+x.amount,0))}</span></div>
    <div class="bill-line tot"><span class="k">${t('c_sale')}</span><span class="v">${num(d.qty)} L • ${money(d.amt)}</span></div>
    <div class="bill-line"><span class="k">${t('c_purch')}</span><span class="v">${money(d.purch)}</span></div>
    <div class="bill-line"><span class="k">💵 ${t('pay_lbl')}</span><span class="v">${money(d.pays)}</span></div>
    <div class="bill-line"><span class="k">💸 ${t('exp_lbl')}</span><span class="v">- ${money(d.exp)}</span></div>
    <div class="bill-line"><span class="k">📉 ${t('wastage')}</span><span class="v">- ${money(d.wast)}</span></div>
    <div class="bill-line tot"><span class="k">${t('net_profit')}</span><span class="v" style="color:${d.net>=0?'var(--green)':'var(--red)'}">${money(d.net)}</span></div>
    <div class="hint" style="margin-top:8px">${d.cust} / ${d.defCust} ${t('party_lbl')} — ${t('dayend_cust')}</div>`;
}
function shareDayEnd(){
  const d=dayEndData(($('deDate')&&$('deDate').value)||todayStr());
  const txt='🥛 '+shopName()+'\n'+t('dayend')+' — '+fmtDate(d.date)+'\n────────────\n'
    +'🌅 '+t('morning')+': '+num(d.m.reduce((s,x)=>s+x.qty,0))+' L • '+money(d.m.reduce((s,x)=>s+x.amount,0))+'\n'
    +'🌙 '+t('evening')+': '+num(d.v.reduce((s,x)=>s+x.qty,0))+' L • '+money(d.v.reduce((s,x)=>s+x.amount,0))+'\n'
    +t('c_sale')+': '+num(d.qty)+' L • '+money(d.amt)+'\n'
    +'💵 '+t('pay_lbl')+': '+money(d.pays)+'\n💸 '+t('exp_lbl')+': '+money(d.exp)+'\n'
    +'────────────\n'+t('net_profit')+': '+money(d.net);
  if(navigator.share){ navigator.share({title:t('dayend'),text:txt}).catch(function(){}); }
  else { if(navigator.clipboard) navigator.clipboard.writeText(txt).catch(function(){}); toast(t('copied')); }
}
/* ---- 💰 Monthly budget ---- */
function modBudget(){ return `<div class="card"><h3>💰 ${t('budget')}</h3><div class="hint" style="margin-bottom:10px">${t('budget_hint')}</div><div id="bdBox"></div>
  <div class="btn-row" style="margin-top:12px"><button class="btn wa sm" style="flex:1" onclick="budgetAlertSend()">📲 ${t('budget_alert')}</button></div></div>`; }
function renderBudget(){
  const box=$('bdBox'); if(!box) return;
  const m=monthStr(); const b=state.settings.budget||{};
  const cats=CATS.concat((state.settings.customCats||[]).map(c=>c.id));
  const act={}; state.expenses.filter(x=>x.date.startsWith(m)).forEach(x=>{ act[x.cat]=(act[x.cat]||0)+x.amount; });
  const rows=cats.map(c=>({c:c,label:catLabel(c),budget:b[c]||0,actual:act[c]||0})).filter(r=>r.budget>0||r.actual>0);
  const tb=rows.reduce((s,r)=>s+r.budget,0), ta=rows.reduce((s,r)=>s+r.actual,0);
  box.innerHTML=(rows.length?rows.map(function(r){
    const pc=r.budget?Math.min(100,Math.round(r.actual/r.budget*100)):100;
    const over=r.budget&&r.actual>r.budget;
    return `<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:13.5px"><b>${esc(r.label)}</b><span style="color:${over?'var(--red)':'var(--muted)'}">${money(r.actual)}${r.budget?(' / '+money(r.budget)):''}</span></div><div style="height:8px;background:var(--soft);border-radius:6px;overflow:hidden;margin-top:4px"><div style="height:100%;width:${pc}%;background:${over?'var(--red)':'var(--green)'}"></div></div></div>`;
  }).join(''):'<div class="empty">'+t('no_data')+'</div>')
  +`<div class="divider"></div><div class="bill-line tot"><span class="k">${t('total')}</span><span class="v">${money(ta)} / ${money(tb)}</span></div>
    <button class="btn ghost" style="width:100%;margin-top:12px" onclick="openBudget()">✏️ ${t('budget_set')}</button>`;
}
function openBudget(){
  const b=state.settings.budget||{};
  openModal(`<div class="sheet-head"><h2>${t('budget')}</h2><button class="x" onclick="closeModal()">✕</button></div>
    ${CATS.map(c=>`<div class="field"><label>${catLabel(c)}</label><input type="number" id="bg_${c}" value="${b[c]||''}" placeholder="0" /></div>`).join('')}
    <button class="btn" onclick="saveBudget()">${t('save')}</button>`);
}
function saveBudget(){
  const b={};
  CATS.forEach(function(c){ const el=$('bg_'+c); const v=el?parseFloat(el.value)||0:0; if(v>0) b[c]=v; });
  state.settings.budget=b; save(); closeModal(); rerenderModule(); try{ renderBudget(); }catch(e){} toast(t('saved'));
}

/* ---- 🔐 Permissions + 📍 location ---- */
function modPerms(){
  return `<div class="card"><h3>🔐 ${t('perms')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('perms_hint')}</div>
    <div id="pmBox"></div>
    <button class="btn" style="width:100%;margin-top:12px" onclick="askPerms()">${t('perms_ask')}</button></div>`;
}
function renderPerms(){
  const box=$('pmBox'); if(!box) return;
  const list=[['CAMERA','📷','perm_cam'],['STORAGE','🗂️','perm_store'],['LOCATION','📍','perm_loc'],['CONTACTS','👤','perm_contact'],['MICROPHONE','🎤','perm_mic'],['NOTIFICATIONS','🔔','perm_notif'],['PHONE','📞','perm_phone'],['VIBRATE','📳','perm_vib']];
  let st={};
  try{ if(window.MilkNative&&window.MilkNative.permStatus){ st=JSON.parse(window.MilkNative.permStatus()||'{}'); } }catch(e){}
  box.innerHTML=list.map(function(x){ const ok=!!st[x[0]];
    return `<div class="sw"><span class="lb">${x[1]} ${t(x[2])}</span><span style="font-size:12px;font-weight:700;color:${ok?'var(--green)':'var(--muted)'}">${ok?t('perm_granted'):t('perm_todo')}</span></div>`;
  }).join('');
}
function askPerms(){
  try{
    if(window.MilkNative&&window.MilkNative.requestPermissions){ window.MilkNative.requestPermissions(); toast(t('perms_asked')); setTimeout(renderPerms,1600); }
    else { toast(t('perms_web')); }
  }catch(e){ toast(t('perms_web')); }
}
function getLocation(){
  if(!navigator.geolocation){ toast(t('loc_na')); return; }
  try{
    navigator.geolocation.getCurrentPosition(function(pos){
      state.settings.shopLoc={lat:pos.coords.latitude,lng:pos.coords.longitude};
      save(); renderLocInfo(); toast(t('loc_done'));
    }, function(){ toast(t('loc_na')); }, {enableHighAccuracy:true, timeout:12000, maximumAge:60000});
  }catch(e){ toast(t('loc_na')); }
}
function renderLocInfo(){
  const el=$('locInfo'); if(!el) return; const l=state.settings.shopLoc;
  el.innerHTML=l?('<a href="https://maps.google.com/?q='+l.lat+','+l.lng+'" target="_blank">📍 '+t('loc_map')+' ('+(+l.lat).toFixed(4)+', '+(+l.lng).toFixed(4)+')</a>'):t('loc_hint');
}

/* ---- native bridges: contacts, perms, dial ---- */
function pickContactJs(){
  try{
    if(window.MilkNative&&window.MilkNative.pickContact){ window.MilkNative.pickContact(); return; }
    toast(t('perms_web'));
  }catch(e){ toast(t('perms_web')); }
}
function __contactPicked(name,phone){
  try{
    if($('c_name') && (!($('c_name').value) || $('c_name').value.trim()==='') ) $('c_name').value=name||'';
    if($('c_phone') && phone) $('c_phone').value=String(phone).replace(/\s+/g,'');
    if(name||phone) toast(t('contact_done')); else toast(t('contact_na'));
  }catch(e){}
}
function __permsDone(){ try{ renderPerms(); toast(t('perm_granted')); }catch(e){} }
function dialParty(id){
  const p=partyById(id); if(!p||!p.phone){ toast(t('no_phone')); return; }
  try{ if(window.MilkNative&&window.MilkNative.dial){ window.MilkNative.dial(p.phone); return; } }catch(e){}
  try{ window.location.href='tel:'+p.phone; }catch(e){}
}

/* ================= AI ASSISTANT + INSIGHTS + MONTH CLOSE ================= */
function getAiKey(){ try{ return localStorage.getItem('milk_ai_key')||''; }catch(e){ return ''; } }
function saveAiKey(){ try{ const v=($('setAiKey')&&$('setAiKey').value||'').trim(); localStorage.setItem('milk_ai_key',v); toast(v?t('ai_key_saved'):t('ai_key_clear')); }catch(e){} }
function clearAiKey(){ try{ localStorage.removeItem('milk_ai_key'); if($('setAiKey')) $('setAiKey').value=''; toast(t('ai_key_clear')); }catch(e){} }
function modAI(){
  const key=getAiKey();
  return `<div class="card"><h3>🤖 ${t('ai')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('ai_hint')}</div>
    <div id="aiChat"></div>
    <div class="chips" style="margin-top:8px">
      <button class="chip" onclick="aiQuick(this)">${t('ai_q1')}</button>
      <button class="chip" onclick="aiQuick(this)">${t('ai_q2')}</button>
      <button class="chip" onclick="aiQuick(this)">${t('ai_q3')}</button>
      <button class="chip" onclick="aiQuick(this)">${t('ai_q4')}</button>
    </div>
    <div class="ai-row"><input type="text" id="aiInput" placeholder="${t('ai_ph')}" onkeydown="if(event.key==='Enter')aiSend()" /><button class="btn" style="width:auto" onclick="aiSend()">${t('ai_send')}</button></div>
    <div class="hint" style="margin-top:8px">${key?'✅ '+t('ai_key')+' ✓':'⚠️ '+t('ai_nokey')}</div></div>`;
}
function aiContext(){
  const m=monthStr(), t0=todayStr();
  const st=monthStats(m);
  const td=state.entries.filter(e=>e.date===t0&&e.kind==='sale');
  const dues=state.parties.filter(p=>p.type==='customer').map(p=>({n:p.name,b:Math.round(partyBalance(p.id))})).filter(x=>x.b>0).sort((a,b)=>b.b-a.b).slice(0,6);
  const cust=state.parties.filter(p=>p.type==='customer').length;
  const sup=state.parties.filter(p=>p.type==='supplier').length;
  const w=state.wastage.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+(x.value||0),0);
  return 'दुकान का नाम: '+shopName()
    +'\nआज ('+fmtDate(t0)+'): '+num(td.reduce((s,e)=>s+e.qty,0))+' लीटर बिक्री, ₹'+Math.round(td.reduce((s,e)=>s+e.amount,0))
    +'\nइस महीने ('+fmtMonth(m)+'): बिक्री ₹'+Math.round(st.sale)+', खरीद ₹'+Math.round(st.purch)+', खर्च ₹'+Math.round(st.exp)+', बर्बादी ₹'+Math.round(w)+', शुद्ध मुनाफ़ा ₹'+Math.round(st.net)
    +'\nग्राहक: '+cust+', किसान/सप्लायर: '+sup
    +'\nसबसे ज़्यादा बकाया: '+(dues.map(d=>d.n+' ₹'+d.b).join(' | ')||'कोई बकाया नहीं');
}
function aiQuick(btn){ const q=btn?btn.textContent:''; if($('aiInput')) $('aiInput').value=q; askAI(q); }
function aiSend(){ const q=($('aiInput')&&$('aiInput').value||'').trim(); if(!q){ return; } if($('aiInput')) $('aiInput').value=''; askAI(q); }
function askAI(q){
  const box=$('aiChat'); if(!box) return;
  const key=getAiKey();
  box.innerHTML+='<div class="chat-u">'+esc(q)+'</div>';
  if(!key){ box.innerHTML+='<div class="chat-b">'+esc(t('ai_nokey'))+'</div>'; return; }
  if(!navigator.onLine){ box.innerHTML+='<div class="chat-b">'+esc(t('ai_offline'))+'</div>'; return; }
  const id='aiw'+Date.now(); box.innerHTML+='<div class="chat-b" id="'+id+'">…</div>';
  const url='https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key='+encodeURIComponent(key);
  const prompt='तुम एक दूध-डेयरी व्यापार के सहायक हो। नीचे दुकान का असली डेटा दिया है। बहुत छोटा, सरल, सटीक और सीधा जवाब हिंदी में दो (सिर्फ़ 3-5 पंक्तियाँ)।\n\n'+aiContext()+'\n\nसवाल: '+q;
  fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.4,maxOutputTokens:500}})})
   .then(function(r){ return r.json(); })
   .then(function(j){
     let txt='';
     try{ txt=j.candidates[0].content.parts[0].text; }catch(e){ txt=(j.error&&j.error.message)||t('ai_fail'); }
     const w=$(id); if(w) w.textContent=txt;
   })
   .catch(function(){ const w=$(id); if(w) w.textContent=t('ai_fail'); });
}
function modInsights(){ return `<div class="card"><h3>🔎 ${t('insights')}</h3><div id="insBox"></div></div>`; }
function renderInsights(){
  const box=$('insBox'); if(!box) return;
  const now=new Date(); const p2=n=>String(n).padStart(2,'0');
  const m=now.getFullYear()+'-'+p2(now.getMonth()+1);
  const pd=new Date(now.getFullYear(),now.getMonth()-1,1); const pm=pd.getFullYear()+'-'+p2(pd.getMonth()+1);
  const st=monthStats(m), ps=monthStats(pm);
  const out=[];
  if(st.sale>0){ const mg=Math.round(st.net/st.sale*100);
    out.push([mg<12?'warn':'ok','💰 '+t('ins_margin'), mg+'% — '+(mg<12?t('ins_margin_low'):t('ins_margin_ok'))]); }
  const dues=state.parties.filter(p=>p.type==='customer').map(p=>({p:p,b:partyBalance(p.id)})).filter(x=>x.b>500).sort((a,b)=>b.b-a.b);
  if(dues.length) out.push(['warn','⏳ '+t('ins_dues'), dues.length+' '+t('party_lbl')+' · '+money(dues.reduce((s,x)=>s+x.b,0))+' — '+esc(dues[0].p.name)]);
  const w=state.wastage.filter(x=>x.date.startsWith(m)).reduce((s,x)=>s+(x.value||0),0);
  if(w>0&&st.sale>0) out.push([(w/st.sale>0.03)?'warn':'ok','📉 '+t('wastage'), money(w)+' ('+Math.round(w/st.sale*100)+'%)']);
  if(ps.sale>0){ const d=Math.round((st.sale-ps.sale)/ps.sale*100);
    out.push([d>=0?'ok':'warn','📈 '+t('c_sale'), (d>=0?'+':'')+d+'% '+t('ins_vs_prev')]); }
  const cut=new Date(); cut.setDate(cut.getDate()-7); const cs=ymd(cut);
  const last={}; state.entries.forEach(e=>{ if(!last[e.partyId]||e.date>last[e.partyId]) last[e.partyId]=e.date; });
  const inact=state.parties.filter(p=>p.type==='customer'&&p.active!==false&&(!last[p.id]||last[p.id]<cs));
  if(inact.length) out.push(['warn','😴 '+t('inactive'), inact.length+' — '+esc(inact.slice(0,3).map(p=>p.name).join(', '))]);
  const low=state.items.filter(i=>(i.stock||0)<=(i.lowAt||0)).length;
  if(low) out.push(['warn','📦 '+t('stock'), low+' '+t('items_lbl')]);
  box.innerHTML=out.length?out.map(function(o){ return '<div class="ins '+o[0]+'"><span class="ii">'+o[1]+'</span><div>'+o[2]+'</div></div>'; }).join(''):'<div class="empty">'+t('no_data')+'</div>';
}
function modMonthClose(){
  return `<div class="card"><h3>📅 ${t('mclose')}</h3>
    <div class="field" style="margin:0 0 10px"><label>${t('rep_month')}</label><input type="month" id="mcMonth" value="${monthStr()}" onchange="renderMonthClose()" /></div>
    <div id="mcBox"></div>
    <button class="btn" style="width:100%;margin-top:12px" onclick="doMonthClose()">${t('mclose_do')}</button>
    <div class="hint" style="margin-top:8px">${t('mclose_hint')}</div></div>`;
}
function renderMonthClose(){
  const box=$('mcBox'); if(!box) return;
  const m=($('mcMonth')&&$('mcMonth').value)||monthStr();
  const st=monthStats(m);
  const done=(state.closes||[]).find(c=>c.month===m);
  box.innerHTML='<div class="bill-line"><span class="k">'+t('c_sale')+'</span><span class="v">'+money(st.sale)+'</span></div>'
    +'<div class="bill-line"><span class="k">'+t('c_purch')+'</span><span class="v">'+money(st.purch)+'</span></div>'
    +'<div class="bill-line"><span class="k">'+t('c_exp')+'</span><span class="v">'+money(st.exp)+'</span></div>'
    +'<div class="bill-line"><span class="k">'+t('wastage')+'</span><span class="v">'+money(st.wast)+'</span></div>'
    +'<div class="bill-line tot"><span class="k">'+t('net_profit')+'</span><span class="v">'+money(st.net)+'</span></div>'
    +'<div class="hint" style="margin-top:8px">'+(done?('✅ '+t('mclose_done')+' — '+fmtDate(ymd(new Date(done.at)))):t('mclose_open'))+'</div>';
}
function doMonthClose(){
  const m=($('mcMonth')&&$('mcMonth').value)||monthStr();
  const st=monthStats(m);
  const dues=state.parties.map(function(p){ return {id:p.id,b:Math.round(partyBalance(p.id)*100)/100}; }).filter(function(x){ return Math.abs(x.b)>0.5; });
  state.closes=state.closes||[];
  state.closes=state.closes.filter(function(c){ return c.month!==m; });
  state.closes.push({month:m,at:Date.now(),totals:st,dues:dues});
  save(); renderMonthClose(); toast(t('mclose_saved'));
}

/* ================= v14: cash book, farm, reminders ================= */
function animalName(id){ const a=state.animals.find(x=>x.id===id); return a?(a.tag||a.name||'—'):'—'; }
function modCashBook(){
  return `<div class="card"><h3>💵 ${t('cashbook')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('cb_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('cb_m')}</label><input type="number" inputmode="decimal" id="cb_m" /></div>
      <div class="field" style="margin:0"><label>${t('cb_e')}</label><input type="number" inputmode="decimal" id="cb_e" /></div>
    </div>
    <button class="btn" style="width:100%;margin-top:10px" onclick="saveCash()">${t('save')}</button>
    <div id="cbBox" style="margin-top:12px"></div></div>`;
}
function renderCashBook(){
  const el=$('cbBox'); if(!el) return;
  const dt=todayStr(), c=state.cash.filter(x=>x.date===dt);
  const m=(c.find(x=>x.shift==='morning')||{}).amount||0, e=(c.find(x=>x.shift==='evening')||{}).amount||0;
  const pays=state.payments.filter(x=>x.date===dt).reduce((s,x)=>s+x.amount,0);
  const exp=state.expenses.filter(x=>x.date===dt).reduce((s,x)=>s+x.amount,0);
  const expect=pays-exp, diff=(m+e)-expect;
  el.innerHTML=`<div class="bill-line"><span class="k">${t('cb_m')}</span><span class="v">${money(m)}</span></div>
    <div class="bill-line"><span class="k">${t('cb_e')}</span><span class="v">${money(e)}</span></div>
    <div class="bill-line tot"><span class="k">${t('cb_total')}</span><span class="v">${money(m+e)}</span></div>
    <div class="bill-line"><span class="k">${t('pay_lbl')} − ${t('exp_lbl')}</span><span class="v">${money(expect)}</span></div>
    ${(Math.abs(diff)>1 && (m+e)>0)?`<div class="ins warn"><span class="ii">⚠️</span><div>${t('cb_mismatch')} (${money(diff)})</div></div>`:''}
    <div class="divider"></div>
    ${state.cash.length?state.cash.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,10).map(x=>`<div class="list-item"><div class="avatar">💵</div><div class="li-main"><div class="t">${fmtDate(x.date)}</div><div class="s">${x.shift==='evening'?t('cb_e'):t('cb_m')}</div></div><div class="li-amt"><div class="a">${money(x.amount)}</div></div></div>`).join(''):'<div class="empty">'+t('no_data')+'</div>'}`;
}
function saveCash(){
  const m=parseFloat(($('cb_m')||{}).value)||0, e=parseFloat(($('cb_e')||{}).value)||0, dt=todayStr();
  state.cash=state.cash.filter(x=>x.date!==dt);
  if(m>0) state.cash.push({id:uid(),date:dt,shift:'morning',amount:m});
  if(e>0) state.cash.push({id:uid(),date:dt,shift:'evening',amount:e});
  save(); renderCashBook(); toast(t('cb_saved'));
}
/* ---- farm ---- */
function modAHealth(){
  const list=state.animals.filter(a=>a.active!==false);
  const opts=list.length?list.map(a=>`<option value="${a.id}">${esc(a.tag||a.name||'—')}</option>`).join(''):'<option value="">—</option>';
  const rows=state.health.slice().sort((a,b)=>b.date.localeCompare(a.date));
  return `<div class="card"><h3>🩺 ${t('ahealth')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('ah_hint')}</div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('animals')}</label><select id="ah_an">${opts}</select></div>
      <div class="field" style="margin:0"><label>${t('ah_kind')}</label><select id="ah_kind"><option value="vaccine">${t('ah_vaccine')}</option><option value="illness">${t('ah_illness')}</option><option value="med">${t('ah_med')}</option></select></div>
    </div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('date')}</label><input type="date" id="ah_date" value="${todayStr()}" /></div>
      <div class="field" style="margin:0"><label>${t('ah_next')}</label><input type="date" id="ah_next" /></div>
    </div>
    <div class="field"><label>${t('ah_detail')}</label><input type="text" id="ah_detail" /></div>
    <button class="btn" onclick="saveHealth()">${t('save')}</button></div>
  <div class="card"><h3>📒 रिकॉर्ड</h3>
    ${rows.length?rows.map(h=>`<div class="list-item"><div class="avatar">🩺</div><div class="li-main"><div class="t">${esc(animalName(h.animalId))} · ${h.kind==='vaccine'?t('ah_vaccine'):h.kind==='illness'?t('ah_illness'):t('ah_med')}</div><div class="s">${fmtDate(h.date)}${h.next?' • '+t('ah_next')+' '+fmtDate(h.next):''}${h.detail?' • '+esc(h.detail):''}</div></div><button class="btn danger xs" onclick="delHealth('${h.id}')">🗑</button></div>`).join(''):'<div class="empty">'+t('no_data')+'</div>'}</div>`;
}
function saveHealth(){
  const an=($('ah_an')||{}).value||''; if(!an){ toast(t('no_data_toast')); return; }
  state.health.push({id:uid(),animalId:an,kind:($('ah_kind')||{}).value||'vaccine',date:($('ah_date')||{}).value||todayStr(),next:($('ah_next')||{}).value||'',detail:($('ah_detail')||{}).value||''});
  save(); rerenderModule(); toast(t('saved'));
}
function delHealth(id){ state.health=state.health.filter(x=>x.id!==id); save(); rerenderModule(); toast(t('deleted')); }
function modAVacc(){
  const today=todayStr();
  const up=state.health.filter(h=>h.next).sort((a,b)=>a.next.localeCompare(b.next));
  const late=up.filter(h=>h.next<today);
  return `<div class="card"><h3>💊 ${t('avacc')}</h3>
    ${late.length?`<div class="ins warn"><span class="ii">⚠️</span><div>${late.length} की तारीख निकल गई</div></div>`:''}
    ${up.length?up.map(h=>`<div class="list-item"><div class="avatar" style="background:${h.next<today?'var(--red-l)':'var(--green-l)'};color:${h.next<today?'var(--red)':'var(--green-d)'}">💊</div><div class="li-main"><div class="t">${esc(animalName(h.animalId))}</div><div class="s">${fmtDate(h.next)}${h.detail?' • '+esc(h.detail):''}</div></div></div>`).join(''):'<div class="empty">कोई आगामी टीका नहीं</div>'}</div>`;
}
function modAProd(){
  const list=state.animals.filter(a=>a.active!==false);
  const opts=list.length?list.map(a=>`<option value="${a.id}">${esc(a.tag||a.name||'—')}</option>`).join(''):'<option value="">—</option>';
  return `<div class="card"><h3>🥛 ${t('aprod')}</h3>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('animals')}</label><select id="ap_an">${opts}</select></div>
      <div class="field" style="margin:0"><label>${t('date')}</label><input type="date" id="ap_date" value="${todayStr()}" /></div>
    </div>
    <div class="row2">
      <div class="field" style="margin:0"><label>🌅 ${t('morning')}</label><input type="number" inputmode="decimal" id="ap_m" /></div>
      <div class="field" style="margin:0"><label>🌙 ${t('evening')}</label><input type="number" inputmode="decimal" id="ap_e" /></div>
    </div>
    <button class="btn" style="width:100%;margin-top:10px" onclick="saveProd()">${t('save')}</button>
    <div id="apBox" style="margin-top:12px"></div></div>`;
}
function renderAProd(){
  const el=$('apBox'); if(!el) return;
  const dt=todayStr();
  const rows=state.animals.filter(a=>a.active!==false).map(function(a){
    const m=state.prod.filter(x=>x.animalId===a.id&&x.date===dt&&x.shift==='morning').reduce((s,x)=>s+x.qty,0);
    const e=state.prod.filter(x=>x.animalId===a.id&&x.date===dt&&x.shift==='evening').reduce((s,x)=>s+x.qty,0);
    return {a:a,m:m,e:e,t:m+e};
  }).sort((x,y)=>y.t-x.t);
  const best=rows[0];
  el.innerHTML=((best&&best.t>0)?`<div class="ins ok"><span class="ii">🏆</span><div>${esc(best.a.tag||best.a.name||'—')} — ${num(best.t)} L (सबसे ज़्यादा)</div></div>`:'')
    +rows.map(r=>`<div class="bill-line"><span class="k">${esc(r.a.tag||r.a.name||'—')}</span><span class="v">${num(r.m)} + ${num(r.e)} = ${num(r.t)} L</span></div>`).join('');
}
function saveProd(){
  const an=($('ap_an')||{}).value||''; if(!an){ toast(t('no_data_toast')); return; }
  const dt=($('ap_date')||{}).value||todayStr();
  const m=parseFloat(($('ap_m')||{}).value)||0, e=parseFloat(($('ap_e')||{}).value)||0;
  state.prod=state.prod.filter(x=>!(x.animalId===an&&x.date===dt));
  if(m>0) state.prod.push({id:uid(),animalId:an,date:dt,shift:'morning',qty:m});
  if(e>0) state.prod.push({id:uid(),animalId:an,date:dt,shift:'evening',qty:e});
  save(); renderAProd(); toast(t('saved'));
}
function modFeed(){
  return `<div class="card"><h3>🌾 ${t('feed')}</h3>
    <div class="hint" style="margin-bottom:10px">${t('feed_hint')}</div>
    <div class="field"><label>${t('feed_name')}</label><input type="text" id="fd_name" /></div>
    <div class="row2">
      <div class="field" style="margin:0"><label>${t('feed_stock')}</label><input type="number" inputmode="decimal" id="fd_stock" /></div>
      <div class="field" style="margin:0"><label>${t('feed_low')}</label><input type="number" inputmode="decimal" id="fd_low" /></div>
    </div>
    <button class="btn" style="width:100%;margin-top:10px" onclick="saveFeed()">${t('save')}</button>
    <div id="fdBox" style="margin-top:12px"></div></div>`;
}
function renderFeed(){
  const el=$('fdBox'); if(!el) return;
  const list=state.feed||[];
  el.innerHTML=list.length?list.map(f=>{ const low=(f.stock||0)<=(f.lowAt||0);
    return `<div class="list-item"><div class="avatar" style="background:${low?'var(--amber-l)':'var(--green-l)'};color:${low?'var(--amber)':'var(--green-d)'}">🌾</div><div class="li-main"><div class="t">${esc(f.name)}</div><div class="s">${t('feed_stock')}: ${num(f.stock||0)}${low?' • ⚠️ '+t('feed_low')+' '+num(f.lowAt||0):''}</div></div><button class="btn grey xs" onclick="editRec('feed','${f.id}')">✏️</button><button class="btn danger xs" onclick="delFeed('${f.id}')">🗑</button></div>`; }).join(''):'<div class="empty">'+t('no_data')+'</div>';
}
function saveFeed(){
  const n=($('fd_name')||{}).value||''; if(!n.trim()){ toast(t('enter_name')); return; }
  state.feed=state.feed||[];
  state.feed.push({id:uid(),name:n.trim(),stock:parseFloat(($('fd_stock')||{}).value)||0,lowAt:parseFloat(($('fd_low')||{}).value)||0});
  save(); rerenderModule(); toast(t('saved'));
}
function delFeed(id){ state.feed=(state.feed||[]).filter(x=>x.id!==id); save(); rerenderModule(); toast(t('deleted')); }
function modFat30(){ return `<div class="card"><h3>📊 ${t('fat30')}</h3><div id="fatBox"></div></div>`; }
function renderFat30(){
  const box=$('fatBox'); if(!box) return;
  const days=[]; const now=new Date();
  for(let i=29;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i); days.push(ymd(d)); }
  const ag=days.map(function(dt){ const es=state.entries.filter(e=>e.date===dt&&e.kind==='sale'&&e.fat>0);
    const q=es.reduce((s,e)=>s+e.qty,0), w=es.reduce((s,e)=>s+e.qty*e.fat,0); return {dt:dt,f:q?w/q:0}; });
  const vals=ag.filter(x=>x.f>0).map(x=>x.f);
  if(!vals.length){ box.innerHTML='<div class="empty">'+t('no_fat')+'</div>'; return; }
  const max=Math.max.apply(null,vals), min=Math.min.apply(null,vals);
  const avg=vals.reduce((s,v)=>s+v,0)/vals.length;
  box.innerHTML='<div class="fatstrip">'+ag.map(x=>`<i style="height:${Math.round(x.f/max*100)}%" title="${x.dt} · ${x.f?x.f.toFixed(1):'-'}"></i>`).join('')+'</div>'
    +`<div class="bill-line" style="margin-top:10px"><span class="k">${t('q_avg')}</span><span class="v">${num(Math.round(avg*100)/100)}</span></div>`
    +`<div class="bill-line"><span class="k">सबसे कम / ज़्यादा</span><span class="v">${num(Math.round(min*100)/100)} / ${num(Math.round(max*100)/100)}</span></div>`;
}
function modWastPie(){ return `<div class="card"><h3>📉 ${t('wastpie')}</h3><div id="wpBox"></div></div>`; }
function renderWastPie(){
  const box=$('wpBox'); if(!box) return;
  const m=monthStr(); const list=state.wastage.filter(x=>x.date.startsWith(m));
  if(!list.length){ box.innerHTML='<div class="empty">'+t('no_data')+'</div>'; return; }
  const by={}; list.forEach(x=>{ const r=((x.reason||'').trim()||'अन्य'); by[r]=(by[r]||0)+(x.value||0); });
  const keys=Object.keys(by), tot=keys.reduce((s,k)=>s+by[k],0)||1;
  const cols=['#0f7b53','#b7791f','#c0392b','#1d6fb8','#7b3fb0','#0c7b7b'];
  let acc=0;
  const stops=keys.map(function(k,i){ const a=acc/tot*360; acc+=by[k]; const b=acc/tot*360; return cols[i%cols.length]+' '+a+'deg '+b+'deg'; }).join(',');
  box.innerHTML='<div style="display:flex;gap:14px;align-items:center"><div class="pie" style="background:conic-gradient('+stops+')"></div><div style="flex:1">'
    +keys.map((k,i)=>`<div class="bill-line" style="padding:3px 0"><span class="k"><i style="display:inline-block;width:9px;height:9px;border-radius:2px;background:${cols[i%cols.length]};margin-right:6px"></i>${esc(k)}</span><span class="v">${money(by[k])} (${Math.round(by[k]/tot*100)}%)</span></div>`).join('')
    +'</div></div>';
}
/* ---- repeat last + reminders + sync ---- */
function repeatLast(){
  const es=state.entries.filter(e=>e.kind==='sale').slice().sort((a,b)=>(String(b.date)+String(b.id)).localeCompare(String(a.date)+String(a.id)));
  const last=es[0];
  if(!last){ toast(t('repeat_none')); return; }
  const dup=Object.assign({},last,{id:uid(),date:todayStr()});
  state.entries.push(dup); save(); refreshAll(); toast(t('repeat_done'));
}
let alarmTimer=null;
function alarmBeep(){
  try{
    const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
    const ctx=new AC(); const o=ctx.createOscillator(), g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination); o.type='sine'; o.frequency.value=880;
    g.gain.setValueAtTime(0.0001,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.25,ctx.currentTime+0.05);
    g.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.9);
    o.start(); o.stop(ctx.currentTime+0.95);
    setTimeout(function(){ try{ ctx.close(); }catch(e){} },1400);
  }catch(e){}
}
function shiftRemindCheck(force){
  if(state.settings.shiftRemind===false) return;
  const now=new Date(), h=now.getHours();
  const isAlarm=(h===6||h===17);
  if(!isAlarm && force!==true) return;
  const key=todayStr()+(h<12?'M':'E');
  if(force!==true && state.settings.lastRemind===key) return;
  state.settings.lastRemind=key; save();
  const msg=(h<12?'सुबह':'शाम')+' '+t('alarm_body');
  try{ if(window.Notification && Notification.permission==='granted') new Notification('दूध हिसाब',{body:msg, tag:'milk-shift'}); }catch(e){}
  try{ alarmBeep(); }catch(e){}
  toast('⏰ '+msg);
}
function nextAlarmTime(){ const now=new Date(); const c=[];
  [6,17].forEach(function(h){ const d=new Date(); d.setHours(h,0,0,0); if(d<=now) d.setDate(d.getDate()+1); c.push(d); });
  c.sort(function(a,b){ return a-b; }); return c[0]; }
function scheduleShiftAlarm(){
  if(state.settings.shiftRemind===false) return;
  try{ if(alarmTimer) clearTimeout(alarmTimer); }catch(e){}
  const ms=Math.max(2000, nextAlarmTime().getTime()-Date.now()+1500);
  alarmTimer=setTimeout(function(){ try{ shiftRemindCheck(true); }catch(e){} try{ scheduleShiftAlarm(); }catch(e){} }, ms);
}
function testAlarm(){ try{ alarmBeep(); }catch(e){} shiftRemindCheck(true); }
/* swipe on the entries (register) screen */
function initSwipe(){
  const el=document.getElementById('view-entries'); if(!el||el._swipe) return; el._swipe=true;
  let x0=0,y0=0,t0=0;
  el.addEventListener('touchstart',function(e){ const t=e.touches[0]; x0=t.clientX; y0=t.clientY; t0=Date.now(); },{passive:true});
  el.addEventListener('touchend',function(e){
    const t=e.changedTouches[0]; if(!t) return;
    const dx=t.clientX-x0, dy=t.clientY-y0, dt=Date.now()-t0;
    if(dt>800) return; if(Math.abs(dx)<70) return; if(Math.abs(dy)>Math.abs(dx)) return;
    if(typeof uiTab!=='undefined' && uiTab!=='entries') return;
    try{ if(dx<0) shiftDay(1); else shiftDay(-1); toast(dx<0?'▶ '+fmtDate($('entryDate').value):'◀ '+fmtDate($('entryDate').value)); }catch(err){}
  },{passive:true});
}
function requestNotif(){ try{ if(window.Notification){ Notification.requestPermission().then(function(p){ toast(p==='granted'?'🔔 नोटिफिकेशन चालू':t('perms_web')); }); } else toast(t('perms_web')); }catch(e){ toast(t('perms_web')); } }
function markSynced(){ try{ const now=Date.now(); state.entries.forEach(function(e){ e.syncAt=now; }); save(); }catch(e){} }

/* ================= DATA CHECK ================= */
function modDataCheck(){ return `<div class="card"><div class="hint" style="margin-bottom:10px">${t('dc_hint')}</div><div id="dcBox"></div></div>`; }
function renderDataCheck(){
  const el=$('dcBox'); if(!el) return;
  const seen={},dups=[]; state.entries.forEach(e=>{ const k=e.partyId+'|'+e.date+'|'+e.shift+'|'+(e.itemId||''); if(seen[k]) dups.push(e); else seen[k]=1; });
  const zero=state.entries.filter(e=>!e.qty||e.qty<=0);
  const nodef=state.parties.filter(p=>p.type==='customer'&&!(p.defaultQty>0));
  const negst=state.items.filter(it=>stockOf(it.id)<0);
  const row=(n,label)=>`<div class="bill-line"><span class="k">${label}</span><span class="v" style="font-weight:700;color:${n?'var(--red)':'var(--green)'}">${n}</span></div>`;
  el.innerHTML=row(dups.length,t('dc_dup'))+row(zero.length,t('dc_zeroqty'))+row(nodef.length,t('dc_nodefault'))+row(negst.length,t('dc_negstock'))
    +((dups.length||zero.length)?`<div class="btn-row" style="margin-top:12px"><button class="btn" onclick="cleanData()">${t('dc_clean')}</button></div>`:'')
    +((!dups.length&&!zero.length&&!nodef.length&&!negst.length)?`<div class="hint" style="margin-top:10px">${t('dc_allok')}</div>`:'');
}
function cleanData(){
  if(!confirm(t('dc_clean')+'?')) return;
  const seen={},keep=[]; let removed=0;
  state.entries.forEach(e=>{ const k=e.partyId+'|'+e.date+'|'+e.shift+'|'+(e.itemId||'');
    if(!e.qty||e.qty<=0){ removed++; return; } if(seen[k]){ removed++; return; } seen[k]=1; keep.push(e); });
  state.entries=keep; save(); renderDataCheck(); renderHome(); renderEntries(); toast(removed+' '+t('dc_cleaned'));
}

/* ================= STATIC / BOOT ================= */
function applyStatic(){
  document.documentElement.lang=LANG;
  $('appTitle').textContent=shopName(); $('appSub').textContent=t('tagline');
  const d=new Date(); $('topDate').textContent=d.getDate()+' '+MONTHS[LANG][d.getMonth()]+' '+d.getFullYear();
  const map={'t-home':'tab_home','t-entries':'tab_entries','t-parties':'tab_parties','t-bills':'tab_bills','t-more':'tab_more',
    'l-todaySale':'today_sale','l-todayPurchase':'today_purchase','l-monthProfit':'month_profit','l-receivable':'receivable',
    'l-chart':'chart','l-todayEntries':'today_entries','l-todayCust':'today_cust','l-partyDues':'party_dues','l-lowStock':'low_stock','l-pickDate':'pick_date','l-milkEntries':'milk_entries',
    'l-partyList':'party_list','l-billing':'billing','l-anchor':'anchor','l-periodSummary':'periodSummary','l-totalMilk2':'totalMilk2','l-billSale':'billSale','l-billPurch':'billPurch','l-paidPeriod':'paidPeriod','l-duePeriod':'duePeriod','l-partyBills':'partyBills',
    'l-modules':'modules','l-modHint':'mod_hint','l-bkRemind':'backup_reminder','l-targetProgress':'target',
    'b-addEntryHome':'add_entry','b-addEntry':'add_entry','b-bulk':'bulk_entry','b-bulkHome':'bulk_entry','b-autoHome':'whole_day','b-autoEntry':'whole_day',
    'b-remind':'reminders','b-bulkRemind':'bulk_remind','b-addParty':'add_customer','b-bkNow':'backup_now','b-allPdf':'all_pdf','b-allPrint':'print','b-summary':'send','b-shareChart':'send',
    'b-morHome':'morning_entry','b-eveHome':'evening_entry',
    'per-day':'rep_day','per-d10':'rep_tenday','per-d15':'rep_d15','per-month':'rep_month','seg-cust':'customers','seg-sup':'farmers',
    'b-prevDay':'prev','b-today':'today','b-nextDay':'next','t-search':'tab_search','l-searchAll':'search_all','b-bulkBill':'bulkbill'};
  for(const k in map) if($(k)) $(k).textContent=t(map[k]);
  $('b-addParty').textContent=uiPartyType==='supplier'?t('add_farmer'):t('add_customer');
  if($('partySearch')) $('partySearch').placeholder=t('search_ph');
  if($('entrySearch')) $('entrySearch').placeholder=t('search_ph');
  if($('srchInput')) $('srchInput').placeholder=t('srch_ph');
  renderSettingsBits(); cloudStatus(); renderHub(); renderShiftSeg(); renderHeaderAvatar(); renderProfileCard(); renderQuick(); renderHighlights(); updateBell();
}
function refreshAll(){ renderHome(); renderEntries(); renderParties(); renderBilling(); if(curModule) rerenderModule(); }
function init(){
  setLangVar(state.settings.lang||'hi');
  rebuildIndex();
  $('entryDate').value=todayStr(); $('billAnchor').value=todayStr();
  applyTheme(); applyStatic(); buildLockPad();
  autoMaintenance();
  refreshAll(); switchTab('home');
  loadHandle();
  if(bioNative()){ if(state.settings.pin && !state.settings.biometricLock) showLock(); }
  else if(state.settings.biometricLock && bioSupported()) showBioLock();
  else if(state.settings.pin) showLock();
  renderHeaderAvatar(); waitGis(); initOnline(); registerSW();
  tickClock(); setInterval(tickClock,1000); renderNavBtns();
  if(!state.settings.onboarded) showOnboard();
  startHighlightTimer();
  try{ driveAutoSync(); }catch(e){}
  document.addEventListener('visibilitychange',function(){ if(document.visibilityState==='hidden'){ try{ if(state.settings.driveAuto&&driveReady()) driveBackupNow(true); }catch(e){} } else { try{ driveAutoSync(); }catch(e){} } });
  window.addEventListener('focus',function(){ try{ driveAutoSync(); }catch(e){} });
  if(navigator.serviceWorker){ try{ navigator.serviceWorker.addEventListener('message',function(e){ if(e.data&&e.data.type==='drive-sync'){ try{ driveAutoSync(); }catch(_){} } }); }catch(e){} }
  registerPeriodicSync();
  try{ shiftRemindCheck(); setInterval(shiftRemindCheck, 60000); scheduleShiftAlarm(); }catch(e){}
  try{ initSwipe(); }catch(e){}
}


function relatedRow(id){
  const rel=REL[id]; if(!rel||!rel.length) return '';
  const chips=rel.map(function(r){ const m=MODULES.find(function(x){return x.id===r;}); if(!m) return '';
    return `<button class="chip" onclick="${m.jump?("switchTab('"+m.jump+"')"):("openModule('"+m.id+"')")}">${m.ic} ${esc(LANG==='hi'?m.hi:m.en)}</button>`; }).join('');
  if(!chips) return '';
  return `<div class="card"><h3>🔗 ${t('related')}</h3><div class="chips">${chips}</div></div>`;
}
/* ---- hardware back button bridge ---- */
export function appCanBack(){ try{ return $('modalBg').classList.contains('on') || curModule!=='' || navPos>0 || uiTab!=='home'; }catch(e){ return false; } }
export function updateBackState(){ try{ if(window.MilkNative && window.MilkNative.setBackAvailable) window.MilkNative.setBackAvailable(appCanBack()); }catch(e){} }
export function __appBack(){
  try{
    if($('modalBg').classList.contains('on')){ closeModal(); updateBackState(); return true; }
    if(navPos>0){ navBack(); updateBackState(); return true; }
    if(curModule){ closeModule(); updateBackState(); return true; }
    if(uiTab!=='home'){ switchTab('home'); updateBackState(); return true; }
  }catch(e){}
  return false;
}

/* expose every UI handler so inline onclick + main.js can reach them */
export {
  save, applyTheme, setLang, setTheme, toggleDark, toggleRound, toggleAutoShift, togglePin, askNewPin, saveNewPin, lockBuf, showLock, renderLockDots, lockPress, lockSubmit, buildLockPad, uiPartyType, uiTab, MODULES, switchTab, _lpFired, hubTile, hubHead, renderHub, bindHubTiles, toggleFav, toggleGroup, hubJump, openModule, closeModule, autoShift, tickClock, navLoc, navLabel, navPush, renderNavBtns, navApply, navBack, navForward, entryNav, shiftDay, jumpToday, rerenderModule, openModal, closeModal, renderHome, renderChart, renderLowStock, renderTarget, entryRow, uiShift, setShift, renderShiftSeg, openEntryShift, renderEntries, delEntry, entryItemOptions, openEntry, onEntryParty, setQty, previewAmt, saveEntry, openBulk, saveBulk, autoDefaultEntries, copyPrevDay, shareTodaySummary, setPartyType, setRoute, renderRouteChips, renderParties, openParty, renderPartyItems, addPartyItem, delPartyItem, toggleRateLabel, pickPhoto, shrink, saveParty, delParty, setBillPeriod, renderBilling, openBillDetail, payStats, openPayment, payFill, payPreview, editPayment, saveEditPayment, savePayment, delPayment, billText, shareBill, billRowsHtml, themeHex, billPageCss, billPageHtml, printBill, shareBillLink, printAllStatements, dataUrlToBytes, buildPdfMulti, BILL_LBL, bl, billAccent, billCanvas, downloadAllBillsPdf, shareBillPdf, syncPendingCount, renderSyncCard, toggleAutoBackup, quickBackupFile, billRange, billPdfBytes, billFileName, billView, billDownload, billWhatsApp, REC_DEF, editRec, saveRec, delRec, upiUri, qrMatrix, drawQrTo, showUpiQr, remMsg, dial, waLink, smsLink, waRemind, smsRemind, openReminders, openBulkRemind, renderBulkRemind, bulkSelect, selParties, sendBulkSms, startQueue, renderQueue, queueNext, queuePrev, copyDueList, modBulk, modBulkMonthly, runBulkMonthly, modHoliday, addHoliday, callParty, waParty, delHoliday, modMilkCard, renderMilkCard, modLedger, fillLedParty, openLedgerFor, ledgerData, renderLedger, ledgerText, shareLedger, printLedger, modStatement, statementData, renderStatement, printStatement, shareStatement, modPayments, renderPayments, modDues, renderDues, renderAgeing, modReports, setRepType, REP_TYPES, reportData, renderReports, downloadReportCSV, printReport, pnlData, modPnl, renderPnL, printPnL, modRate, renderRateChart, stockOf, modStock, renderStock, openStockItem, saveStockItem, delStockItem, openStockMove, saveStockMove, delStockMove, CATS, catLabel, allCats, modExpenses, renderExpenses, openExpense, saveExpense, pickExpPhoto, checkBudgetAlert, budgetAlertSend, viewPhoto, delExpense, modExpLog, modReminders, modBackup, GOOGLE_CLIENT_ID, gisInited, waitGis, initGoogle, decodeJwt, handleGoogleCredential, googleSignOut, renderGoogleButton, renderAccountBits, renderHeaderAvatar, fillOwnerFromGoogle, modAccount, setBillLang, setBillColor, b64buf, buf64, importEncrypted, logError, showErrLog, dataCleanup, crc32, zipStore, xmlEsc, colName, sheetXml, exportXlsx, reportChartImage, modRouteMap, loadLeaflet, drawMap, markPartyLoc, toggleShiftRemind, modSettings, renderSettingsBits, fillSettings, addCat, delCat, saveSettings, modHelp, fsHandle, idbOpen, cloudStatus, download, shareBackup, applyImported, exportBackup, importBackup, exportCSV, purgeOld, takeAutoBackup, restoreAutoBackup, cleanNow, renderDataUsage, renderBackupReminder, autoMaintenance, clearAll, chartCanvas, shareChart, regEntry, modRegister, renderRegister, regSet, registerText, shareRegister, printRegister, modDrive, fmtDateTime, renderDriveBits, toggleDriveAuto, initDriveAuth, connectDrive, driveReady, onDriveConnected, driveHeaders, scheduleAutoDriveBackup, driveOpenFile, updateOnlineStatus, initOnline, registerSW, calMonth, modCalendar, calMove, calToday, calOpen, renderCalendar, modTopCust, renderTopCust, modRoutes, renderRoutes, modWastage, wastageRow, openWastage, saveWastage, delWastage, modAnimals, animalRow, openAnimal, saveAnimal, delAnimal, calcBuf, modCalc, calcPress, modNotes, noteRow, addNote, toggleNote, delNote, modSearch, runGlobalSearch, OB, obIdx, renderOnboard, showOnboard, onboardNext, onboardDone, openLocalProfile, saveLocalProfile, renderProfileCard, srchCat, SRCH_CATS, setSrchCat, matchP, partyRow, emptyBox, renderSearch, srchUse, buildNotifications, updateBell, openNotifications, __notifGo, hlIdx, buildHighlights, renderHighlights, startHighlightTimer, renderQuick, HELP_KB, modSupport, askHelper, contactWA, contactMail, modLegal, renderShiftCard, bbPeriod, modBulkBill, setBbPeriod, bbData, renderBulkBill, bbPaint, bbSelect, startBillQueue, renderBillQueue, bqCur, bqSendWa, bqPdf, bqNext, bqPrev, printBillR, driveSilentTried, driveAutoSync, registerPeriodicSync, monthStats, modCompare, renderCompare, modDelivery, deliveryRows, renderDelivery, printDelivery, modQuality, renderQuality, modInactive, renderInactive, modLoans, loanRow, openLoan, saveLoan, toggleLoan, delLoan, modRecurring, recurringRow, openRecurring, saveRecurring, delRecurring, runRecurring, bioNative, bioSupported, b64, b64d, toggleBio, enableBiometric, showBioLock, hideBioLock, bioUsePin, bioUnlock, __bioOk, __bioFail, nextInvNo, modInvoices, invRow, openInvoice, invAutoAmt, calcInvoiceAmt, saveInvoice, delInvoice, shareInvoice, modStaff, staffRow, openStaff, saveStaff, delStaff, openAttendance, renderAtt, toggleAtt, saveAtt, payWages, modTrend, renderTrend, modDayEnd, dayEndData, renderDayEnd, shareDayEnd, modBudget, renderBudget, openBudget, saveBudget, modPerms, renderPerms, askPerms, getLocation, renderLocInfo, pickContactJs, __contactPicked, __permsDone, dialParty, getAiKey, saveAiKey, clearAiKey, modAI, aiContext, aiQuick, aiSend, askAI, modInsights, renderInsights, modMonthClose, renderMonthClose, doMonthClose, animalName, modCashBook, renderCashBook, saveCash, modAHealth, saveHealth, delHealth, modAVacc, modAProd, renderAProd, saveProd, modFeed, renderFeed, saveFeed, delFeed, modFat30, renderFat30, modWastPie, renderWastPie, repeatLast, alarmTimer, alarmBeep, shiftRemindCheck, nextAlarmTime, scheduleShiftAlarm, testAlarm, initSwipe, requestNotif, markSynced, modDataCheck, renderDataCheck, cleanData, applyStatic, refreshAll, init, relatedRow
};
