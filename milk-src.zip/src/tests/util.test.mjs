import test from 'node:test';
import assert from 'node:assert/strict';
import { esc, num, ymd, fmtDate, lastDay, isSup, calcAmount, rangeFor, inRange } from '../app/lib/helpers.js';

test('esc escapes html', () => {
  assert.equal(esc('<b>"x"&\'</b>'), '&lt;b&gt;&quot;x&quot;&amp;&#39;&lt;/b&gt;');
  assert.equal(esc(null), '');
});
test('num uses Indian grouping', () => {
  assert.equal(num(1234567.5), '12,34,567.5');
  assert.equal(num(0), '0');
});
test('ymd / fmtDate / lastDay', () => {
  assert.equal(ymd(new Date(2026, 9, 5)), '2026-10-05');
  assert.equal(fmtDate('2026-10-05'), '05/10/2026');
  assert.equal(lastDay(2026, 2), 28);
  assert.equal(lastDay(2024, 2), 29);
});
test('isSup detects suppliers', () => {
  assert.equal(isSup({ type: 'supplier' }), true);
  assert.equal(isSup({ type: 'customer' }), false);
  assert.ok(!isSup(null));
});
test('calcAmount uses app defaults when no party', () => {
  assert.deepEqual(calcAmount(null, 2, 0, null, null), { rate: 50, amount: 100 });
});
test('rangeFor delegates to the pure core', () => {
  const r = rangeFor('month', '2026-10-16');
  assert.equal(r.start, '2026-10-01');
  assert.equal(inRange('2026-10-16', r.start, r.end), true);
});
