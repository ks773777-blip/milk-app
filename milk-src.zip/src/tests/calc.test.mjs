import test from 'node:test';
import assert from 'node:assert/strict';
import { calcAmountCore, rebuildIndexCore, partyBalanceCore, rangeForCore, inRange, isHolidayCore, monthTotals, lastDayOfMonth } from '../app/lib/calc.js';

const fmt = { ymd: d => d.toISOString().slice(0, 10), fmtDate: s => s, fmtMonth: s => 'M' + s, lastDay: lastDayOfMonth };

test('calcAmountCore: qty × rate', () => {
  assert.deepEqual(calcAmountCore({ rate: 55 }, null, 2, 0, null, 50, false), { rate: 55, amount: 110 });
});
test('calcAmountCore: manual rate wins', () => {
  assert.deepEqual(calcAmountCore({ rate: 55 }, null, 2, 0, 60, 50, false), { rate: 60, amount: 120 });
});
test('calcAmountCore: fat-based rate', () => {
  assert.deepEqual(calcAmountCore({ rate: 8, rateType: 'fat' }, null, 2, 6, null, 50, false), { rate: 48, amount: 96 });
});
test('calcAmountCore: item rate beats party rate', () => {
  const it = { rate: 40 };
  assert.deepEqual(calcAmountCore({ rate: 55 }, it, 3, 0, null, 50, false), { rate: 40, amount: 120 });
});
test('calcAmountCore: falls back to default rate', () => {
  assert.deepEqual(calcAmountCore(null, null, 1.5, 0, null, 50, false), { rate: 50, amount: 75 });
});
test('calcAmountCore: roundOff', () => {
  assert.equal(calcAmountCore({ rate: 33.33 }, null, 1, 0, null, 0, true).amount, 33);
});
test('rebuildIndexCore + partyBalanceCore', () => {
  const idx = rebuildIndexCore(
    [{ partyId: 'p1', date: '2026-10-01', kind: 'sale', qty: 2, amount: 110 },
     { partyId: 'p1', date: '2026-10-02', kind: 'sale', qty: 1, amount: 55 },
     { partyId: 'p2', date: '2026-10-01', kind: 'purchase', qty: 5, amount: 200 }],
    [{ partyId: 'p1', amount: 100 }], []);
  assert.equal(idx.party.p1.billed, 165);
  assert.equal(idx.party.p1.paid, 100);
  assert.equal(idx.date['2026-10-01'].sale, 110);
  assert.equal(partyBalanceCore({ opening: 10 }, idx.party.p1), 75);
  assert.equal(partyBalanceCore({ opening: 0 }, idx.party.p2), 200);  // purchases count as billed
});
test('rangeForCore: month', () => {
  const r = rangeForCore('month', '2026-02-15', fmt);
  assert.equal(r.start, '2026-02-01');
  assert.equal(r.end, '2026-02-28');
});
test('rangeForCore: day and year', () => {
  assert.deepEqual(rangeForCore('day', '2026-10-16', fmt).start, '2026-10-16');
  assert.deepEqual(rangeForCore('year', '2026-06-01', fmt).end, '2026-12-31');
});
test('inRange + isHolidayCore', () => {
  assert.equal(inRange('2026-10-05', '2026-10-01', '2026-10-10'), true);
  assert.equal(inRange('2026-10-11', '2026-10-01', '2026-10-10'), false);
  assert.equal(isHolidayCore([{ date: '2026-10-05', partyId: 'p1' }], '2026-10-05', 'p1'), true);
  assert.equal(isHolidayCore([{ date: '2026-10-05', partyId: '' }], '2026-10-05', 'p9'), true);
});
test('monthTotals', () => {
  const t = monthTotals(
    [{ date: '2026-10-01', kind: 'sale', qty: 2, amount: 110 }, { date: '2026-10-02', kind: 'purchase', qty: 5, amount: 200 }],
    [{ date: '2026-10-03', amount: 40 }], '2026-10');
  assert.deepEqual(t, { sale: 110, purchase: 200, expense: 40, qty: 2, profit: -130 });
});
