package com.milk.hisaab.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small helpers to build native views in code. */
public class Ui {
    public static final int GREEN = Color.parseColor("#0F7B53");
    public static final int GREEN_D = Color.parseColor("#0A5C3E");
    public static final int GREEN_L = Color.parseColor("#E7F5EE");
    public static final int INK = Color.parseColor("#16241D");
    public static final int MUTED = Color.parseColor("#5F6F67");
    public static final int LINE = Color.parseColor("#DFE6E1");
    public static final int BG = Color.parseColor("#F4F7F5");
    public static final int CARD = Color.WHITE;
    public static final int RED = Color.parseColor("#C0392B");
    public static final int AMBER = Color.parseColor("#B7791F");
    public static final int AMBER_L = Color.parseColor("#FDF3E7");
    public static final int RED_L = Color.parseColor("#FBEAE8");

    public static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    public static LinearLayout col(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
    public static LinearLayout row(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    public static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(c, radiusDp));
        return g;
    }
    public static GradientDrawable roundStroke(int color, int radiusDp, int strokeColor, Context c) {
        GradientDrawable g = round(color, radiusDp, c);
        g.setStroke(dp(c, 1), strokeColor);
        return g;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(round(CARD, 16, c));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        l.setLayoutParams(lp);
        return l;
    }

    public static TextView tv(Context c, String s, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    public static TextView title(Context c, String s) { return tv(c, s, 16f, INK, true); }
    public static TextView label(Context c, String s) { return tv(c, s, 13f, MUTED, false); }
    public static TextView big(Context c, String s) { return tv(c, s, 20f, INK, true); }

    public static Button btn(Context c, String s) {
        Button b = new Button(c);
        b.setText(s); b.setAllCaps(false); b.setTextSize(14f); b.setTextColor(Color.WHITE);
        b.setBackground(round(GREEN, 12, c));
        b.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        return b;
    }
    public static Button btnGrey(Context c, String s) {
        Button b = btn(c, s); b.setTextColor(GREEN_D); b.setBackground(round(GREEN_L, 12, c)); return b;
    }

    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint); e.setTextSize(15f);
        e.setBackground(roundStroke(Color.WHITE, 12, LINE, c));
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 8);
        e.setLayoutParams(lp);
        return e;
    }

    public static View divider(Context c) {
        View v = new View(c); v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1));
        lp.topMargin = dp(c, 8); lp.bottomMargin = dp(c, 8);
        v.setLayoutParams(lp);
        return v;
    }

    public static LinearLayout.LayoutParams lp(Context c) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    public static LinearLayout.LayoutParams lpGap(Context c, int bottomDp) {
        LinearLayout.LayoutParams lp = lp(c); lp.bottomMargin = dp(c, bottomDp); return lp;
    }
    public static void weight(View v, float w) {
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
        if (lp == null) lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.width = 0; lp.weight = w; v.setLayoutParams(lp);
    }

    /** One label/value line used across cards. */
    public static LinearLayout line(Context c, String k, String v, boolean total, Integer valueColor) {
        LinearLayout r = row(c);
        r.setPadding(0, dp(c, 5), 0, dp(c, 5));
        TextView a = tv(c, k, total ? 15f : 14f, total ? INK : MUTED, total);
        Ui.weight(a, 1f);
        TextView b = tv(c, v, total ? 16f : 14f, valueColor == null ? (total ? INK : INK) : valueColor, total);
        r.addView(a); r.addView(b);
        return r;
    }

    public static LinearLayout listRow(Context c) {
        LinearLayout r = row(c);
        r.setBackground(round(CARD, 14, c));
        int p = dp(c, 12);
        r.setPadding(p, p, p, p);
        r.setLayoutParams(lpGap(c, 8));
        return r;
    }
}
