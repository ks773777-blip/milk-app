package com.milk.hisaab.app;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Util {
    public static final String[] MONTHS_HI = {"जनवरी","फ़रवरी","मार्च","अप्रैल","मई","जून","जुलाई","अगस्त","सितंबर","अक्टूबर","नवंबर","दिसंबर"};
    public static final String[] MONTHS_SHORT_HI = {"जन","फ़र","मार","अप्र","मई","जून","जुल","अग","सित","अक्त","नव","दिस"};

    public static String today() { return ymd(new Date()); }
    public static String ymd(Date d) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d); }
    public static String month() { return new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()); }

    public static String monthLabel(String m) {
        try { int mm = Integer.parseInt(m.substring(5, 7)); return MONTHS_HI[mm - 1] + " " + m.substring(0, 4); }
        catch (Exception e) { return m; }
    }

    public static String niceDate(String ymd) {
        try {
            int mo = Integer.parseInt(ymd.substring(5, 7)), d = Integer.parseInt(ymd.substring(8, 10));
            return d + " " + MONTHS_SHORT_HI[mo - 1];
        } catch (Exception e) { return ymd; }
    }

    /** Indian grouping: 1,23,456 */
    public static String money(double v) {
        long n = Math.round(v);
        String s = String.valueOf(Math.abs(n));
        String out;
        if (s.length() <= 3) out = s;
        else {
            String last3 = s.substring(s.length() - 3);
            String rest = s.substring(0, s.length() - 3);
            StringBuilder sb = new StringBuilder();
            int c = 0;
            for (int i = rest.length() - 1; i >= 0; i--) {
                sb.append(rest.charAt(i)); c++;
                if (c == 2 && i > 0) { sb.append(','); c = 0; }
            }
            out = sb.reverse().toString() + "," + last3;
        }
        return "₹" + (n < 0 ? "-" : "") + out;
    }

    public static String num(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.valueOf(Math.round(v * 100) / 100.0);
    }

    public static String autoShift() { return Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 12 ? "morning" : "evening"; }
    public static String shiftHi(String s) { return "evening".equals(s) ? "शाम" : "सुबह"; }

    public static String addDays(String ymd, int d) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Calendar c = Calendar.getInstance(); c.setTime(f.parse(ymd)); c.add(Calendar.DAY_OF_MONTH, d);
            return f.format(c.getTime());
        } catch (Exception e) { return ymd; }
    }

    public static String monthOf(String ymd) { return ymd != null && ymd.length() >= 7 ? ymd.substring(0, 7) : month(); }

    public static String firstOfMonth(String m) { return m + "-01"; }
    public static String lastOfMonth(String m) {
        try {
            int y = Integer.parseInt(m.substring(0, 4)), mo = Integer.parseInt(m.substring(5, 7));
            Calendar c = Calendar.getInstance(); c.set(y, mo - 1, 1);
            return m + "-" + String.format(Locale.US, "%02d", c.getActualMaximum(Calendar.DAY_OF_MONTH));
        } catch (Exception e) { return m + "-28"; }
    }
}
