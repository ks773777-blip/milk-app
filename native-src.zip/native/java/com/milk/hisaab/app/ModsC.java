package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Modules: farm + app & settings. */
public class ModsC {

    public static boolean render(final Activity a, final LinearLayout box, final String id) {
        final Db db = Db.get(a);
        final String m = Util.month(), today = Util.today();

        if (id.equals("animals")) {
            final EditText nm = ModsA.et(a, "पशु का नाम / नंबर", "");
            final EditText tag = ModsA.et(a, "टैग / पहचान", "");
            final EditText nt = ModsA.et(a, "नोट (नस्ल, दूध…) ", "");
            LinearLayout v = ModsA.form(a);
            v.addView(nm); v.addView(tag); v.addView(nt);
            Button add = Ui.btn(a, "पशु जोड़ें");
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (ModsA.str(nm).isEmpty()) { ((MainActivity) a).toast("नाम डालें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("name", ModsA.str(nm)); cv.put("tag", ModsA.str(tag));
                    cv.put("note", ModsA.str(nt)); cv.put("active", 1);
                    db.insert("animals", cv);
                    ((MainActivity) a).openModule("animals");
                }
            });
            box.addView(v);
            box.addView(ModsA.rowBtn(a, add));
            box.addView(Scr.table(a, "🐄 पशु रजिस्टर", db.rows(
                    "SELECT (name || CASE WHEN IFNULL(tag,'')='' THEN '' ELSE ' · ' || tag END), IFNULL(note,'') FROM animals WHERE active=1 ORDER BY id", null),
                    "कोई पशु दर्ज नहीं"));
            return true;
        }
        if (id.equals("wastage")) {
            LinearLayout v = ModsA.form(a);
            final EditText q = ModsA.et(a, "कितना दूध (लीटर)", "");
            final EditText rt = ModsA.et(a, "रेट प्रति लीटर", Util.num(db.getNum("defaultRate", 50)));
            final EditText rs = ModsA.et(a, "कारण (गिर गया, खट्टा…)", "");
            v.addView(q); v.addView(rt); v.addView(rs);
            Button add = Ui.btn(a, "वेस्टेज जोड़ें");
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    double qq = ModsA.num(q), rr = ModsA.num(rt);
                    if (qq <= 0) { ((MainActivity) a).toast("मात्रा डालें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("date", Util.today()); cv.put("qty", qq); cv.put("rate", rr);
                    cv.put("value", Math.round(qq * rr)); cv.put("reason", ModsA.str(rs));
                    db.insert("wastage", cv);
                    ((MainActivity) a).openModule("wastage");
                }
            });
            box.addView(v);
            box.addView(ModsA.rowBtn(a, add));
            box.addView(Scr.report(a, "📉 " + Util.monthLabel(m) + " — नुकसान",
                    new String[]{"कुल वेस्टेज", "बिक्री का %"},
                    new String[]{Util.money(db.wastageMonth(m)),
                            (db.saleMonth(m) > 0 ? String.valueOf(Math.round(db.wastageMonth(m) / db.saleMonth(m) * 100)) : "0") + "%"},
                    Ui.AMBER));
            box.addView(Scr.table(a, "वेस्टेज की एंट्री", db.rows(
                    "SELECT (date || ' · ' || IFNULL(reason,'')), (qty || ' L · ₹' || value) FROM wastage WHERE date LIKE ? ORDER BY date DESC",
                    new String[]{m + "%"}), "इस महीने कुछ नहीं"));
            return true;
        }
        if (id.equals("insights")) {
            LinearLayout c = Scr.card(a, "🔎 स्मार्ट इनसाइट्स");
            double sale = db.saleMonth(m), net = db.netMonth(m);
            if (sale > 0) {
                int mg = (int) Math.round(net / sale * 100);
                c.addView(alert(a, "💰 मुनाफ़ा दर", mg + "% — " + (mg < 12 ? "थोड़ा कम है, खर्च या रेट देखें" : "ठीक है"), mg >= 12));
            }
            double due = db.totalDue();
            if (due > 500) c.addView(alert(a, "⏳ बकाया वसूली", Util.money(due) + " वसूलना है", false));
            double w = db.wastageMonth(m);
            if (w > 0 && sale > 0) c.addView(alert(a, "📉 वेस्टेज", Util.money(w) + " (" + Math.round(w / sale * 100) + "%)", w / sale <= 0.03));
            Calendar cc = Calendar.getInstance();
            cc.add(Calendar.MONTH, -1);
            String pm = String.format(java.util.Locale.US, "%04d-%02d", cc.get(Calendar.YEAR), cc.get(Calendar.MONTH) + 1);
            double ps = db.saleMonth(pm);
            if (ps > 0) {
                int d = (int) Math.round((sale - ps) / ps * 100);
                c.addView(alert(a, "📈 बिक्री", (d >= 0 ? "+" : "") + d + "% पिछले महीने से", d >= 0));
            }
            Calendar c7 = Calendar.getInstance();
            c7.add(Calendar.DAY_OF_MONTH, -7);
            double inact = db.one("SELECT COUNT(*) FROM parties p WHERE p.type='customer' AND p.active=1 AND IFNULL((SELECT MAX(e.date) FROM entries e WHERE e.party_id=p.id),'') < ?",
                    new String[]{Util.ymd(c7.getTime())});
            if (inact > 0) c.addView(alert(a, "😴 निष्क्रिय ग्राहक", ((int) inact) + " ग्राहक 7 दिन से नहीं आए", false));
            double low = db.one("SELECT COUNT(*) FROM items WHERE stock<=low_at", null);
            if (low > 0) c.addView(alert(a, "📦 स्टॉक", ((int) low) + " सामान कम है", false));
            if (c.getChildCount() == 1) c.addView(Ui.label(a, "अभी कोई खास बात नहीं — डेटा बढ़ने पर यहाँ सलाह दिखेगी।"));
            box.addView(c);
            return true;
        }
        if (id.equals("ai")) { aiCard(a, box, db); return true; }
        if (id.equals("settings")) { new TabMore().build(a, box); return true; }
        if (id.equals("backup")) {
            box.addView(Scr.note(a, "पूरा डेटा एक JSON फ़ाइल में सेव होगा — Downloads फ़ोल्डर में। इसे कहीं सुरक्षित रख लें।"));
            Button b = Ui.btn(a, "बैकअप सेव करें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String where = Io.saveToDownloads(a, "milk-backup-" + today + ".json", "application/json", db.dumpJson().getBytes());
                    ((MainActivity) a).toast(where == null ? "सेव नहीं हो सका" : "सेव: " + where);
                }
            });
            box.addView(ModsA.rowBtn(a, b));
            box.addView(Scr.table(a, "क्या-क्या सेव होगा", db.rows(
                    "SELECT 'ग्राहक / किसान', COUNT(*) FROM parties UNION ALL SELECT 'एंट्री', COUNT(*) FROM entries "
                            + "UNION ALL SELECT 'भुगतान', COUNT(*) FROM payments UNION ALL SELECT 'खर्च', COUNT(*) FROM expenses", null), "—"));
            return true;
        }
        if (id.equals("perms")) {
            box.addView(Scr.note(a, "यह ऐप कैमरा, फ़ाइल, फ़ोन (कॉल) जैसी अनुमतियाँ माँग सकता है। नीचे से सीधे ऐप की सेटिंग खोलकर अनुमति दे/हटा सकते हैं।"));
            Button b = Ui.btn(a, "ऐप की अनुमतियाँ खोलें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    try {
                        Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName()));
                        a.startActivity(i);
                    } catch (Exception e) { ((MainActivity) a).toast("सेटिंग नहीं खुली"); }
                }
            });
            box.addView(ModsA.rowBtn(a, b));
            box.addView(Scr.table(a, "इस ऐप की अनुमतियाँ", db.rows("SELECT 'फ़ोन (कॉल)', 'अनुमति दें' UNION ALL SELECT 'फ़ाइल / Downloads', 'अनुमति दें'", null), "—"));
            return true;
        }
        if (id.equals("datacheck")) {
            box.addView(Scr.table(a, "🩺 डेटा जाँच", db.rows(
                    "SELECT 'ग्राहक', COUNT(*) FROM parties WHERE type='customer' UNION ALL SELECT 'किसान', COUNT(*) FROM parties WHERE type='supplier' "
                            + "UNION ALL SELECT 'एंट्री', COUNT(*) FROM entries UNION ALL SELECT 'भुगतान', COUNT(*) FROM payments "
                            + "UNION ALL SELECT 'खर्च', COUNT(*) FROM expenses UNION ALL SELECT 'वेस्टेज', COUNT(*) FROM wastage "
                            + "UNION ALL SELECT 'इनवॉइस', COUNT(*) FROM invoices UNION ALL SELECT 'स्टाफ', COUNT(*) FROM staff "
                            + "UNION ALL SELECT 'पशु', COUNT(*) FROM animals UNION ALL SELECT 'नोट्स', COUNT(*) FROM notes", null), "—"));
            box.addView(Scr.note(a, "यहाँ सब ठीक दिख रहा है तो डेटा सुरक्षित है। नियमित बैकअप लेते रहें।"));
            return true;
        }
        if (id.equals("support")) {
            box.addView(Scr.note(a, "आम सवाल नीचे दिए हैं। कोई और दिक्कत हो तो दुकान के मालिक से संपर्क करें।"));
            String[][] faq = {
                    {"एंट्री कैसे जोड़ें?", "नीचे 'एंट्री' टैब खोलें → ➕ नई एंट्री → ग्राहक चुनें, मात्रा डालें, सेव। समय अपने आप सुबह/शाम चुना जाता है।"},
                    {"बल्क एंट्री क्या है?", "मॉड्यूल → 🧺 बल्क एंट्री — एक टैप में हर ग्राहक की डिफ़ॉल्ट मात्रा भर जाती है।"},
                    {"बकाया कहाँ देखें?", "मॉड्यूल → ⏳ बकाया, या होम स्क्रीन पर कुल बकाया।"},
                    {"PDF बिल कैसे बनाएँ?", "मॉड्यूल → 📄 स्टेटमेंट → ग्राहक चुनें → 📄 PDF बिल बनाएँ (Downloads में सेव होगा)।"},
                    {"डेटा सुरक्षित है?", "हाँ — सारा डेटा आपके फ़ोन की SQLite में रहता है। नियमित बैकअप लेते रहें।"}
            };
            for (String[] f : faq) {
                LinearLayout c = Scr.card(a, "❓ " + f[0]);
                c.addView(Ui.label(a, f[1]));
                box.addView(c);
            }
            return true;
        }
        if (id.equals("legal")) {
            LinearLayout c1 = Scr.card(a, "🔒 प्राइवेसी पॉलिसी");
            c1.addView(Ui.label(a, "सारा डेटा आपके ही फ़ोन में रहता है — किसी सर्वर पर नहीं जाता।\n"
                    + "AI सहायक इस्तेमाल करने पर ही आपकी दुकान का सारांश (बिक्री, मुनाफ़ा, बकाया) उस सेवा को भेजा जाता है — और वह भी आपकी key से।\n"
                    + "कोई विज्ञापन नहीं, डेटा किसी को नहीं बेचा जाता।\n"
                    + "'सारा डेटा मिटाएँ' दबाने पर डेटा हमेशा के लिए हट जाता है।"));
            box.addView(c1);
            LinearLayout c2 = Scr.card(a, "📜 नियम व शर्तें");
            c2.addView(Ui.label(a, "यह ऐप आपके अपने धंधे के हिसाब के लिए है।\n"
                    + "बैकअप नियमित लेते रहें।\n"
                    + "ऐप 'जैसा है' (as-is) दिया गया है — रकम, बिल और रिपोर्ट अपनी जाँच के बाद भरोसे लायक मानें।"));
            box.addView(c2);
            return true;
        }
        if (id.equals("help")) {
            box.addView(Scr.note(a, "दूध हिसाब (Native) — पूरी तरह native Android ऐप, तेज़ और हल्का।\n\n"
                    + "• नीचे 5 टैब: होम, एंट्री, ग्राहक, रिपोर्ट, और (मॉड्यूल)।\n"
                    + "• 'और' टैब में सभी मॉड्यूल 6 फ़ोल्डर में बँटे हैं।\n"
                    + "• मोबाइल का बैक बटन किसी भी स्क्रीन से होम पर ले आता है।\n"
                    + "• किसी एंट्री या ग्राहक पर देर तक दबाने से हटाने का विकल्प मिलता है।"));
            return true;
        }
        return false;
    }

    private static LinearLayout alert(Activity a, String head, String text, boolean good) {
        LinearLayout r = Ui.row(a);
        r.setBackground(Ui.round(good ? Ui.GREEN_L : Ui.AMBER_L, 12, a));
        r.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10));
        r.setLayoutParams(Ui.lpGap(a, 8));
        r.addView(Ui.tv(a, head, 13.5f, good ? Ui.GREEN_D : Ui.AMBER, true));
        TextView t = Ui.tv(a, "  " + text, 13f, Ui.INK, false);
        Ui.weight(t, 1f);
        r.addView(t);
        return r;
    }

    private static void aiCard(final Activity a, LinearLayout box, final Db db) {
        LinearLayout c = Scr.card(a, "🤖 AI सहायक");
        c.addView(Ui.label(a, "अपने दूध-व्यापार के बारे में सवाल पूछें — जवाब आपके असली डेटा के हिसाब से मिलेगा। (इंटरनेट चाहिए)"));
        final LinearLayout chat = Ui.col(a);
        c.addView(chat);
        final EditText q = Ui.input(a, "सवाल लिखें…");
        c.addView(q);
        LinearLayout row = Ui.row(a);
        Button ask = Ui.btn(a, "पूछें");
        ask.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        ask.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { askAI(a, db, chat, q.getText().toString().trim()); q.setText(""); }
        });
        row.addView(ask);
        Button q1 = Ui.btnGrey(a, "इस महीने का हिसाब");
        q1.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        q1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { askAI(a, db, chat, "इस महीने का हिसाब बताओ"); }
        });
        row.addView(q1);
        c.addView(row);
        if (db.get("aiKey", "").isEmpty()) c.addView(Ui.label(a, "⚠️ पहले मॉड्यूल → ⚙️ सेटिंग में AI key डालें।"));
        box.addView(c);
    }

    private static void askAI(final Activity a, final Db db, final LinearLayout chat, final String question) {
        if (question == null || question.isEmpty()) return;
        chat.addView(Ui.tv(a, "🙋 " + question, 14f, Ui.GREEN_D, true));
        final TextView ans = Ui.tv(a, "…", 14f, Ui.INK, false);
        chat.addView(ans);
        final String key = db.get("aiKey", "");
        if (key.isEmpty()) { ans.setText("पहले मॉड्यूल → ⚙️ सेटिंग में AI key डालें।"); return; }
        new Thread(new Runnable() {
            public void run() {
                final String out = Gemini.ask(key, context(db), question);
                a.runOnUiThread(new Runnable() { public void run() { ans.setText(out); } });
            }
        }).start();
    }

    private static String context(Db db) {
        String m = Util.month(), t = Util.today();
        List<String[]> dues = db.dueList();
        StringBuilder sb = new StringBuilder();
        sb.append("दुकान: ").append(db.get("shopName", "दूध हिसाब"));
        sb.append("\nआज (").append(t).append("): ").append(Util.num(db.qtyOn(t, "morning") + db.qtyOn(t, "evening")))
                .append(" लीटर, ").append(Util.money(db.saleOn(t)));
        sb.append("\nइस महीने: बिक्री ").append(Util.money(db.saleMonth(m)))
                .append(", खरीद ").append(Util.money(db.purchaseMonth(m)))
                .append(", खर्च ").append(Util.money(db.expenseMonth(m)))
                .append(", मुनाफ़ा ").append(Util.money(db.netMonth(m)));
        sb.append("\nग्राहक: ").append(db.parties("customer").size());
        sb.append("\nसबसे ज़्यादा बकाया: ");
        int n = 0;
        for (String[] d : dues) {
            if (n++ >= 5) break;
            sb.append(d[0]).append(" ").append(Util.money(Double.parseDouble(d[1]))).append(" | ");
        }
        if (n == 0) sb.append("कोई नहीं");
        return sb.toString();
    }
}
