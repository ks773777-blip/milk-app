package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

/** Customers / suppliers tab. */
public class TabParties {

    public void build(final Activity a, LinearLayout box) {
        final Db db = Db.get(a);

        LinearLayout head = Ui.card(a);
        Button add = Ui.btn(a, "➕ नया ग्राहक / किसान");
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { edit(a, db, null); } });
        head.addView(add);
        box.addView(head);

        List<Db.Party> cs = db.parties("customer");
        List<Db.Party> sp = db.parties("supplier");

        box.addView(Ui.tv(a, "👥 ग्राहक (" + cs.size() + ")", 15f, Ui.INK, true));
        if (cs.isEmpty()) box.addView(Ui.label(a, "अभी कोई ग्राहक नहीं"));
        for (final Db.Party p : cs) box.addView(row(a, db, p));

        box.addView(Ui.tv(a, "🧺 किसान / सप्लायर (" + sp.size() + ")", 15f, Ui.INK, true));
        if (sp.isEmpty()) box.addView(Ui.label(a, "अभी कोई किसान नहीं"));
        for (final Db.Party p : sp) box.addView(row(a, db, p));
    }

    private LinearLayout row(final Activity a, final Db db, final Db.Party p) {
        LinearLayout r = Ui.listRow(a);
        LinearLayout col = Ui.col(a);
        Ui.weight(col, 1f);
        col.addView(Ui.tv(a, p.name, 15f, Ui.INK, true));
        StringBuilder s = new StringBuilder();
        if (!p.phone.isEmpty()) s.append(p.phone);
        if (!p.route.isEmpty()) s.append(s.length() > 0 ? " · " : "").append(p.route);
        col.addView(Ui.label(a, s.length() > 0 ? s.toString() : "—"));
        r.addView(col);
        double bal = db.balance(p.id);
        r.addView(Ui.tv(a, Util.money(bal), 15f, bal > 0 ? Ui.RED : Ui.GREEN, true));
        if (!p.phone.isEmpty()) {
            Button call = Ui.btnGrey(a, "📞");
            call.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 52), Ui.dp(a, 40)));
            call.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    try { a.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + p.phone))); } catch (Exception e) { }
                }
            });
            r.addView(call);
        }
        r.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { edit(a, db, p); } });
        r.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(a).setMessage(p.name + " को हटाएँ? उसकी सारी एंट्री भी हट जाएँगी।")
                        .setPositiveButton("हटाएँ", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { db.deleteParty(p.id); ((MainActivity) a).go(2); }
                        }).setNegativeButton("नहीं", null).show();
                return true;
            }
        });
        return r;
    }

    private void edit(final Activity a, final Db db, final Db.Party old) {
        LinearLayout v = Ui.col(a);
        int pd = Ui.dp(a, 16);
        v.setPadding(pd, pd, pd, pd);
        final EditText name = Ui.input(a, "नाम");
        final EditText phone = Ui.input(a, "मोबाइल नंबर");
        final EditText route = Ui.input(a, "रूट / गली (जैसे: वार्ड 1)");
        final EditText rate = Ui.input(a, "रेट प्रति लीटर");
        final EditText dq = Ui.input(a, "रोज़ की डिफ़ॉल्ट मात्रा (लीटर)");
        final EditText open = Ui.input(a, "पुराना बकाया (शुरुआत में)");
        v.addView(Ui.label(a, "प्रकार"));
        final Spinner type = new Spinner(a);
        type.setAdapter(new ArrayAdapter<String>(a, android.R.layout.simple_spinner_dropdown_item, new String[]{"ग्राहक (जिसे दूध देते हैं)", "किसान (जिससे दूध लेते हैं)"}));
        v.addView(type);
        v.addView(name); v.addView(phone); v.addView(route); v.addView(rate); v.addView(dq); v.addView(open);
        if (old != null) {
            name.setText(old.name); phone.setText(old.phone); route.setText(old.route);
            rate.setText(old.rate > 0 ? Util.num(old.rate) : "");
            dq.setText(old.defaultQty > 0 ? Util.num(old.defaultQty) : "");
            open.setText(old.opening != 0 ? Util.num(old.opening) : "");
            type.setSelection("supplier".equals(old.type) ? 1 : 0);
        }
        new AlertDialog.Builder(a)
                .setTitle(old == null ? "नया ग्राहक" : "बदलाव करें")
                .setView(v)
                .setPositiveButton("सेव", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String nm = name.getText().toString().trim();
                        if (nm.isEmpty()) { ((MainActivity) a).toast("नाम डालें"); return; }
                        Db.Party p = old == null ? new Db.Party() : old;
                        p.name = nm;
                        p.phone = phone.getText().toString().trim();
                        p.route = route.getText().toString().trim();
                        p.rate = TabEntries.parse(rate.getText().toString());
                        p.defaultQty = TabEntries.parse(dq.getText().toString());
                        p.opening = TabEntries.parse(open.getText().toString());
                        p.type = type.getSelectedItemPosition() == 1 ? "supplier" : "customer";
                        db.saveParty(p);
                        ((MainActivity) a).toast("सेव हो गया ✓");
                        ((MainActivity) a).go(2);
                    }
                })
                .setNegativeButton("रद्द", null).show();
    }
}
