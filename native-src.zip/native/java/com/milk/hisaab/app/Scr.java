package com.milk.hisaab.app;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Reusable native screen pieces: report cards, tables, tiles, charts. */
public class Scr {

    public static LinearLayout card(Activity a, String title) {
        LinearLayout c = Ui.card(a);
        if (title != null && title.length() > 0) c.addView(Ui.tv(a, title, 15f, Ui.INK, true));
        return c;
    }

    public static LinearLayout report(Activity a, String title, String[] keys, String[] vals, Integer lastColor) {
        LinearLayout c = card(a, title);
        for (int i = 0; i < keys.length; i++) {
            boolean last = (i == keys.length - 1);
            c.addView(Ui.line(a, keys[i], vals[i], last, last ? lastColor : null));
        }
        return c;
    }

    public static LinearLayout table(Activity a, String title, List<String[]> rows, String emptyText) {
        LinearLayout c = card(a, title);
        if (rows == null || rows.isEmpty()) { c.addView(Ui.label(a, emptyText)); return c; }
        for (String[] r : rows) {
            LinearLayout row = Ui.row(a);
            row.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
            for (int i = 0; i < r.length; i++) {
                if (i == 0) {
                    TextView t = Ui.tv(a, r[i], 14f, Ui.INK, true);
                    Ui.weight(t, 1f);
                    row.addView(t);
                } else {
                    TextView t = Ui.tv(a, r[i], 13.5f, Ui.MUTED, false);
                    t.setGravity(android.view.Gravity.END);
                    row.addView(t);
                }
            }
            c.addView(row);
        }
        return c;
    }

    public static LinearLayout item(Activity a, String main, String sub, String right, int rightColor, View.OnClickListener onClick) {
        LinearLayout row = Ui.listRow(a);
        LinearLayout col = Ui.col(a);
        Ui.weight(col, 1f);
        col.addView(Ui.tv(a, main, 15f, Ui.INK, true));
        if (sub != null && sub.length() > 0) col.addView(Ui.label(a, sub));
        row.addView(col);
        if (right != null && right.length() > 0) row.addView(Ui.tv(a, right, 15f, rightColor, true));
        if (onClick != null) row.setOnClickListener(onClick);
        return row;
    }

    public static LinearLayout tiles(Activity a, List<Modules.Mod> list) {
        LinearLayout wrap = Ui.col(a);
        LinearLayout row = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % 3 == 0) { row = Ui.row(a); wrap.addView(row); }
            final Modules.Mod m = list.get(i);
            LinearLayout t = Ui.col(a);
            t.setBackground(Ui.round(Ui.CARD, 14, a));
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(Ui.dp(a, 6), Ui.dp(a, 12), Ui.dp(a, 6), Ui.dp(a, 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3));
            t.setLayoutParams(lp);
            t.addView(Ui.tv(a, m.icon, 22f, Ui.INK, false));
            TextView lbl = Ui.tv(a, m.name, 11.5f, Ui.INK, true);
            lbl.setGravity(android.view.Gravity.CENTER);
            t.addView(lbl);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { ((MainActivity) a).openModule(m.id); }
            });
            row.addView(t);
        }
        return wrap;
    }

    public static LinearLayout chartCard(Activity a, String title, List<String[]> data) {
        LinearLayout c = card(a, title);
        Chart ch = new Chart(a, data);
        ch.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(a, 180)));
        c.addView(ch);
        return c;
    }

    public static LinearLayout note(Activity a, String s) {
        LinearLayout c = Ui.card(a);
        c.addView(Ui.label(a, s));
        return c;
    }

    public static class Chart extends View {
        private final List<String[]> data;
        public Chart(android.content.Context c, List<String[]> d) { super(c); this.data = d; }
        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            cv.drawColor(Color.WHITE);
            if (data == null || data.isEmpty()) return;
            double max = 1;
            for (String[] d : data) { try { double v = Double.parseDouble(d[1]); if (v > max) max = v; } catch (Exception e) { } }
            int pad = Ui.dp(getContext(), 26), base = h - Ui.dp(getContext(), 24), top = Ui.dp(getContext(), 12);
            float slot = (w - pad * 2f) / data.size(), bw = slot * 0.52f;
            Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG); bar.setColor(Ui.GREEN);
            Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG); txt.setColor(Ui.MUTED);
            txt.setTextSize(Ui.dp(getContext(), 11)); txt.setTextAlign(Paint.Align.CENTER);
            Paint axis = new Paint(); axis.setColor(Ui.LINE);
            cv.drawRect(pad, base, w - pad, base + 1, axis);
            for (int i = 0; i < data.size(); i++) {
                double v = 0;
                try { v = Double.parseDouble(data.get(i)[1]); } catch (Exception e) { }
                int bh = (int) ((base - top) * (max <= 0 ? 0 : v / max));
                float x = pad + i * slot + (slot - bw) / 2f;
                cv.drawRoundRect(x, base - bh, x + bw, base, 6, 6, bar);
                cv.drawText(data.get(i)[0], x + bw / 2f, base + Ui.dp(getContext(), 16), txt);
            }
        }
    }
}
