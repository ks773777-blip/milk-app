package com.milk.hisaab.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

/** Native Milk Hisaab — bottom-nav shell + module hub. */
public class MainActivity extends Activity {

    private LinearLayout content;
    private ScrollView scroll;
    private final TextView[] navBtn = new TextView[5];
    private static final String[] TITLES = {"होम", "एंट्री", "ग्राहक", "रिपोर्ट", "मॉड्यूल"};
    private static final String[] ICONS = {"🏠", "🥛", "👥", "📊", "📁"};
    private int tab = 0;
    private String curModule = null;
    private final Handler h = new Handler();
    private TextView clock;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.col(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout head = Ui.row(this);
        head.setBackgroundColor(Ui.GREEN);
        head.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16));
        TextView t = Ui.tv(this, "🥛 दूध हिसाब", 19f, Color.WHITE, true);
        Ui.weight(t, 1f);
        head.addView(t);
        clock = Ui.tv(this, "", 13f, Color.WHITE, true);
        head.addView(clock);
        root.addView(head);

        scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        content = Ui.col(this);
        int cp = Ui.dp(this, 12);
        content.setPadding(cp, cp, cp, Ui.dp(this, 24));
        scroll.addView(content);
        root.addView(scroll);

        LinearLayout nav = Ui.row(this);
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 6));
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            TextView nb = Ui.tv(this, ICONS[i] + "\n" + TITLES[i], 11f, Ui.MUTED, false);
            nb.setGravity(Gravity.CENTER);
            nb.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            nb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            nb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { go(idx); } });
            navBtn[i] = nb;
            nav.addView(nb);
        }
        root.addView(nav);
        setContentView(root);

        go(0);
        h.post(tick);
    }

    private final Runnable tick = new Runnable() {
        public void run() {
            Calendar c = Calendar.getInstance();
            clock.setText(String.format(Locale.US, "%02d:%02d:%02d",
                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND)));
            h.postDelayed(this, 1000);
        }
    };

    private void mark(int idx) {
        for (int i = 0; i < 5; i++) {
            navBtn[i].setTextColor(i == idx ? Ui.GREEN : Ui.MUTED);
            navBtn[i].setTypeface(null, i == idx ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    public void go(int idx) {
        tab = idx;
        curModule = null;
        mark(idx);
        content.removeAllViews();
        if (idx == 0) new TabHome().build(this, content);
        else if (idx == 1) new TabEntries().build(this, content);
        else if (idx == 2) new TabParties().build(this, content);
        else if (idx == 3) new TabReports().build(this, content);
        else renderHub();
        scroll.scrollTo(0, 0);
    }

    /** Module hub: every module grouped into folders. */
    private void renderHub() {
        LinearLayout intro = Scr.card(this, "📁 सभी मॉड्यूल (" + Modules.ALL.size() + ")");
        intro.addView(Ui.label(this, "फ़ोल्डर के हिसाब से सारे मॉड्यूल नीचे हैं — किसी पर भी टैप करें।"));
        content.addView(intro);
        for (int g = 0; g < Modules.GROUP_NAMES.length; g++) {
            TextView head = Ui.tv(this, Modules.GROUP_ICONS[g] + "  " + Modules.GROUP_NAMES[g], 14f, Ui.GREEN_D, true);
            head.setLayoutParams(Ui.lpGap(this, 6));
            content.addView(head);
            content.addView(Scr.tiles(this, Modules.group(g)));
        }
    }

    /** Opens one module inside the content area. */
    public void openModule(String id) {
        Modules.Mod m = Modules.find(id);
        if (m == null) return;
        curModule = id;
        mark(4);
        tab = 4;
        content.removeAllViews();
        LinearLayout bar = Ui.row(this);
        Button back = Ui.btnGrey(this, "← वापस");
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { go(4); }
        });
        bar.addView(back);
        TextView ttl = Ui.tv(this, m.icon + " " + m.name, 16f, Ui.INK, true);
        ttl.setPadding(Ui.dp(this, 12), 0, 0, 0);
        bar.addView(ttl);
        bar.setLayoutParams(Ui.lpGap(this, 10));
        content.addView(bar);
        Modules.render(this, content, id);
        scroll.scrollTo(0, 0);
    }

    public void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            if (curModule != null) { go(4); return true; }
            if (tab != 0) { go(0); return true; }
        }
        return super.onKeyDown(code, e);
    }

    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
