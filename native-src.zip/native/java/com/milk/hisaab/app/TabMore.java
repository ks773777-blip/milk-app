package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

/** Settings / backup / about tab. */
public class TabMore {

    public void build(final Activity a, LinearLayout box) {
        final Db db = Db.get(a);

        LinearLayout c1 = Ui.card(a);
        c1.addView(Ui.tv(a, "⚙️ दुकान की जानकारी", 15f, Ui.INK, true));
        final EditText name = Ui.input(a, "दुकान का नाम");
        final EditText owner = Ui.input(a, "मालिक का नाम");
        final EditText phone = Ui.input(a, "फ़ोन");
        final EditText addr = Ui.input(a, "पता");
        final EditText rate = Ui.input(a, "डिफ़ॉल्ट रेट प्रति लीटर");
        name.setText(db.get("shopName", "दूध हिसाब"));
        owner.setText(db.get("owner", ""));
        phone.setText(db.get("bizPhone", ""));
        addr.setText(db.get("address", ""));
        rate.setText(Util.num(db.getNum("defaultRate", 50)));
        c1.addView(name); c1.addView(owner); c1.addView(phone); c1.addView(addr); c1.addView(rate);
        Button save = Ui.btn(a, "सेव करें");
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db.set("shopName", name.getText().toString().trim());
                db.set("owner", owner.getText().toString().trim());
                db.set("bizPhone", phone.getText().toString().trim());
                db.set("address", addr.getText().toString().trim());
                db.set("defaultRate", String.valueOf(TabEntries.parse(rate.getText().toString())));
                ((MainActivity) a).toast("सेव हो गया ✓");
            }
        });
        c1.addView(save);
        box.addView(c1);

        LinearLayout c2 = Ui.card(a);
        c2.addView(Ui.tv(a, "🤖 AI सहायक की key", 15f, Ui.INK, true));
        c2.addView(Ui.label(a, "key सिर्फ़ इस फ़ोन में सेव होती है — ऐप की फ़ाइल या GitHub में कभी नहीं जाती।"));
        final EditText key = Ui.input(a, "AI API key");
        key.setText(db.get("aiKey", ""));
        c2.addView(key);
        LinearLayout kr = Ui.row(a);
        Button ks = Ui.btnGrey(a, "सेव");
        ks.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ks.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { db.set("aiKey", key.getText().toString().trim()); ((MainActivity) a).toast("AI key सेव ✓"); }
        });
        kr.addView(ks);
        Button kc = Ui.btnGrey(a, "हटाएँ");
        kc.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        kc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { db.set("aiKey", ""); key.setText(""); ((MainActivity) a).toast("AI key हटा दी"); }
        });
        kr.addView(kc);
        c2.addView(kr);
        box.addView(c2);

        LinearLayout c3 = Ui.card(a);
        c3.addView(Ui.tv(a, "💾 बैकअप", 15f, Ui.INK, true));
        c3.addView(Ui.label(a, "पूरा डेटा एक JSON फ़ाइल में सेव करें (Downloads फ़ोल्डर में)।"));
        Button bk = Ui.btn(a, "बैकअप सेव करें");
        bk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String json = db.dumpJson();
                String where = Io.saveToDownloads(a, "milk-backup-" + Util.today() + ".json", "application/json", json.getBytes());
                ((MainActivity) a).toast(where == null ? "सेव नहीं हो सका" : "सेव: " + where);
            }
        });
        c3.addView(bk);
        box.addView(c3);

        LinearLayout c4 = Ui.card(a);
        c4.addView(Ui.tv(a, "ℹ️ ऐप", 15f, Ui.INK, true));
        c4.addView(Ui.line(a, "ऐप", "दूध हिसाब (Native)", false, null));
        c4.addView(Ui.line(a, "वर्ज़न", "1.0", false, null));
        c4.addView(Ui.line(a, "ग्राहक", String.valueOf(db.parties("customer").size()), false, null));
        c4.addView(Ui.line(a, "किसान", String.valueOf(db.parties("supplier").size()), false, null));
        c4.addView(Ui.label(a, "पूरी तरह native (Java) — तेज़ और हल्का। सारा डेटा फ़ोन की SQLite में सुरक्षित रहता है, इंटरनेट की ज़रूरत नहीं।"));
        box.addView(c4);

        Button wipe = Ui.btnGrey(a, "🗑️ सारा डेटा मिटाएँ");
        wipe.setTextColor(Ui.RED);
        wipe.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(a).setMessage("सारा डेटा हमेशा के लिए मिट जाएगा। पक्का?")
                        .setPositiveButton("हाँ, मिटाएँ", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { db.wipe(); ((MainActivity) a).toast("सारा डेटा मिट गया"); ((MainActivity) a).go(4); }
                        }).setNegativeButton("नहीं", null).show();
            }
        });
        box.addView(wipe);
    }
}
