package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/** Modules: bills + bulk bill sending. */
public class ModsD {

    public static boolean render(final Activity a, final LinearLayout box, final String id) {
        final Db db = Db.get(a);
        final String m = Util.month();

        if (id.equals("bills")) {
            box.addView(Scr.note(a, "इस महीने के सारे ग्राहकों के बिल एक ही PDF में बनेंगे — सीधे Downloads फ़ोल्डर में।"));
            Button all = Ui.btn(a, "📄 सबके बिल की PDF बनाएँ");
            all.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { allBillsPdf(a, db, m); }
            });
            box.addView(ModsA.rowBtn(a, all));
            box.addView(Scr.table(a, "🧾 " + Util.monthLabel(m) + " — बिल सारांश", db.rows(
                    "SELECT p.name, (IFNULL(SUM(e.qty),0) || ' L · ₹' || IFNULL(SUM(e.amount),0)) FROM parties p "
                            + "JOIN entries e ON e.party_id=p.id AND e.kind='sale' AND e.date LIKE ? WHERE p.type='customer' "
                            + "GROUP BY p.id HAVING SUM(e.amount)>0 ORDER BY SUM(e.amount) DESC",
                    new String[]{m + "%"}), "इस महीने किसी का बिल नहीं"));
            return true;
        }

        if (id.equals("bulkbill")) {
            final List<String[]> list = billList(db, m);
            box.addView(Scr.note(a, "एक-एक ग्राहक का बिल WhatsApp पर भेजें — \"भेजें\" दबाएँ, फिर \"अगला\"।"));
            Button start = Ui.btn(a, "📤 भेजना शुरू करें");
            start.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (list.isEmpty()) { ((MainActivity) a).toast("इस महीने कोई बिल नहीं"); return; }
                    queue(a, db, list, 0);
                }
            });
            box.addView(ModsA.rowBtn(a, start));

            LinearLayout c = Scr.card(a, "ग्राहक-वार बिल (" + list.size() + ")");
            if (list.isEmpty()) c.addView(Ui.label(a, "इस महीने कोई बिल नहीं"));
            for (String[] row : list) {
                final long pid = Long.parseLong(row[0]);
                c.addView(Scr.item(a, row[1], row[2] + " L · " + Util.money(Double.parseDouble(row[3])), "💬", Ui.GREEN,
                        new View.OnClickListener() {
                            public void onClick(View v) { sendWa(a, db, db.party(pid), m); }
                        }));
            }
            box.addView(c);
            return true;
        }

        return false;
    }

    /* ---------------- helpers ---------------- */

    private static List<String[]> billList(Db db, String m) {
        return db.rows("SELECT p.id, p.name, IFNULL(SUM(e.qty),0), IFNULL(SUM(e.amount),0) FROM parties p "
                + "JOIN entries e ON e.party_id=p.id AND e.kind='sale' AND e.date LIKE ? WHERE p.type='customer' "
                + "GROUP BY p.id HAVING SUM(e.amount)>0 ORDER BY SUM(e.amount) DESC", new String[]{m + "%"});
    }

    private static String billText(Db db, Db.Party p, String m) {
        double q = db.one("SELECT IFNULL(SUM(qty),0) FROM entries WHERE kind='sale' AND party_id=? AND date LIKE ?",
                new String[]{String.valueOf(p.id), m + "%"});
        double amt = db.one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND party_id=? AND date LIKE ?",
                new String[]{String.valueOf(p.id), m + "%"});
        double paid = db.one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE party_id=? AND date LIKE ?",
                new String[]{String.valueOf(p.id), m + "%"});
        return "🥛 " + db.get("shopName", "दूध हिसाब")
                + "\nबिल — " + p.name
                + "\n" + Util.monthLabel(m)
                + "\n────────────"
                + "\nदूध: " + Util.num(q) + " लीटर"
                + "\nकुल बिल: " + Util.money(amt)
                + "\nजमा: " + Util.money(paid)
                + "\nइस महीने बाकी: " + Util.money(amt - paid)
                + "\nकुल बकाया: " + Util.money(db.balance(p.id))
                + "\n────────────\nधन्यवाद 🙏";
    }

    private static void sendWa(Activity a, Db db, Db.Party p, String m) {
        if (p == null) return;
        if (p.phone == null || p.phone.isEmpty()) { ((MainActivity) a).toast("फ़ोन नंबर नहीं है"); return; }
        try {
            String url = "https://wa.me/91" + p.phone.replaceAll("[^0-9]", "") + "?text=" + Uri.encode(billText(db, p, m));
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) { ((MainActivity) a).toast("WhatsApp नहीं खुला"); }
    }

    private static void queue(final Activity a, final Db db, final List<String[]> list, final int i) {
        if (i >= list.size()) { ((MainActivity) a).toast("सब बिल भेज दिए ✓"); return; }
        final Db.Party p = db.party(Long.parseLong(list.get(i)[0]));
        if (p == null) { queue(a, db, list, i + 1); return; }
        LinearLayout v = ModsA.form(a);
        v.addView(Ui.tv(a, "ग्राहक " + (i + 1) + " / " + list.size(), 13f, Ui.MUTED, false));
        v.addView(Ui.tv(a, p.name, 18f, Ui.INK, true));
        v.addView(Ui.label(a, p.phone.isEmpty() ? "फ़ोन नंबर नहीं" : p.phone));
        TextView body = Ui.tv(a, billText(db, p, Util.month()), 13f, Ui.INK, false);
        v.addView(body);
        new AlertDialog.Builder(a)
                .setTitle("📤 बल्क बिल भेजें")
                .setView(v)
                .setPositiveButton("💬 भेजें", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { sendWa(a, db, p, Util.month()); queue(a, db, list, i + 1); }
                })
                .setNeutralButton("छोड़ें", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { queue(a, db, list, i + 1); }
                })
                .setNegativeButton(i >= list.size() - 1 ? "पूरा" : "अगला", null)
                .show();
    }

    /* ---------------- one PDF with every customer's bill ---------------- */

    private static void allBillsPdf(Activity a, Db db, String m) {
        try {
            List<Db.Party> ps = db.parties("customer");
            List<Db.Party> with = new ArrayList<Db.Party>();
            for (Db.Party p : ps) {
                double amt = db.one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND party_id=? AND date LIKE ?",
                        new String[]{String.valueOf(p.id), m + "%"});
                if (amt > 0) with.add(p);
            }
            if (with.isEmpty()) { ((MainActivity) a).toast("इस महीने कोई बिल नहीं"); return; }

            PdfDocument doc = new PdfDocument();
            Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
            for (int n = 0; n < with.size(); n++) {
                Db.Party p = with.get(n);
                PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder(595, 842, n + 1).create();
                PdfDocument.Page page = doc.startPage(pi);
                Canvas c = page.getCanvas();
                pt.setColor(Color.BLACK);
                int y = 56;
                pt.setTextSize(18); pt.setFakeBoldText(true);
                c.drawText(db.get("shopName", "दूध हिसाब"), 40, y, pt);
                y += 26;
                pt.setFakeBoldText(false); pt.setTextSize(12);
                String owner = db.get("owner", ""), phone = db.get("bizPhone", "");
                if (!owner.isEmpty()) { c.drawText(owner, 40, y, pt); y += 16; }
                if (!phone.isEmpty()) { c.drawText(phone, 40, y, pt); y += 16; }
                y += 8;
                pt.setTextSize(14); pt.setFakeBoldText(true);
                c.drawText("बिल — " + Util.monthLabel(m), 40, y, pt);
                pt.setFakeBoldText(false); pt.setTextSize(13);
                y += 20;
                c.drawText("नाम: " + p.name, 40, y, pt); y += 16;
                if (!p.phone.isEmpty()) { c.drawText("फ़ोन: " + p.phone, 40, y, pt); y += 16; }
                y += 6;
                c.drawText("तारीख", 40, y, pt); c.drawText("समय", 150, y, pt);
                c.drawText("लीटर", 240, y, pt); c.drawText("रेट", 320, y, pt); c.drawText("रकम", 430, y, pt);
                y += 6;
                c.drawRect(40, y, 555, y + 1, pt);
                y += 16;
                double q = 0, amt = 0;
                List<Db.Entry> es = db.entriesOf(p.id, Util.firstOfMonth(m), Util.lastOfMonth(m));
                for (Db.Entry e : es) {
                    if (!"sale".equals(e.kind)) continue;
                    q += e.qty; amt += e.amount;
                    c.drawText(e.date, 40, y, pt);
                    c.drawText(Util.shiftHi(e.shift), 150, y, pt);
                    c.drawText(Util.num(e.qty), 240, y, pt);
                    c.drawText(Util.num(e.rate), 320, y, pt);
                    c.drawText(Util.money(e.amount), 430, y, pt);
                    y += 16;
                    if (y > 760) break;
                }
                double paid = db.one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE party_id=? AND date LIKE ?",
                        new String[]{String.valueOf(p.id), m + "%"});
                y += 8;
                c.drawRect(40, y, 555, y + 1, pt);
                y += 22;
                pt.setTextSize(14); pt.setFakeBoldText(true);
                c.drawText("कुल दूध: " + Util.num(q) + " लीटर", 40, y, pt); y += 20;
                c.drawText("कुल बिल: " + Util.money(amt), 40, y, pt); y += 20;
                c.drawText("जमा: " + Util.money(paid), 40, y, pt); y += 20;
                c.drawText("कुल बकाया: " + Util.money(db.balance(p.id)), 40, y, pt);
                y += 30;
                pt.setFakeBoldText(false); pt.setTextSize(11);
                c.drawText("धन्यवाद 🙏", 40, y, pt);
                doc.finishPage(page);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            doc.writeTo(bos);
            doc.close();
            String where = Io.saveToDownloads(a, "bills-" + m + ".pdf", "application/pdf", bos.toByteArray());
            ((MainActivity) a).toast(where == null ? "PDF सेव नहीं हो सकी" : "PDF सेव: " + where + " (" + with.size() + " बिल)");
        } catch (Exception e) {
            ((MainActivity) a).toast("PDF नहीं बन सकी");
        }
    }
}
