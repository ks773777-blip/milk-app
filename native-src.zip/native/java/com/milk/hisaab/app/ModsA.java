package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

/** Modules: daily work + money. */
public class ModsA {

    /* ---------------- small form helpers ---------------- */

    static LinearLayout form(Activity a) {
        LinearLayout v = Ui.col(a);
        int p = Ui.dp(a, 16);
        v.setPadding(p, p, p, p);
        return v;
    }

    static void show(final Activity a, String title, LinearLayout body, String ok, DialogInterface.OnClickListener run, final String reopen) {
        new AlertDialog.Builder(a).setTitle(title).setView(body)
                .setPositiveButton(ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        run.onClick(d, w);
                        if (reopen != null) ((MainActivity) a).openModule(reopen);
                    }
                })
                .setNegativeButton("रद्द", null).show();
    }

    static double num(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch (Exception x) { return 0; } }
    static String str(EditText e) { return e.getText().toString().trim(); }

    static Spinner spin(Activity a, String[] items) {
        Spinner s = new Spinner(a);
        s.setAdapter(new ArrayAdapter<String>(a, android.R.layout.simple_spinner_dropdown_item, items));
        return s;
    }

    static EditText et(Activity a, String hint, String val) {
        EditText e = Ui.input(a, hint);
        if (val != null) e.setText(val);
        return e;
    }

    static LinearLayout rowBtn(Activity a, Button b) {
        LinearLayout r = Ui.row(a);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(b);
        return r;
    }

    /* ---------------- render ---------------- */

    public static boolean render(final Activity a, final LinearLayout box, final String id) {
        final Db db = Db.get(a);
        String m = Util.month(), today = Util.today();

        if (id.equals("bulk")) {
            Button go = Ui.btn(a, "आज के लिए सबकी डिफ़ॉल्ट एंट्री भरें");
            go.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { bulkDialog(a, false); }
            });
            box.addView(rowBtn(a, go));
            box.addView(Scr.note(a, "हर सक्रिय ग्राहक की डिफ़ॉल्ट मात्रा के हिसाब से एक-एक एंट्री बन जाएगी (जिनकी छुट्टी है उनकी नहीं)।"));
            return true;
        }
        if (id.equals("bulkmonth")) {
            Button go = Ui.btn(a, "पूरे महीने की एंट्री भरें");
            go.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { bulkDialog(a, true); } });
            box.addView(rowBtn(a, go));
            box.addView(Scr.note(a, "इस महीने की हर तारीख के लिए डिफ़ॉल्ट मात्रा भर दी जाएगी। पहले से भरी एंट्री नहीं बदलेगी।"));
            return true;
        }
        if (id.equals("holiday")) {
            final List<Db.Party> ps = db.parties("customer");
            LinearLayout v = form(a);
            final EditText d = et(a, "तारीख", today);
            v.addView(d);
            v.addView(Ui.label(a, "किसकी छुट्टी?"));
            final Spinner sp = spin(a, names(ps));
            v.addView(sp);
            Button b = Ui.btn(a, "छुट्टी जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("date", str(d)); cv.put("party_id", ps.get(sp.getSelectedItemPosition()).id);
                    db.insert("holidays", cv);
                    ((MainActivity) a).toast("छुट्टी जुड़ गई ✓");
                    ((MainActivity) a).openModule("holiday");
                }
            });
            box.addView(Ui.card(a));
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "इस महीने की छुट्टियाँ", db.rows(
                    "SELECT p.name, h.date FROM holidays h LEFT JOIN parties p ON p.id=h.party_id WHERE h.date LIKE ? ORDER BY h.date DESC", new String[]{m + "%"}),
                    "कोई छुट्टी दर्ज नहीं"));
            return true;
        }
        if (id.equals("milkcard")) {
            box.addView(Scr.table(a, "🥛 " + Util.monthLabel(m) + " — मिल्क कार्ड", db.rows(
                    "SELECT p.name, (IFNULL(SUM(e.qty),0) || ' L · ' || IFNULL(SUM(e.amount),0)) FROM parties p LEFT JOIN entries e ON e.party_id=p.id AND e.kind='sale' AND e.date LIKE ? WHERE p.type='customer' GROUP BY p.id ORDER BY SUM(e.amount) DESC",
                    new String[]{m + "%"}), "कोई डेटा नहीं"));
            return true;
        }
        if (id.equals("calendar")) {
            box.addView(calendarCard(a, db, m));
            return true;
        }
        if (id.equals("register")) {
            box.addView(Scr.table(a, "📒 डेली रजिस्टर", db.rows(
                    "SELECT date, (IFNULL(SUM(qty),0) || ' L · ₹' || IFNULL(SUM(amount),0)) FROM entries WHERE kind='sale' AND date LIKE ? GROUP BY date ORDER BY date DESC LIMIT 20",
                    new String[]{m + "%"}), "कोई एंट्री नहीं"));
            return true;
        }
        if (id.equals("delivery")) {
            final EditText d = et(a, "तारीख", today);
            final Spinner sh = spin(a, new String[]{"सुबह", "शाम", "दोनों"});
            LinearLayout v = form(a);
            v.addView(d);
            v.addView(sh);
            Button b = Ui.btn(a, "शीट देखें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) { deliverySheet(a, box, str(d), sh.getSelectedItemPosition()); }
            });
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.note(a, "रूट के हिसाब से लिस्ट बनेगी — डिलीवरी के समय काम आएगी।"));
            return true;
        }
        if (id.equals("dayend")) {
            double mq = db.qtyOn(today, "morning"), eq = db.qtyOn(today, "evening");
            double ma = db.saleAmtOn(today, "morning"), ea = db.saleAmtOn(today, "evening");
            double s = db.saleOn(today);
            double pur = db.one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='purchase' AND date=?", new String[]{today});
            double pay = db.one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE date=?", new String[]{today});
            double exp = db.one("SELECT IFNULL(SUM(amount),0) FROM expenses WHERE date=?", new String[]{today});
            double wst = db.one("SELECT IFNULL(SUM(value),0) FROM wastage WHERE date=?", new String[]{today});
            double net = s - pur - exp - wst;
            box.addView(Scr.report(a, "🌙 दिन-अंत सारांश · " + Util.niceDate(today),
                    new String[]{"🌅 सुबह", "🌙 शाम", "बिक्री", "खरीद", "वसूली (जमा)", "खर्च", "वेस्टेज", "शुद्ध मुनाफ़ा"},
                    new String[]{Util.num(mq) + " L · " + Util.money(ma), Util.num(eq) + " L · " + Util.money(ea),
                            Util.money(s), Util.money(pur), Util.money(pay), Util.money(exp), Util.money(wst), Util.money(net)},
                    net >= 0 ? Ui.GREEN : Ui.RED));
            return true;
        }
        if (id.equals("stock")) {
            LinearLayout v = form(a);
            final EditText nm = et(a, "सामान का नाम (जैसे: थैली)", "");
            final EditText st = et(a, "कितना है", "");
            final EditText lo = et(a, "कम होने पर चेतावनी (कितना)", "");
            v.addView(nm); v.addView(st); v.addView(lo);
            Button b = Ui.btn(a, "जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    ContentValues cv = new ContentValues();
                    cv.put("name", str(nm)); cv.put("stock", num(st)); cv.put("low_at", num(lo)); cv.put("rate", 0);
                    db.insert("items", cv);
                    ((MainActivity) a).toast("जुड़ गया ✓");
                    ((MainActivity) a).openModule("stock");
                }
            });
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "📦 स्टॉक", db.rows(
                    "SELECT name, (stock || ' (कम: ' || low_at || ')') FROM items ORDER BY name", null), "कोई सामान नहीं"));
            return true;
        }
        if (id.equals("notes")) {
            final EditText t = Ui.input(a, "नोट लिखें…");
            Button b = Ui.btn(a, "नोट जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (str(t).isEmpty()) return;
                    ContentValues cv = new ContentValues();
                    cv.put("date", Util.today()); cv.put("text", str(t));
                    db.insert("notes", cv);
                    ((MainActivity) a).toast("नोट जुड़ गया ✓");
                    ((MainActivity) a).openModule("notes");
                }
            });
            box.addView(t);
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "📝 नोट्स", db.rows("SELECT date, text FROM notes ORDER BY id DESC", null), "कोई नोट नहीं"));
            return true;
        }
        if (id.equals("calc")) { box.addView(calcCard(a)); return true; }

        /* ---------- money ---------- */

        if (id.equals("payments")) {
            final List<Db.Party> ps = db.parties(null);
            LinearLayout v = form(a);
            v.addView(Ui.label(a, "किससे / किसको"));
            final Spinner sp = spin(a, names(ps));
            final EditText amt = et(a, "रकम", "");
            final EditText d = et(a, "तारीख", today);
            final EditText nt = et(a, "नोट (वैकल्पिक)", "");
            v.addView(sp); v.addView(amt); v.addView(d); v.addView(nt);
            Button b = Ui.btn(a, "भुगतान जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
                    double am = num(amt);
                    if (am <= 0) { ((MainActivity) a).toast("रकम डालें"); return; }
                    db.addPayment(str(d), ps.get(sp.getSelectedItemPosition()).id, am, "", str(nt));
                    ((MainActivity) a).toast("भुगतान जुड़ गया ✓");
                    ((MainActivity) a).openModule("payments");
                }
            });
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "💵 हाल के भुगतान", db.rows(
                    "SELECT (p.name || ' · ' || pay.date), pay.amount FROM payments pay LEFT JOIN parties p ON p.id=pay.party_id ORDER BY pay.id DESC LIMIT 20", null),
                    "कोई भुगतान नहीं"));
            return true;
        }
        if (id.equals("dues")) {
            List<String[]> d = db.dueList();
            List<String[]> out = new ArrayList<String[]>();
            for (String[] x : d) out.add(new String[]{x[0], Util.money(Double.parseDouble(x[1]))});
            box.addView(Scr.report(a, "⏳ कुल बकाया", new String[]{"वसूली बाकी"}, new String[]{Util.money(db.totalDue())}, Ui.RED));
            box.addView(Scr.table(a, "ग्राहक-वार बकाया", out, "कोई बकाया नहीं ✅"));
            return true;
        }
        if (id.equals("expenses")) {
            LinearLayout v = form(a);
            final EditText amt = et(a, "रकम", "");
            final EditText cat = et(a, "श्रेणी (चारा, बिजली, मजदूरी…)", "");
            final EditText nt = et(a, "नोट", "");
            final EditText d = et(a, "तारीख", today);
            v.addView(amt); v.addView(cat); v.addView(nt); v.addView(d);
            Button b = Ui.btn(a, "खर्च जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (num(amt) <= 0) { ((MainActivity) a).toast("रकम डालें"); return; }
                    db.addExpense(str(d), num(amt), str(cat), str(nt));
                    ((MainActivity) a).toast("खर्च जुड़ गया ✓");
                    ((MainActivity) a).openModule("expenses");
                }
            });
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "💸 हाल के खर्च", db.rows(
                    "SELECT (cat || ' · ' || date || ' ' || note), amount FROM expenses ORDER BY id DESC LIMIT 20", null), "कोई खर्च नहीं"));
            return true;
        }
        if (id.equals("explog")) {
            box.addView(Scr.table(a, "🧾 " + Util.monthLabel(m) + " — श्रेणी-वार खर्च", db.rows(
                    "SELECT cat, (IFNULL(SUM(amount),0) || ' · ' || COUNT(*) || ' बार') FROM expenses WHERE date LIKE ? GROUP BY cat ORDER BY SUM(amount) DESC",
                    new String[]{m + "%"}), "कोई खर्च नहीं"));
            return true;
        }
        if (id.equals("rate")) {
            box.addView(Scr.table(a, "📈 रेट चार्ट", db.rows(
                    "SELECT name, (rate || ' ₹/L') FROM parties WHERE rate>0 ORDER BY name", null), "कोई रेट सेट नहीं"));
            return true;
        }
        if (id.equals("loans")) {
            LinearLayout v = form(a);
            final EditText nm = et(a, "नाम", "");
            final EditText am = et(a, "रकम", "");
            final Spinner k = spin(a, new String[]{"दिया (लेना है)", "लिया (देना है)"});
            final EditText nt = et(a, "नोट", "");
            v.addView(nm); v.addView(am); v.addView(k); v.addView(nt);
            Button b = Ui.btn(a, "उधार जोड़ें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (str(nm).isEmpty() || num(am) <= 0) { ((MainActivity) a).toast("नाम और रकम डालें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("date", Util.today()); cv.put("name", str(nm)); cv.put("amount", num(am));
                    cv.put("kind", k.getSelectedItemPosition() == 0 ? "lent" : "borrowed");
                    cv.put("note", str(nt)); cv.put("settled", 0);
                    db.insert("loans", cv);
                    ((MainActivity) a).toast("जुड़ गया ✓");
                    ((MainActivity) a).openModule("loans");
                }
            });
            box.addView(v);
            box.addView(rowBtn(a, b));
            box.addView(Scr.report(a, "💳 बाकी उधार",
                    new String[]{"दिया (लेना है)", "लिया (देना है)"},
                    new String[]{Util.money(db.one("SELECT IFNULL(SUM(amount),0) FROM loans WHERE kind='lent' AND settled=0", null)),
                            Util.money(db.one("SELECT IFNULL(SUM(amount),0) FROM loans WHERE kind='borrowed' AND settled=0", null))}, Ui.INK));
            box.addView(Scr.table(a, "सारे उधार", db.rows(
                    "SELECT (name || ' · ' || date), (amount || CASE WHEN settled=1 THEN ' ✓' ELSE '' END) FROM loans ORDER BY id DESC", null), "कोई उधार नहीं"));
            return true;
        }
        if (id.equals("recurring")) {
            LinearLayout v = form(a);
            final EditText nm = et(a, "नाम (किराया, सैलरी…)", "");
            final EditText am = et(a, "रकम", "");
            final EditText day = et(a, "महीने की कौन सी तारीख", "1");
            v.addView(nm); v.addView(am); v.addView(day);
            Button add = Ui.btn(a, "जोड़ें");
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (str(nm).isEmpty() || num(am) <= 0) { ((MainActivity) a).toast("नाम और रकम डालें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("name", str(nm)); cv.put("amount", num(am)); cv.put("cat", str(nm));
                    cv.put("day", (int) num(day)); cv.put("active", 1);
                    db.insert("recurring", cv);
                    ((MainActivity) a).openModule("recurring");
                }
            });
            Button run = Ui.btnGrey(a, "इस महीने के खर्च जोड़ें");
            run.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    List<String[]> rs = db.rows("SELECT id, name, amount, day FROM recurring WHERE active=1", null);
                    int n = 0;
                    for (String[] r : rs) {
                        String dt = m + "-" + pad((int) Double.parseDouble(r[3]));
                        double c = db.one("SELECT COUNT(*) FROM expenses WHERE date=? AND cat=? AND amount=?", new String[]{dt, r[1], r[2]});
                        if (c > 0) continue;
                        db.addExpense(dt, Double.parseDouble(r[2]), r[1], r[1]);
                        n++;
                    }
                    ((MainActivity) a).toast(n > 0 ? (n + " खर्च जुड़ गए ✓") : "पहले ही जुड़े हैं");
                    ((MainActivity) a).openModule("recurring");
                }
            });
            box.addView(v);
            box.addView(rowBtn(a, add));
            box.addView(rowBtn(a, run));
            box.addView(Scr.table(a, "🔁 आवर्ती खर्च", db.rows(
                    "SELECT name, (amount || ' · तारीख ' || day) FROM recurring ORDER BY id", null), "कुछ नहीं जुड़ा"));
            return true;
        }
        if (id.equals("budget")) {
            double budget = db.getNum("budget_total", 0);
            box.addView(Scr.report(a, "💰 मासिक बजट",
                    new String[]{"बजट", "अब तक खर्च", "बाकी"},
                    new String[]{Util.money(budget), Util.money(db.expenseMonth(m)),
                            Util.money(Math.max(0, budget - db.expenseMonth(m)))},
                    budget > 0 && db.expenseMonth(m) > budget ? Ui.RED : Ui.GREEN));
            final EditText b = et(a, "महीने का कुल बजट", budget > 0 ? Util.num(budget) : "");
            box.addView(b);
            Button sv = Ui.btn(a, "बजट सेव करें");
            sv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) { db.set("budget_total", String.valueOf(num(b))); ((MainActivity) a).toast("सेव ✓"); ((MainActivity) a).openModule("budget"); }
            });
            box.addView(rowBtn(a, sv));
            box.addView(Scr.table(a, "श्रेणी-वार खर्च (इस महीने)", db.rows(
                    "SELECT cat, IFNULL(SUM(amount),0) FROM expenses WHERE date LIKE ? GROUP BY cat ORDER BY SUM(amount) DESC", new String[]{m + "%"}), "कोई खर्च नहीं"));
            return true;
        }
        if (id.equals("pnl")) {
            double s = db.saleMonth(m), p = db.purchaseMonth(m), x = db.expenseMonth(m), w = db.wastageMonth(m);
            box.addView(Scr.report(a, "📉 " + Util.monthLabel(m) + " — लाभ-हानि",
                    new String[]{"बिक्री", "खरीद", "खर्च", "वेस्टेज", "शुद्ध मुनाफ़ा"},
                    new String[]{Util.money(s), Util.money(p), Util.money(x), Util.money(w), Util.money(s - p - x - w)},
                    (s - p - x - w) >= 0 ? Ui.GREEN : Ui.RED));
            return true;
        }
        if (id.equals("monthclose")) {
            box.addView(Scr.report(a, "📅 " + Util.monthLabel(m) + " — महीना बंद",
                    new String[]{"बिक्री", "खरीद", "खर्च", "वेस्टेज", "शुद्ध मुनाफ़ा"},
                    new String[]{Util.money(db.saleMonth(m)), Util.money(db.purchaseMonth(m)), Util.money(db.expenseMonth(m)),
                            Util.money(db.wastageMonth(m)), Util.money(db.netMonth(m))}, Ui.INK));
            Button b = Ui.btn(a, "इस महीने का हिसाब बंद करें");
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    ContentValues cv = new ContentValues();
                    cv.put("month", m); cv.put("at", System.currentTimeMillis());
                    cv.put("json", db.dumpJson());
                    db.getWritableDatabase().insertWithOnConflict("closes", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                    ((MainActivity) a).toast("महीना बंद हो गया ✓");
                    ((MainActivity) a).openModule("monthclose");
                }
            });
            box.addView(rowBtn(a, b));
            box.addView(Scr.table(a, "बंद किए महीने", db.rows("SELECT month, date(at/1000,'unixepoch') FROM closes ORDER BY month DESC", null), "अभी कोई नहीं"));
            return true;
        }

        return false;
    }

    /* ---------------- helpers used by modules ---------------- */

    static String pad(int d) { return d < 10 ? "0" + d : String.valueOf(d); }

    static String[] names(List<Db.Party> ps) {
        if (ps.isEmpty()) return new String[]{"— कोई नहीं —"};
        String[] n = new String[ps.size()];
        for (int i = 0; i < ps.size(); i++) n[i] = ps.get(i).name;
        return n;
    }

    private static void bulkDialog(final Activity a, final boolean wholeMonth) {
        final Db db = Db.get(a);
        LinearLayout v = form(a);
        final EditText d = et(a, "तारीख (YYYY-MM-DD)", Util.today());
        final Spinner sh = spin(a, new String[]{"सुबह", "शाम"});
        sh.setSelection("evening".equals(Util.autoShift()) ? 1 : 0);
        final EditText q = et(a, "मात्रा (खाली = हर ग्राहक की डिफ़ॉल्ट)", "");
        v.addView(d); v.addView(sh); v.addView(q);
        show(a, wholeMonth ? "बल्क मासिक एंट्री" : "बल्क एंट्री", v, "भरें", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dlg, int w) {
                String shift = sh.getSelectedItemPosition() == 1 ? "evening" : "morning";
                double over = num(q);
                List<Db.Party> ps = db.parties("customer");
                List<String> dates = new ArrayList<String>();
                if (wholeMonth) {
                    String mm = Util.monthOf(str(d));
                    String last = Util.lastOfMonth(mm);
                    int days = Integer.parseInt(last.substring(8, 10));
                    for (int i = 1; i <= days; i++) dates.add(mm + "-" + pad(i));
                } else dates.add(str(d));
                int n = 0;
                for (String dt : dates) {
                    for (Db.Party p : ps) {
                        double qty = over > 0 ? over : p.defaultQty;
                        if (qty <= 0) continue;
                        if (db.hasHoliday(dt, p.id)) continue;
                        double c = db.one("SELECT COUNT(*) FROM entries WHERE date=? AND party_id=? AND shift=?", new String[]{dt, String.valueOf(p.id), shift});
                        if (c > 0) continue;
                        double rt = p.rate > 0 ? p.rate : db.getNum("defaultRate", 50);
                        Db.Entry e = new Db.Entry();
                        e.date = dt; e.partyId = p.id; e.kind = "sale"; e.shift = shift;
                        e.qty = qty; e.rate = rt; e.amount = Math.round(qty * rt);
                        db.saveEntry(e);
                        n++;
                    }
                }
                ((MainActivity) a).toast(n + " एंट्री भर दीं ✓");
            }
        }, null);
    }

    private static LinearLayout calendarCard(Activity a, Db db, String m) {
        LinearLayout c = Scr.card(a, "📅 " + Util.monthLabel(m));
        int days = Integer.parseInt(Util.lastOfMonth(m).substring(8, 10));
        LinearLayout row = null;
        for (int i = 1; i <= days; i++) {
            if ((i - 1) % 7 == 0) { row = Ui.row(a); c.addView(row); }
            String dt = m + "-" + pad(i);
            double amt = db.saleOn(dt);
            LinearLayout cell = Ui.col(a);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(Ui.dp(a, 2), Ui.dp(a, 6), Ui.dp(a, 2), Ui.dp(a, 6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            cell.setLayoutParams(lp);
            cell.addView(Ui.tv(a, String.valueOf(i), 12f, Ui.MUTED, false));
            cell.addView(Ui.tv(a, amt > 0 ? Util.num(Math.round(amt / 100) / 10.0) + "k" : "·", 11f, amt > 0 ? Ui.GREEN : Ui.LINE, amt > 0));
            row.addView(cell);
        }
        c.addView(Ui.label(a, "हरे नंबर = उस दिन की बिक्री ( हज़ार में)"));
        return c;
    }

    private static void deliverySheet(Activity a, LinearLayout box, String date, int shiftIdx) {
        Db db = Db.get(a);
        String[] shifts = shiftIdx == 2 ? new String[]{"morning", "evening"} : new String[]{shiftIdx == 1 ? "evening" : "morning"};
        List<String[]> out = new ArrayList<String[]>();
        double tot = 0;
        for (Db.Party p : db.parties("customer")) {
            if (db.hasHoliday(date, p.id)) continue;
            for (String sh : shifts) {
                double q = db.one("SELECT IFNULL(SUM(qty),0) FROM entries WHERE date=? AND party_id=? AND shift=? AND kind='sale'",
                        new String[]{date, String.valueOf(p.id), sh});
                boolean done = q > 0;
                if (q <= 0) q = p.defaultQty;
                if (q <= 0) continue;
                tot += q;
                out.add(new String[]{(done ? "✅ " : "⬜ ") + p.name + "  (" + (p.route.isEmpty() ? "—" : p.route) + ")",
                        Util.num(q) + " L · " + Util.shiftHi(sh)});
            }
        }
        box.addView(Scr.table(a, "🚚 " + Util.niceDate(date) + " — डिलीवरी शीट", out, "इस दिन कुछ नहीं"));
        box.addView(Scr.report(a, "कुल", new String[]{"दूध"}, new String[]{Util.num(tot) + " L"}, Ui.GREEN));
    }

    private static LinearLayout calcCard(final Activity a) {
        LinearLayout c = Scr.card(a, "🧮 कैलकुलेटर");
        final EditText disp = Ui.input(a, "जैसे: (1200+800)/2");
        disp.setTextSize(20f);
        c.addView(disp);
        final LinearLayout out = Ui.col(a);
        c.addView(out);
        String[] keys = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "(", ")", "+"};
        LinearLayout row = null;
        for (int i = 0; i < keys.length; i++) {
            if (i % 4 == 0) { row = Ui.row(a); c.addView(row); }
            final String k = keys[i];
            Button b = Ui.btnGrey(a, k);
            b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { disp.setText(disp.getText().toString() + k); }
            });
            row.addView(b);
        }
        LinearLayout acts = Ui.row(a);
        Button cl = Ui.btnGrey(a, "C");
        cl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cl.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { disp.setText(""); } });
        acts.addView(cl);
        Button eq = Ui.btn(a, "=");
        eq.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        eq.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double r = new Calc(disp.getText().toString()).run();
                out.removeAllViews();
                out.addView(Ui.tv(a, "= " + Util.num(Math.round(r * 100) / 100.0), 22f, Ui.GREEN, true));
            }
        });
        acts.addView(eq);
        c.addView(acts);
        return c;
    }

    /** Tiny expression evaluator: + - * / and brackets. */
    static class Calc {
        private final String s; private int i;
        Calc(String t) { s = t == null ? "" : t.replace(" ", ""); }
        double run() { i = 0; return expr(); }
        private double expr() {
            double v = term();
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '+') { i++; v += term(); }
                else if (c == '-') { i++; v -= term(); }
                else break;
            }
            return v;
        }
        private double term() {
            double v = fac();
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '*') { i++; v *= fac(); }
                else if (c == '/') { i++; double d = fac(); v = (d == 0 ? 0 : v / d); }
                else break;
            }
            return v;
        }
        private double fac() {
            if (i < s.length() && s.charAt(i) == '(') { i++; double v = expr(); if (i < s.length() && s.charAt(i) == ')') i++; return v; }
            double sg = 1;
            while (i < s.length() && (s.charAt(i) == '-' || s.charAt(i) == '+')) { if (s.charAt(i) == '-') sg = -sg; i++; }
            int st = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) i++;
            if (i == st) { if (i < s.length()) i++; return 0; }
            try { return sg * Double.parseDouble(s.substring(st, i)); } catch (Exception e) { return 0; }
        }
    }
}
