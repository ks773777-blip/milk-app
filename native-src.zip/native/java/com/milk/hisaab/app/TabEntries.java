package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

/** Daily entries tab. */
public class TabEntries {

    private static String date = Util.today();

    public void build(final Activity a, LinearLayout box) {
        final Db db = Db.get(a);

        LinearLayout nav = Ui.card(a);
        LinearLayout r = Ui.row(a);
        Button prev = Ui.btnGrey(a, "◀");
        prev.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { date = Util.addDays(date, -1); ((MainActivity) a).go(1); } });
        r.addView(prev);
        TextView dt = Ui.tv(a, Util.niceDate(date), 15f, Ui.INK, true);
        dt.setGravity(Gravity.CENTER);
        Ui.weight(dt, 1f);
        r.addView(dt);
        Button next = Ui.btnGrey(a, "▶");
        next.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { date = Util.addDays(date, 1); ((MainActivity) a).go(1); } });
        r.addView(next);
        nav.addView(r);
        if (!date.equals(Util.today())) {
            Button td = Ui.btnGrey(a, "आज पर जाएँ");
            td.setLayoutParams(Ui.lpGap(a, 8));
            td.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { date = Util.today(); ((MainActivity) a).go(1); } });
            nav.addView(td);
        }
        Button add = Ui.btn(a, "➕ नई एंट्री");
        add.setLayoutParams(Ui.lpGap(a, 8));
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { addEntry(a, db); } });
        nav.addView(add);
        box.addView(nav);

        List<Db.Entry> es = db.entriesOn(date);
        double q = 0, amt = 0;
        for (Db.Entry e : es) { q += e.qty; amt += e.amount; }

        LinearLayout c = Ui.card(a);
        c.addView(Ui.tv(a, "📋 " + Util.niceDate(date) + " की एंट्री", 15f, Ui.INK, true));
        if (es.isEmpty()) {
            c.addView(Ui.label(a, "इस दिन कोई एंट्री नहीं — ➕ से जोड़ें"));
        } else {
            for (final Db.Entry e : es) {
                Db.Party p = db.party(e.partyId);
                LinearLayout row = Ui.listRow(a);
                LinearLayout col = Ui.col(a);
                Ui.weight(col, 1f);
                col.addView(Ui.tv(a, (p == null ? "?" : p.name), 15f, Ui.INK, true));
                col.addView(Ui.label(a, Util.shiftHi(e.shift) + " · " + Util.num(e.qty) + " L · " + Util.num(e.rate) + "/L"));
                row.addView(col);
                row.addView(Ui.tv(a, Util.money(e.amount), 15f, Ui.INK, true));
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    public boolean onLongClick(View v) {
                        new AlertDialog.Builder(a).setMessage("यह एंट्री हटाएँ?")
                                .setPositiveButton("हटाएँ", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface d, int w) { db.deleteEntry(e.id); ((MainActivity) a).toast("हटा दिया"); ((MainActivity) a).go(1); }
                                }).setNegativeButton("नहीं", null).show();
                        return true;
                    }
                });
                c.addView(row);
            }
            c.addView(Ui.divider(a));
            c.addView(Ui.line(a, "कुल", Util.num(q) + " L · " + Util.money(amt), true, Ui.GREEN));
        }
        box.addView(c);
        box.addView(Ui.label(a, "टिप: किसी एंट्री को हटाने के लिए उस पर देर तक दबाएँ।"));
    }

    private void addEntry(final Activity a, final Db db) {
        final List<Db.Party> ps = db.parties("customer");
        if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
        LinearLayout v = Ui.col(a);
        int p = Ui.dp(a, 16);
        v.setPadding(p, p, p, p);
        v.addView(Ui.label(a, "ग्राहक"));
        final Spinner sp = new Spinner(a);
        String[] names = new String[ps.size()];
        for (int i = 0; i < ps.size(); i++) names[i] = ps.get(i).name;
        sp.setAdapter(new ArrayAdapter<String>(a, android.R.layout.simple_spinner_dropdown_item, names));
        v.addView(sp);
        v.addView(Ui.label(a, "समय (घड़ी के हिसाब से चुना गया)"));
        final Spinner sh = new Spinner(a);
        sh.setAdapter(new ArrayAdapter<String>(a, android.R.layout.simple_spinner_dropdown_item, new String[]{"सुबह", "शाम"}));
        sh.setSelection("evening".equals(Util.autoShift()) ? 1 : 0);
        v.addView(sh);
        final EditText qty = Ui.input(a, "मात्रा (लीटर)");
        v.addView(qty);
        final EditText rate = Ui.input(a, "रेट (खाली छोड़ें = ग्राहक का रेट)");
        v.addView(rate);
        new AlertDialog.Builder(a)
                .setTitle("नई एंट्री · " + Util.niceDate(date))
                .setView(v)
                .setPositiveButton("सेव", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        double q = parse(qty.getText().toString());
                        if (q <= 0) { ((MainActivity) a).toast("मात्रा डालें"); return; }
                        Db.Party sel = ps.get(sp.getSelectedItemPosition());
                        double rt = parse(rate.getText().toString());
                        if (rt <= 0) rt = sel.rate > 0 ? sel.rate : db.getNum("defaultRate", 50);
                        Db.Entry e = new Db.Entry();
                        e.date = date; e.partyId = sel.id; e.kind = "sale";
                        e.shift = sh.getSelectedItemPosition() == 1 ? "evening" : "morning";
                        e.qty = q; e.rate = rt; e.amount = Math.round(q * rt);
                        db.saveEntry(e);
                        ((MainActivity) a).toast("सेव हो गया ✓");
                        ((MainActivity) a).go(1);
                    }
                })
                .setNegativeButton("रद्द", null).show();
    }

    static double parse(String s) { try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; } }
}
