package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Modules: people + reports & bills. */
public class ModsB {

    public static boolean render(final Activity a, final LinearLayout box, final String id) {
        final Db db = Db.get(a);
        final String m = Util.month(), today = Util.today();

        if (id.equals("routes")) {
            box.addView(Scr.table(a, "🛣️ " + Util.monthLabel(m) + " — रूट सारांश", db.rows(
                    "SELECT CASE WHEN IFNULL(p.route,'')='' THEN '—' ELSE p.route END, (COUNT(DISTINCT p.id) || ' ग्राहक · ' || IFNULL(SUM(e.qty),0) || ' L · ₹' || IFNULL(SUM(e.amount),0)) "
                            + "FROM parties p LEFT JOIN entries e ON e.party_id=p.id AND e.kind='sale' AND e.date LIKE ? WHERE p.type='customer' GROUP BY p.route ORDER BY SUM(e.amount) DESC",
                    new String[]{m + "%"}), "कोई डेटा नहीं"));
            return true;
        }
        if (id.equals("topcust")) {
            box.addView(Scr.table(a, "🏆 " + Util.monthLabel(m) + " — टॉप ग्राहक", db.rows(
                    "SELECT p.name, (IFNULL(SUM(e.qty),0) || ' L · ₹' || IFNULL(SUM(e.amount),0)) FROM parties p LEFT JOIN entries e ON e.party_id=p.id AND e.kind='sale' AND e.date LIKE ? "
                            + "WHERE p.type='customer' GROUP BY p.id ORDER BY SUM(e.amount) DESC LIMIT 15",
                    new String[]{m + "%"}), "कोई डेटा नहीं"));
            return true;
        }
        if (id.equals("inactive")) {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, -7);
            String cut = Util.ymd(c.getTime());
            List<String[]> r = db.rows(
                    "SELECT p.name, IFNULL((SELECT MAX(e.date) FROM entries e WHERE e.party_id=p.id),'कभी नहीं') FROM parties p WHERE p.type='customer' AND p.active=1 "
                            + "AND IFNULL((SELECT MAX(e.date) FROM entries e WHERE e.party_id=p.id),'') < ? ORDER BY p.name", new String[]{cut});
            box.addView(Scr.table(a, "😴 7 दिन से निष्क्रिय", r, "सभी ग्राहक सक्रिय हैं ✅"));
            return true;
        }
        if (id.equals("staff")) {
            final EditText nm = ModsA.et(a, "स्टाफ का नाम", "");
            final EditText ph = ModsA.et(a, "फ़ोन", "");
            final EditText wg = ModsA.et(a, "महीने की मजदूरी", "");
            LinearLayout v = ModsA.form(a);
            v.addView(nm); v.addView(ph); v.addView(wg);
            Button add = Ui.btn(a, "स्टाफ जोड़ें");
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    if (ModsA.str(nm).isEmpty()) { ((MainActivity) a).toast("नाम डालें"); return; }
                    ContentValues cv = new ContentValues();
                    cv.put("name", ModsA.str(nm)); cv.put("phone", ModsA.str(ph));
                    cv.put("wage", ModsA.num(wg)); cv.put("active", 1);
                    db.insert("staff", cv);
                    ((MainActivity) a).toast("जुड़ गया ✓");
                    ((MainActivity) a).openModule("staff");
                }
            });
            box.addView(v);
            box.addView(ModsA.rowBtn(a, add));
            Button att = Ui.btnGrey(a, "आज की हाज़िरी भरें");
            att.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    List<String[]> ss = db.rows("SELECT id, name FROM staff WHERE active=1", null);
                    if (ss.isEmpty()) { ((MainActivity) a).toast("पहले स्टाफ जोड़ें"); return; }
                    final String[] nm2 = new String[ss.size()];
                    final long[] ids = new long[ss.size()];
                    for (int i = 0; i < ss.size(); i++) { nm2[i] = ss.get(i)[1]; ids[i] = Long.parseLong(ss.get(i)[0]); }
                    final boolean[] sel = new boolean[ss.size()];
                    new AlertDialog.Builder(a).setTitle("आज हाज़िर कौन है?").setMultiChoiceItems(nm2, sel, new DialogInterface.OnMultiChoiceClickListener() {
                        public void onClick(DialogInterface d, int which, boolean checked) { sel[which] = checked; }
                    }).setPositiveButton("सेव", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            for (int i = 0; i < ids.length; i++) {
                                db.delete("att", "staff_id=? AND date=?", new String[]{String.valueOf(ids[i]), today});
                                ContentValues cv = new ContentValues();
                                cv.put("staff_id", ids[i]); cv.put("date", today); cv.put("p", sel[i] ? 1 : 0);
                                db.insert("att", cv);
                            }
                            ((MainActivity) a).toast("हाज़िरी सेव ✓");
                            ((MainActivity) a).openModule("staff");
                        }
                    }).setNegativeButton("रद्द", null).show();
                }
            });
            Button pay = Ui.btnGrey(a, "इस महीने मजदूरी दें");
            pay.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    List<String[]> ss = db.rows("SELECT id, name, wage FROM staff WHERE active=1", null);
                    int n = 0;
                    for (String[] s : ss) {
                        long sid = Long.parseLong(s[0]);
                        double days = db.one("SELECT COUNT(*) FROM att WHERE staff_id=? AND p=1 AND date LIKE ?", new String[]{String.valueOf(sid), m + "%"});
                        if (days <= 0) continue;
                        double per = Math.round(Double.parseDouble(s[2]) / 26 * days);
                        String note = s[1] + " (" + (int) days + " दिन)";
                        double c = db.one("SELECT COUNT(*) FROM expenses WHERE date LIKE ? AND cat='मजदूरी' AND note=?", new String[]{m + "%", note});
                        if (c > 0) continue;
                        db.addExpense(Util.lastOfMonth(m), per, "मजदूरी", note);
                        n++;
                    }
                    ((MainActivity) a).toast(n > 0 ? (n + " की मजदूरी जुड़ी ✓") : "कुछ नहीं जुड़ा");
                    ((MainActivity) a).openModule("staff");
                }
            });
            box.addView(ModsA.rowBtn(a, att));
            box.addView(ModsA.rowBtn(a, pay));
            box.addView(Scr.table(a, "👷 स्टाफ (इस महीने हाज़िरी)", db.rows(
                    "SELECT s.name, (IFNULL((SELECT COUNT(*) FROM att WHERE staff_id=s.id AND p=1 AND date LIKE ?),0) || ' दिन · ₹' || s.wage) FROM staff s WHERE s.active=1",
                    new String[]{m + "%"}), "कोई स्टाफ नहीं"));
            return true;
        }
        if (id.equals("reminders")) {
            List<String[]> d = db.dueList();
            LinearLayout c = Scr.card(a, "🔔 बकाया रिमाइंडर");
            if (d.isEmpty()) c.addView(Ui.label(a, "कोई बकाया नहीं ✅"));
            for (final String[] x : d) {
                final long pid = db.one("SELECT id FROM parties WHERE name=?", new String[]{x[0]}) > 0
                        ? (long) db.one("SELECT id FROM parties WHERE name=?", new String[]{x[0]}) : 0;
                c.addView(Scr.item(a, x[0], "बकाया " + Util.money(Double.parseDouble(x[1])), "📞", Ui.GREEN,
                        new View.OnClickListener() {
                            public void onClick(View v) {
                                Db.Party p = Db.get(a).party(pid);
                                if (p == null || p.phone.isEmpty()) { ((MainActivity) a).toast("फ़ोन नंबर नहीं है"); return; }
                                String txt = "नमस्ते " + p.name + ", आपका बकाया " + Util.money(Double.parseDouble(x[1]))
                                        + " है। कृपया भुगतान कर दें। — " + Db.get(a).get("shopName", "दूध हिसाब");
                                try {
                                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/91" + p.phone.replaceAll("[^0-9]", "") + "?text=" + Uri.encode(txt)));
                                    a.startActivity(i);
                                } catch (Exception e) { }
                            }
                        }));
            }
            box.addView(c);
            return true;
        }
        if (id.equals("compare")) {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MONTH, -1);
            String pm = String.format(Locale.US, "%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
            double s1 = db.saleMonth(m), s0 = db.saleMonth(pm), n1 = db.netMonth(m), n0 = db.netMonth(pm);
            box.addView(Scr.report(a, "📊 " + Util.monthLabel(pm) + " → " + Util.monthLabel(m),
                    new String[]{"बिक्री (इस महीने)", "बिक्री (पिछले)", "फ़र्क़", "मुनाफ़ा (इस महीने)", "मुनाफ़ा (पिछले)"},
                    new String[]{Util.money(s1), Util.money(s0),
                            (s1 >= s0 ? "▲ +" : "▼ ") + Util.money(Math.abs(s1 - s0)),
                            Util.money(n1), Util.money(n0)},
                    n1 >= n0 ? Ui.GREEN : Ui.RED));
            return true;
        }
        if (id.equals("trend")) {
            box.addView(Scr.chartCard(a, "📈 पिछले 12 महीने की बिक्री", db.monthSeries(12)));
            return true;
        }
        if (id.equals("statement") || id.equals("ledger")) {
            final boolean isStatement = id.equals("statement");
            Button pick = Ui.btn(a, "ग्राहक चुनें");
            pick.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    final List<Db.Party> ps = db.parties("customer");
                    if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
                    String[] n = ModsA.names(ps);
                    new AlertDialog.Builder(a).setTitle("किसका?").setItems(n, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { showStatement(a, box, ps.get(w), m, isStatement); }
                    }).show();
                }
            });
            box.addView(ModsA.rowBtn(a, pick));
            box.addView(Scr.note(a, isStatement
                    ? "ग्राहक का महीने का हिसाब देखें और PDF बिल बनाएँ।"
                    : "ग्राहक की हर एंट्री और भुगतान की पूरी बही।"));
            return true;
        }
        if (id.equals("invoices")) {
            box.addView(Scr.report(a, "🧾 इनवॉइस", new String[]{"अगला नंबर"}, new String[]{"#" + db.nextInvoiceNo()}, Ui.GREEN));
            Button add = Ui.btn(a, "नया इनवॉइस बनाएँ");
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    final List<Db.Party> ps = db.parties("customer");
                    if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
                    String[] n = ModsA.names(ps);
                    new AlertDialog.Builder(a).setTitle("किसका इनवॉइस?").setItems(n, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { newInvoice(a, db, ps.get(w), m); }
                    }).show();
                }
            });
            box.addView(ModsA.rowBtn(a, add));
            box.addView(Scr.table(a, "बने हुए इनवॉइस", db.rows(
                    "SELECT ('#' || i.no || ' · ' || IFNULL(p.name,'—') || ' · ' || i.label), i.amount FROM invoices i LEFT JOIN parties p ON p.id=i.party_id ORDER BY i.no DESC",
                    null), "कोई इनवॉइस नहीं"));
            return true;
        }
        if (id.equals("quality")) {
            double avg = db.fatAvgMonth(m);
            double q = db.qtyMonth(m);
            box.addView(Scr.report(a, "🥛 " + Util.monthLabel(m) + " — गुणवत्ता (FAT)",
                    new String[]{"औसत फैट", "कुल दूध"},
                    new String[]{avg > 0 ? Util.num(Math.round(avg * 100) / 100.0) : "—", Util.num(q) + " L"}, Ui.GREEN));
            box.addView(Scr.table(a, "फैट के हिसाब से दूध", db.rows(
                    "SELECT (CASE WHEN fat<4 THEN '4 से कम' WHEN fat<5 THEN '4 – 5' WHEN fat<6 THEN '5 – 6' WHEN fat<7 THEN '6 – 7' ELSE '7 से ज़्यादा' END), (IFNULL(SUM(qty),0) || ' L') "
                            + "FROM entries WHERE kind='sale' AND fat>0 AND date LIKE ? GROUP BY CASE WHEN fat<4 THEN 1 WHEN fat<5 THEN 2 WHEN fat<6 THEN 3 WHEN fat<7 THEN 4 ELSE 5 END ORDER BY 1",
                    new String[]{m + "%"}), "इस महीने फैट दर्ज नहीं है"));
            return true;
        }
        return false;
    }

    /* ---------------- statement / ledger ---------------- */

    private static void showStatement(final Activity a, LinearLayout box, Db.Party p, String m, boolean isStatement) {
        final Db db = Db.get(a);
        List<Db.Entry> es = db.entriesOf(p.id, Util.firstOfMonth(m), Util.lastOfMonth(m));
        double q = 0, amt = 0;
        List<String[]> rows = new ArrayList<String[]>();
        for (Db.Entry e : es) {
            if (!"sale".equals(e.kind)) continue;
            q += e.qty; amt += e.amount;
            rows.add(new String[]{e.date + "  " + Util.shiftHi(e.shift), Util.num(e.qty) + " L · " + Util.money(e.amount)});
        }
        double paid = db.one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE party_id=? AND date>=? AND date<=?",
                new String[]{String.valueOf(p.id), Util.firstOfMonth(m), Util.lastOfMonth(m)});
        box.addView(Scr.report(a, "📄 " + p.name + " · " + Util.monthLabel(m),
                new String[]{"कुल दूध", "कुल बिल", "जमा (भुगतान)", "इस महीने बाकी", "कुल बकाया"},
                new String[]{Util.num(q) + " L", Util.money(amt), Util.money(paid), Util.money(amt - paid), Util.money(db.balance(p.id))},
                Ui.RED));
        box.addView(Scr.table(a, isStatement ? "महीने की एंट्री" : "बही (सारी एंट्री)", rows, "इस महीने कोई एंट्री नहीं"));

        if (!isStatement) {
            List<String[]> pays = db.rows("SELECT (date || ' · ' || IFNULL(mode,'') || ' ' || IFNULL(note,'')), amount FROM payments WHERE party_id=? ORDER BY date DESC",
                    new String[]{String.valueOf(p.id)});
            box.addView(Scr.table(a, "भुगतान", pays, "कोई भुगतान नहीं"));
        }
        Button pdf = Ui.btn(a, "📄 PDF बिल बनाएँ");
        pdf.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { TabReports.exportPdf(a, db, p, m); }
        });
        box.addView(ModsA.rowBtn(a, pdf));
    }

    private static void newInvoice(final Activity a, final Db db, final Db.Party p, final String m) {
        LinearLayout v = ModsA.form(a);
        double auto = db.one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND party_id=? AND date LIKE ?",
                new String[]{String.valueOf(p.id), m + "%"});
        final EditText amt = ModsA.et(a, "रकम (खाली = इस महीने का कुल " + Util.money(auto) + ")", "");
        final EditText nt = ModsA.et(a, "नोट", "");
        v.addView(amt); v.addView(nt);
        ModsA.show(a, "नया इनवॉइस — " + p.name, v, "सेव", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                double am = ModsA.num(amt);
                if (am <= 0) am = db.one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND party_id=? AND date LIKE ?",
                        new String[]{String.valueOf(p.id), m + "%"});
                if (am <= 0) { ((MainActivity) a).toast("रकम नहीं मिली"); return; }
                ContentValues cv = new ContentValues();
                cv.put("no", db.nextInvoiceNo()); cv.put("date", Util.today());
                cv.put("party_id", p.id); cv.put("amount", am);
                cv.put("label", Util.monthLabel(m)); cv.put("note", ModsA.str(nt));
                db.insert("invoices", cv);
                ((MainActivity) a).toast("इनवॉइस #" + (db.nextInvoiceNo() - 1) + " बन गया ✓");
            }
        }, "invoices");
    }
}
