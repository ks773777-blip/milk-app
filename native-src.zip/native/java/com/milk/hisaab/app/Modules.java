package com.milk.hisaab.app;

import android.app.Activity;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

/** Registry of every module + grouped hub rendering. */
public class Modules {

    public static class Mod {
        public String id, icon, name, group;
        public Mod(String id, String icon, String name, String group) {
            this.id = id; this.icon = icon; this.name = name; this.group = group;
        }
    }

    public static final String[] GROUP_NAMES = {"रोज़ का काम", "पैसा व खर्च", "ग्राहक व स्टाफ", "रिपोर्ट व बिल", "पशु व उत्पादन", "ऐप व सेटिंग"};
    public static final String[] GROUP_ICONS = {"🌅", "💰", "👥", "📊", "🐄", "⚙️"};

    public static final List<Mod> ALL = new ArrayList<Mod>();

    static {
        add("bulk", "🧺", "बल्क एंट्री", "0");
        add("bulkmonth", "🗓️", "बल्क मासिक", "0");
        add("holiday", "🎉", "छुट्टी", "0");
        add("milkcard", "🥛", "मिल्क कार्ड", "0");
        add("calendar", "📅", "कैलेंडर", "0");
        add("register", "📒", "डेली रजिस्टर", "0");
        add("delivery", "🚚", "डिलीवरी शीट", "0");
        add("dayend", "🌙", "दिन-अंत सारांश", "0");
        add("stock", "📦", "स्टॉक", "0");
        add("notes", "📝", "नोट्स", "0");
        add("calc", "🧮", "कैलकुलेटर", "0");

        add("payments", "💵", "भुगतान", "1");
        add("dues", "⏳", "बकाया", "1");
        add("expenses", "💸", "खर्च", "1");
        add("explog", "🧾", "खर्च बहीखाता", "1");
        add("rate", "📈", "रेट चार्ट", "1");
        add("loans", "💳", "उधार / कर्ज़", "1");
        add("recurring", "🔁", "आवर्ती खर्च", "1");
        add("budget", "💰", "मासिक बजट", "1");
        add("pnl", "📉", "लाभ-हानि", "1");
        add("monthclose", "📅", "महीना बंद", "1");

        add("routes", "🛣️", "रूट सारांश", "2");
        add("topcust", "🏆", "टॉप ग्राहक", "2");
        add("inactive", "😴", "निष्क्रिय ग्राहक", "2");
        add("staff", "👷", "स्टाफ व मजदूरी", "2");
        add("reminders", "🔔", "रिमाइंडर", "2");

        add("compare", "📊", "महीना तुलना", "3");
        add("trend", "📈", "वार्षिक ट्रेंड", "3");
        add("statement", "📄", "स्टेटमेंट", "3");
        add("ledger", "📒", "खाता (लेजर)", "3");
        add("invoices", "🧾", "इनवॉइस नंबर", "3");
        add("quality", "🥛", "गुणवत्ता (FAT)", "3");

        add("animals", "🐄", "पशु रजिस्टर", "4");
        add("wastage", "📉", "वेस्टेज / नुकसान", "4");

        add("insights", "🔎", "स्मार्ट इनसाइट्स", "5");
        add("ai", "🤖", "AI सहायक", "5");
        add("settings", "⚙️", "सेटिंग", "5");
        add("backup", "💾", "बैकअप", "5");
        add("perms", "🔐", "परमिशन", "5");
        add("datacheck", "🩺", "डेटा जाँच", "5");
        add("support", "🆘", "सहायता", "5");
        add("legal", "📜", "नियम व प्राइवेसी", "5");
        add("help", "❓", "मदद", "5");
    }

    private static void add(String id, String ic, String nm, String g) { ALL.add(new Mod(id, ic, nm, g)); }

    public static Mod find(String id) { for (Mod m : ALL) if (m.id.equals(id)) return m; return null; }

    public static List<Mod> group(int g) {
        List<Mod> out = new ArrayList<Mod>();
        for (Mod m : ALL) if (m.group.equals(String.valueOf(g))) out.add(m);
        return out;
    }

    public static void render(Activity a, LinearLayout box, String id) {
        boolean done = ModsA.render(a, box, id);
        if (!done) done = ModsB.render(a, box, id);
        if (!done) done = ModsC.render(a, box, id);
        if (!done) box.addView(Scr.note(a, "यह मॉड्यूल अभी बन रहा है।"));
    }
}
