package com.milk.hisaab.app;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.List;

/** Dashboard tab. */
public class TabHome {
    public void build(final Activity a, LinearLayout box) {
        final Db db = Db.get(a);
        String today = Util.today(), m = Util.month();

        LinearLayout c1 = Ui.card(a);
        c1.addView(Ui.tv(a, "🌅 सुबह / शाम कलेक्शन", 15f, Ui.INK, true));
        double mq = db.qtyOn(today, "morning"), eq = db.qtyOn(today, "evening");
        double ma = db.saleAmtOn(today, "morning"), ea = db.saleAmtOn(today, "evening");
        c1.addView(Ui.line(a, "🌅 सुबह", Util.num(mq) + " L · " + Util.money(ma), false, null));
        c1.addView(Ui.line(a, "🌙 शाम", Util.num(eq) + " L · " + Util.money(ea), false, null));
        c1.addView(Ui.line(a, "कुल", Util.num(mq + eq) + " L · " + Util.money(ma + ea), true, Ui.GREEN));
        box.addView(c1);

        LinearLayout grid = Ui.row(a);
        grid.setLayoutParams(Ui.lpGap(a, 12));
        grid.addView(stat(a, "आज की बिक्री", Util.money(db.saleOn(today)), Ui.GREEN, true));
        grid.addView(stat(a, "कुल बकाया", Util.money(db.totalDue()), Ui.RED, false));
        box.addView(grid);

        LinearLayout c2 = Ui.card(a);
        c2.addView(Ui.tv(a, "📊 " + Util.monthLabel(m), 15f, Ui.INK, true));
        double s = db.saleMonth(m), p = db.purchaseMonth(m), x = db.expenseMonth(m), net = s - p - x;
        c2.addView(Ui.line(a, "बिक्री", Util.money(s), false, null));
        c2.addView(Ui.line(a, "खरीद", Util.money(p), false, null));
        c2.addView(Ui.line(a, "खर्च", Util.money(x), false, null));
        c2.addView(Ui.line(a, "शुद्ध मुनाफ़ा", Util.money(net), true, net >= 0 ? Ui.GREEN : Ui.RED));
        box.addView(c2);

        LinearLayout c3 = Ui.card(a);
        c3.addView(Ui.tv(a, "⚡ झटपट", 15f, Ui.INK, true));
        LinearLayout r = Ui.row(a);
        Button b1 = Ui.btn(a, "➕ नई एंट्री");
        b1.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        b1.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { ((MainActivity) a).go(1); } });
        r.addView(b1);
        Button b2 = Ui.btnGrey(a, "👥 ग्राहक");
        b2.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        b2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { ((MainActivity) a).go(2); } });
        r.addView(b2);
        c3.addView(r);
        box.addView(c3);

        LinearLayout c4 = Ui.card(a);
        c4.addView(Ui.tv(a, "⏳ सबसे ज़्यादा बकाया", 15f, Ui.INK, true));
        List<String[]> dues = db.dueList();
        if (dues.isEmpty()) c4.addView(Ui.label(a, "कोई बकाया नहीं ✅"));
        else for (int i = 0; i < Math.min(5, dues.size()); i++)
            c4.addView(Ui.line(a, dues.get(i)[0], Util.money(Double.parseDouble(dues.get(i)[1])), false, Ui.RED));
        box.addView(c4);
    }

    private LinearLayout stat(Activity a, String label, String val, int color, boolean left) {
        LinearLayout c = Ui.col(a);
        c.setBackground(Ui.round(Ui.CARD, 16, a));
        int p = Ui.dp(a, 14);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (left) lp.rightMargin = Ui.dp(a, 10);
        c.setLayoutParams(lp);
        c.addView(Ui.label(a, label));
        c.addView(Ui.tv(a, val, 19f, color, true));
        return c;
    }
}
