package com.milk.hisaab.app;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Minimal Gemini REST call (key comes from Settings — never hard-coded). */
public class Gemini {
    public static String ask(String key, String context, String question) {
        try {
            URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key="
                    + URLEncoder.encode(key, "UTF-8"));
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(25000);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            org.json.JSONObject part = new org.json.JSONObject();
            part.put("text", "तुम एक दूध-डेयरी व्यापार के सहायक हो। नीचे दुकान का असली डेटा है। बहुत छोटा, सरल, सटीक जवाब हिंदी में दो (सिर्फ़ 3-5 पंक्तियाँ)।\n\n"
                    + context + "\n\nसवाल: " + question);
            org.json.JSONArray parts = new org.json.JSONArray(); parts.put(part);
            org.json.JSONObject content = new org.json.JSONObject(); content.put("parts", parts);
            org.json.JSONArray contents = new org.json.JSONArray(); contents.put(content);
            org.json.JSONObject gen = new org.json.JSONObject();
            gen.put("temperature", 0.4);
            gen.put("maxOutputTokens", 500);
            org.json.JSONObject body = new org.json.JSONObject();
            body.put("contents", contents);
            body.put("generationConfig", gen);

            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();

            int code = c.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            try {
                org.json.JSONObject j = new org.json.JSONObject(sb.toString());
                return j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getString("text");
            } catch (Exception e) {
                return "जवाब नहीं मिला — key या इंटरनेट जाँचें।";
            }
        } catch (Exception e) {
            return "इंटरनेट नहीं मिला — कृपया नेट चालू करें।";
        }
    }
}
