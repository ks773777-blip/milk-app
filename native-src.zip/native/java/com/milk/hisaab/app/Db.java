package com.milk.hisaab.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** SQLite data layer — full schema for every module. */
public class Db extends SQLiteOpenHelper {

    private static final String NAME = "milk.db";
    private static final int VERSION = 2;
    private static Db inst;

    public static synchronized Db get(Context c) {
        if (inst == null) inst = new Db(c.getApplicationContext());
        return inst;
    }

    private Db(Context c) { super(c, NAME, null, VERSION); }

    @Override public void onCreate(SQLiteDatabase d) { createTables(d); }

    @Override public void onUpgrade(SQLiteDatabase d, int o, int n) { createTables(d); }

    private void createTables(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE IF NOT EXISTS parties(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, type TEXT, rate REAL, route TEXT, default_qty REAL, opening REAL, active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, party_id INTEGER, kind TEXT, shift TEXT, qty REAL, fat REAL, rate REAL, amount REAL)");
        d.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, party_id INTEGER, amount REAL, mode TEXT, note TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, amount REAL, cat TEXT, note TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS wastage(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, qty REAL, rate REAL, value REAL, reason TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS animals(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, tag TEXT, note TEXT, active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, name TEXT, amount REAL, kind TEXT, note TEXT, settled INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE IF NOT EXISTS recurring(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, amount REAL, cat TEXT, day INTEGER, active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, no INTEGER, date TEXT, party_id INTEGER, amount REAL, label TEXT, note TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, wage REAL, active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE IF NOT EXISTS att(id INTEGER PRIMARY KEY AUTOINCREMENT, staff_id INTEGER, date TEXT, p INTEGER)");
        d.execSQL("CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, text TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS holidays(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, party_id INTEGER)");
        d.execSQL("CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, stock REAL, low_at REAL, rate REAL)");
        d.execSQL("CREATE TABLE IF NOT EXISTS closes(month TEXT PRIMARY KEY, at INTEGER, json TEXT)");
        d.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT)");
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_e ON entries(date)");
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_ep ON entries(party_id)");
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pd ON payments(date)");
    }

    /* ---------------- models ---------------- */

    public static class Party {
        public long id;
        public String name = "", phone = "", type = "customer", route = "";
        public double rate, defaultQty, opening;
        public boolean active = true;
    }

    public static class Entry {
        public long id, partyId;
        public String date = "", kind = "sale", shift = "morning";
        public double qty, fat, rate, amount;
    }

    /* ---------------- generic helpers (used by most modules) ---------------- */

    public List<String[]> rows(String sql, String[] args) {
        List<String[]> out = new ArrayList<String[]>();
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        while (c.moveToNext()) {
            String[] r = new String[c.getColumnCount()];
            for (int i = 0; i < r.length; i++) r[i] = c.getString(i) == null ? "" : c.getString(i);
            out.add(r);
        }
        c.close();
        return out;
    }

    public void exec(String sql) { getWritableDatabase().execSQL(sql); }
    public void exec(String sql, Object[] args) { getWritableDatabase().execSQL(sql, args); }

    public long insert(String table, ContentValues cv) { return getWritableDatabase().insert(table, null, cv); }
    public void delete(String table, String where, String[] args) { getWritableDatabase().delete(table, where, args); }

    /* ---------------- settings ---------------- */

    public String get(String k, String def) {
        Cursor c = getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?", new String[]{k});
        String r = def;
        if (c.moveToFirst()) r = c.getString(0);
        c.close();
        return r;
    }
    public double getNum(String k, double def) {
        try { return Double.parseDouble(get(k, String.valueOf(def))); } catch (Exception e) { return def; }
    }
    public void set(String k, String v) {
        ContentValues cv = new ContentValues();
        cv.put("k", k); cv.put("v", v);
        getWritableDatabase().insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    /* ---------------- parties ---------------- */

    public long saveParty(Party p) {
        ContentValues cv = new ContentValues();
        cv.put("name", p.name); cv.put("phone", p.phone); cv.put("type", p.type);
        cv.put("rate", p.rate); cv.put("route", p.route);
        cv.put("default_qty", p.defaultQty); cv.put("opening", p.opening);
        cv.put("active", p.active ? 1 : 0);
        SQLiteDatabase d = getWritableDatabase();
        if (p.id > 0) { d.update("parties", cv, "id=?", new String[]{String.valueOf(p.id)}); return p.id; }
        return d.insert("parties", null, cv);
    }

    public void deleteParty(long id) {
        SQLiteDatabase d = getWritableDatabase();
        d.delete("entries", "party_id=?", new String[]{String.valueOf(id)});
        d.delete("payments", "party_id=?", new String[]{String.valueOf(id)});
        d.delete("parties", "id=?", new String[]{String.valueOf(id)});
    }

    public Party party(long id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name,phone,type,rate,route,default_qty,opening,active FROM parties WHERE id=?", new String[]{String.valueOf(id)});
        Party p = c.moveToFirst() ? readParty(c) : null;
        c.close();
        return p;
    }

    public List<Party> parties(String type) {
        String sql = "SELECT id,name,phone,type,rate,route,default_qty,opening,active FROM parties"
                + (type == null ? "" : " WHERE type=?") + " ORDER BY name COLLATE NOCASE";
        Cursor c = getReadableDatabase().rawQuery(sql, type == null ? null : new String[]{type});
        List<Party> out = new ArrayList<Party>();
        while (c.moveToNext()) out.add(readParty(c));
        c.close();
        return out;
    }

    private Party readParty(Cursor c) {
        Party p = new Party();
        p.id = c.getLong(0); p.name = nz(c.getString(1)); p.phone = nz(c.getString(2));
        p.type = nz(c.getString(3)); p.rate = c.getDouble(4); p.route = nz(c.getString(5));
        p.defaultQty = c.getDouble(6); p.opening = c.getDouble(7); p.active = c.getInt(8) == 1;
        return p;
    }

    /* ---------------- entries ---------------- */

    public long saveEntry(Entry e) {
        ContentValues cv = new ContentValues();
        cv.put("date", e.date); cv.put("party_id", e.partyId); cv.put("kind", e.kind);
        cv.put("shift", e.shift); cv.put("qty", e.qty); cv.put("fat", e.fat);
        cv.put("rate", e.rate); cv.put("amount", e.amount);
        SQLiteDatabase d = getWritableDatabase();
        if (e.id > 0) { d.update("entries", cv, "id=?", new String[]{String.valueOf(e.id)}); return e.id; }
        return d.insert("entries", null, cv);
    }

    public void deleteEntry(long id) {
        getWritableDatabase().delete("entries", "id=?", new String[]{String.valueOf(id)});
    }

    public List<Entry> entriesOn(String date) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,date,party_id,kind,shift,qty,fat,rate,amount FROM entries WHERE date=? ORDER BY id", new String[]{date});
        List<Entry> out = new ArrayList<Entry>();
        while (c.moveToNext()) out.add(readEntry(c));
        c.close();
        return out;
    }

    public List<Entry> entriesOf(long partyId, String from, String to) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,date,party_id,kind,shift,qty,fat,rate,amount FROM entries WHERE party_id=? AND date>=? AND date<=? ORDER BY date",
                new String[]{String.valueOf(partyId), from, to});
        List<Entry> out = new ArrayList<Entry>();
        while (c.moveToNext()) out.add(readEntry(c));
        c.close();
        return out;
    }

    private Entry readEntry(Cursor c) {
        Entry e = new Entry();
        e.id = c.getLong(0); e.date = nz(c.getString(1)); e.partyId = c.getLong(2);
        e.kind = nz(c.getString(3)); e.shift = nz(c.getString(4));
        e.qty = c.getDouble(5); e.fat = c.getDouble(6); e.rate = c.getDouble(7); e.amount = c.getDouble(8);
        return e;
    }

    /* ---------------- payments / expenses ---------------- */

    public void addPayment(String date, long partyId, double amount, String mode, String note) {
        ContentValues cv = new ContentValues();
        cv.put("date", date); cv.put("party_id", partyId); cv.put("amount", amount);
        cv.put("mode", mode == null ? "" : mode); cv.put("note", note == null ? "" : note);
        getWritableDatabase().insert("payments", null, cv);
    }

    public void addExpense(String date, double amount, String cat, String note) {
        ContentValues cv = new ContentValues();
        cv.put("date", date); cv.put("amount", amount);
        cv.put("cat", cat == null ? "" : cat); cv.put("note", note == null ? "" : note);
        getWritableDatabase().insert("expenses", null, cv);
    }

    public boolean hasHoliday(String date, long partyId) {
        return one("SELECT COUNT(*) FROM holidays WHERE date=? AND party_id=?", new String[]{date, String.valueOf(partyId)}) > 0;
    }

    /* ---------------- aggregates ---------------- */

    public double one(String sql, String[] args) {
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        double r = c.moveToFirst() ? c.getDouble(0) : 0;
        c.close();
        return r;
    }

    public double saleOn(String date) { return one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND date=?", new String[]{date}); }
    public double qtyOn(String date, String shift) {
        return one("SELECT IFNULL(SUM(qty),0) FROM entries WHERE kind='sale' AND date=? AND shift=?", new String[]{date, shift});
    }
    public double saleAmtOn(String date, String shift) {
        return one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND date=? AND shift=?", new String[]{date, shift});
    }
    public double saleMonth(String m) { return one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND date LIKE ?", new String[]{m + "%"}); }
    public double qtyMonth(String m) { return one("SELECT IFNULL(SUM(qty),0) FROM entries WHERE kind='sale' AND date LIKE ?", new String[]{m + "%"}); }
    public double purchaseMonth(String m) { return one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='purchase' AND date LIKE ?", new String[]{m + "%"}); }
    public double expenseMonth(String m) { return one("SELECT IFNULL(SUM(amount),0) FROM expenses WHERE date LIKE ?", new String[]{m + "%"}); }
    public double wastageMonth(String m) { return one("SELECT IFNULL(SUM(value),0) FROM wastage WHERE date LIKE ?", new String[]{m + "%"}); }
    public double paymentMonth(String m) { return one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE date LIKE ?", new String[]{m + "%"}); }
    public double fatAvgMonth(String m) {
        double q = one("SELECT IFNULL(SUM(qty),0) FROM entries WHERE kind='sale' AND fat>0 AND date LIKE ?", new String[]{m + "%"});
        if (q <= 0) return 0;
        return one("SELECT IFNULL(SUM(qty*fat),0) FROM entries WHERE kind='sale' AND fat>0 AND date LIKE ?", new String[]{m + "%"}) / q;
    }

    public double netMonth(String m) { return saleMonth(m) - purchaseMonth(m) - expenseMonth(m) - wastageMonth(m); }

    public double balance(long partyId) {
        double opening = one("SELECT IFNULL(opening,0) FROM parties WHERE id=?", new String[]{String.valueOf(partyId)});
        double sale = one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='sale' AND party_id=?", new String[]{String.valueOf(partyId)});
        double pur = one("SELECT IFNULL(SUM(amount),0) FROM entries WHERE kind='purchase' AND party_id=?", new String[]{String.valueOf(partyId)});
        double paid = one("SELECT IFNULL(SUM(amount),0) FROM payments WHERE party_id=?", new String[]{String.valueOf(partyId)});
        return opening + sale - pur - paid;
    }

    public double totalDue() {
        double t = 0;
        for (Party p : parties("customer")) { double b = balance(p.id); if (b > 0) t += b; }
        return t;
    }

    public List<String[]> dueList() {
        List<Party> ps = parties("customer");
        List<double[]> tmp = new ArrayList<double[]>();
        for (int i = 0; i < ps.size(); i++) tmp.add(new double[]{i, balance(ps.get(i).id)});
        java.util.Collections.sort(tmp, new java.util.Comparator<double[]>() {
            public int compare(double[] a, double[] b) { return Double.compare(b[1], a[1]); }
        });
        List<String[]> out = new ArrayList<String[]>();
        for (double[] row : tmp) if (row[1] > 0.5) out.add(new String[]{ps.get((int) row[0]).name, String.valueOf(row[1])});
        return out;
    }

    public List<String[]> monthSeries(int months) {
        List<String[]> out = new ArrayList<String[]>();
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.add(java.util.Calendar.MONTH, -(months - 1));
        for (int i = 0; i < months; i++) {
            String m = String.format(java.util.Locale.US, "%04d-%02d", cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1);
            out.add(new String[]{Util.MONTHS_SHORT_HI[cal.get(java.util.Calendar.MONTH)], String.valueOf(saleMonth(m))});
            cal.add(java.util.Calendar.MONTH, 1);
        }
        return out;
    }

    public int nextInvoiceNo() { return (int) one("SELECT IFNULL(MAX(no),0)+1 FROM invoices", null); }

    /* ---------------- backup / wipe ---------------- */

    public String dumpJson() {
        try {
            org.json.JSONObject root = new org.json.JSONObject();
            String[] tables = {"parties", "entries", "payments", "expenses", "wastage", "animals",
                    "loans", "recurring", "invoices", "staff", "att", "notes", "holidays", "items"};
            for (String t : tables) {
                org.json.JSONArray arr = new org.json.JSONArray();
                Cursor c = getReadableDatabase().rawQuery("SELECT * FROM " + t, null);
                String[] cols = c.getColumnNames();
                while (c.moveToNext()) {
                    org.json.JSONObject o = new org.json.JSONObject();
                    for (int i = 0; i < cols.length; i++) o.put(cols[i], c.getString(i));
                    arr.put(o);
                }
                c.close();
                root.put(t, arr);
            }
            return root.toString(2);
        } catch (Exception e) { return "{}"; }
    }

    public void wipe() {
        SQLiteDatabase d = getWritableDatabase();
        String[] tables = {"entries", "payments", "expenses", "wastage", "animals", "loans",
                "recurring", "invoices", "staff", "att", "notes", "holidays", "items", "closes", "parties"};
        for (String t : tables) d.delete(t, null, null);
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
