package com.milk.hisaab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Reports tab: month summary, native chart, top customers, PDF bill. */
public class TabReports {

    private static String month = Util.month();

    public void build(final Activity a, LinearLayout box) {
        final Db db = Db.get(a);

        LinearLayout nav = Ui.card(a);
        LinearLayout r = Ui.row(a);
        Button prev = Ui.btnGrey(a, "◀");
        prev.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { month = shiftMonth(month, -1); ((MainActivity) a).go(3); } });
        r.addView(prev);
        TextView lbl = Ui.tv(a, Util.monthLabel(month), 15f, Ui.INK, true);
        lbl.setGravity(Gravity.CENTER);
        Ui.weight(lbl, 1f);
        r.addView(lbl);
        Button next = Ui.btnGrey(a, "▶");
        next.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { month = shiftMonth(month, 1); ((MainActivity) a).go(3); } });
        r.addView(next);
        nav.addView(r);
        box.addView(nav);

        double s = db.saleMonth(month), p = db.purchaseMonth(month), x = db.expenseMonth(month), pay = db.paymentMonth(month);
        double net = s - p - x;
        LinearLayout c1 = Ui.card(a);
        c1.addView(Ui.tv(a, "📊 " + Util.monthLabel(month) + " का हिसाब", 15f, Ui.INK, true));
        c1.addView(Ui.line(a, "कुल दूध बिक्री", Util.num(db.qtyMonth(month)) + " L", false, null));
        c1.addView(Ui.line(a, "बिक्री", Util.money(s), false, null));
        c1.addView(Ui.line(a, "खरीद", Util.money(p), false, null));
        c1.addView(Ui.line(a, "खर्च", Util.money(x), false, null));
        c1.addView(Ui.line(a, "वसूली (जमा)", Util.money(pay), false, Ui.GREEN));
        c1.addView(Ui.line(a, "शुद्ध मुनाफ़ा", Util.money(net), true, net >= 0 ? Ui.GREEN : Ui.RED));
        box.addView(c1);

        LinearLayout c2 = Ui.card(a);
        c2.addView(Ui.tv(a, "📈 पिछले 6 महीने की बिक्री", 15f, Ui.INK, true));
        Chart chart = new Chart(a, db.monthSeries(6));
        chart.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(a, 180)));
        c2.addView(chart);
        box.addView(c2);

        LinearLayout c3 = Ui.card(a);
        c3.addView(Ui.tv(a, "⏳ बकाया (सबसे ऊपर)", 15f, Ui.INK, true));
        List<String[]> dues = db.dueList();
        if (dues.isEmpty()) c3.addView(Ui.label(a, "कोई बकाया नहीं ✅"));
        else for (int i = 0; i < Math.min(8, dues.size()); i++)
            c3.addView(Ui.line(a, dues.get(i)[0], Util.money(Double.parseDouble(dues.get(i)[1])), false, Ui.RED));
        box.addView(c3);

        Button pdf = Ui.btn(a, "📄 PDF बिल बनाएँ (Downloads में)");
        pdf.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickBill(a, db); } });
        box.addView(pdf);
    }

    private void pickBill(final Activity a, final Db db) {
        final List<Db.Party> ps = db.parties("customer");
        if (ps.isEmpty()) { ((MainActivity) a).toast("पहले ग्राहक जोड़ें"); return; }
        String[] names = new String[ps.size()];
        for (int i = 0; i < ps.size(); i++) names[i] = ps.get(i).name;
        new AlertDialog.Builder(a).setTitle("किसका बिल बनाएँ?").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { makePdf(a, db, ps.get(which)); }
        }).show();
    }

    private void makePdf(Activity a, Db db, Db.Party p) {
        try {
            PdfDocument doc = new PdfDocument();
            PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
            PdfDocument.Page page = doc.startPage(pi);
            Canvas c = page.getCanvas();
            Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
            pt.setColor(Color.BLACK);
            int y = 56;
            pt.setTextSize(18);
            pt.setFakeBoldText(true);
            c.drawText(db.get("shopName", "दूध हिसाब"), 40, y, pt);
            y += 26;
            pt.setFakeBoldText(false);
            pt.setTextSize(12);
            String owner = db.get("owner", "");
            String phone = db.get("bizPhone", "");
            if (!owner.isEmpty()) { c.drawText(owner, 40, y, pt); y += 16; }
            if (!phone.isEmpty()) { c.drawText(phone, 40, y, pt); y += 16; }
            y += 8;
            pt.setTextSize(14);
            pt.setFakeBoldText(true);
            c.drawText("बिल — " + Util.monthLabel(month), 40, y, pt);
            pt.setFakeBoldText(false);
            y += 20;
            pt.setTextSize(13);
            c.drawText("नाम: " + p.name, 40, y, pt); y += 16;
            if (!p.phone.isEmpty()) { c.drawText("फ़ोन: " + p.phone, 40, y, pt); y += 16; }
            y += 6;
            c.drawText("तारीख", 40, y, pt);
            c.drawText("समय", 150, y, pt);
            c.drawText("लीटर", 240, y, pt);
            c.drawText("रेट", 320, y, pt);
            c.drawText("रकम", 430, y, pt);
            y += 6;
            c.drawRect(40, y, 555, y + 1, pt);
            y += 16;
            double q = 0, amt = 0;
            List<Db.Entry> es = db.entriesOf(p.id, Util.firstOfMonth(month), Util.lastOfMonth(month));
            for (Db.Entry e : es) {
                if (!"sale".equals(e.kind)) continue;
                q += e.qty; amt += e.amount;
                c.drawText(e.date, 40, y, pt);
                c.drawText(Util.shiftHi(e.shift), 150, y, pt);
                c.drawText(Util.num(e.qty), 240, y, pt);
                c.drawText(Util.num(e.rate), 320, y, pt);
                c.drawText(Util.money(e.amount), 430, y, pt);
                y += 16;
                if (y > 760) break;
            }
            y += 8;
            c.drawRect(40, y, 555, y + 1, pt);
            y += 22;
            pt.setTextSize(14);
            pt.setFakeBoldText(true);
            c.drawText("कुल दूध: " + Util.num(q) + " लीटर", 40, y, pt); y += 20;
            c.drawText("कुल बिल: " + Util.money(amt), 40, y, pt); y += 20;
            c.drawText("कुल बकाया: " + Util.money(db.balance(p.id)), 40, y, pt);
            y += 30;
            pt.setFakeBoldText(false);
            pt.setTextSize(11);
            c.drawText("धन्यवाद 🙏", 40, y, pt);
            doc.finishPage(page);

            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            doc.writeTo(bos);
            doc.close();
            String where = Io.saveToDownloads(a, "bill-" + p.name.replaceAll("\\s+", "-") + "-" + month + ".pdf", "application/pdf", bos.toByteArray());
            ((MainActivity) a).toast(where == null ? "PDF सेव नहीं हो सका" : "PDF सेव: " + where);
        } catch (Exception e) {
            ((MainActivity) a).toast("PDF नहीं बन सका");
        }
    }

    private static String shiftMonth(String m, int d) {
        try {
            int y = Integer.parseInt(m.substring(0, 4)), mo = Integer.parseInt(m.substring(5, 7));
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.set(y, mo - 1, 1);
            c.add(java.util.Calendar.MONTH, d);
            return String.format(java.util.Locale.US, "%04d-%02d", c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1);
        } catch (Exception e) { return m; }
    }

    /** Tiny native bar chart. */
    static class Chart extends View {
        private final List<String[]> data;
        Chart(Context c, List<String[]> d) { super(c); this.data = d; }

        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            cv.drawColor(Color.WHITE);
            if (data == null || data.isEmpty()) return;
            double max = 1;
            for (String[] d : data) { double v = Double.parseDouble(d[1]); if (v > max) max = v; }
            int pad = Ui.dp(getContext(), 26);
            int base = h - Ui.dp(getContext(), 24);
            int top = Ui.dp(getContext(), 12);
            float slot = (w - pad * 2f) / data.size();
            float bw = slot * 0.52f;
            Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
            bar.setColor(Ui.GREEN);
            Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
            txt.setColor(Ui.MUTED);
            txt.setTextSize(Ui.dp(getContext(), 11));
            txt.setTextAlign(Paint.Align.CENTER);
            Paint axis = new Paint();
            axis.setColor(Ui.LINE);
            cv.drawRect(pad, base, w - pad, base + 1, axis);
            for (int i = 0; i < data.size(); i++) {
                double v = Double.parseDouble(data.get(i)[1]);
                int bh = (int) ((base - top) * (max <= 0 ? 0 : v / max));
                float x = pad + i * slot + (slot - bw) / 2f;
                cv.drawRoundRect(x, base - bh, x + bw, base, 6, 6, bar);
                cv.drawText(data.get(i)[0], x + bw / 2f, base + Ui.dp(getContext(), 16), txt);
            }
        }
    }
}
